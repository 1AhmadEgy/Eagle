# Device Transfer Protocol

Define discovery, mutual authentication, transfer authorization, key wrapping, transfer scope, integrity checks, cancellation, timeout, rollback, partial-transfer cleanup, and post-transfer trust activation.

No plaintext secrets may cross an unauthenticated channel.
