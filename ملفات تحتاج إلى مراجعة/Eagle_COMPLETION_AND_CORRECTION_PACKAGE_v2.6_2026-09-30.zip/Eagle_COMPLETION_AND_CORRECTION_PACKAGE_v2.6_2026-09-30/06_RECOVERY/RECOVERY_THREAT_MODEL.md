# Recovery Threat Model

Separate account/identity recovery from data recovery. Analyze stolen device, lost device, malicious new device, social engineering, recovery-secret theft, rollback, replay, downgrade, and insider abuse.

Preferred early model: trusted device → authenticated device transfer → new trusted device, subject to explicit policy and user verification.
