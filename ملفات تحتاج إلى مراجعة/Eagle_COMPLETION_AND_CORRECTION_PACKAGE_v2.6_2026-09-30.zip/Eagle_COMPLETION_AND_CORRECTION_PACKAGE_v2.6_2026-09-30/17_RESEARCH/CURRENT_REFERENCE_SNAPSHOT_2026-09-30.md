# Current Reference Snapshot — 2026-09-30

- SLSA 1.2: Approved/current specification.
- Signal Double Ratchet: Revision 4 (2025-11-04).
- Signal PQXDH: Revision 3, last updated 2024-01-23.
- OWASP MASWE: v1.0.0 stable (2026-08-17).
- OWASP MASTG: v2.0.0 stable (2026-07-04).

These references support the project baseline but do not establish implementation adoption by themselves.
