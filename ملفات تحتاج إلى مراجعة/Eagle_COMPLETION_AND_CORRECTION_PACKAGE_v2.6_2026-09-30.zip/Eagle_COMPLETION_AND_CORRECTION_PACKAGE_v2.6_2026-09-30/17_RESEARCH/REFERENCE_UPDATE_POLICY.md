# Reference Update Policy

On every protocol/crypto/platform/dependency/security-advisory change: record source/date/version, impact analysis, affected requirements/ADR/specs/tests, compatibility implications, and release-gate effect.

Official sources outrank secondary commentary.
