# Change Control

Every security-sensitive change records: change ID, reason, affected requirements, ADR, threat impact, compatibility impact, migration, tests, evidence, reviewer, verifier, rollback, and release gate.

Security kernel, identity, cryptographic state, trust state, recovery, deletion, and downgrade changes require explicit security review.
