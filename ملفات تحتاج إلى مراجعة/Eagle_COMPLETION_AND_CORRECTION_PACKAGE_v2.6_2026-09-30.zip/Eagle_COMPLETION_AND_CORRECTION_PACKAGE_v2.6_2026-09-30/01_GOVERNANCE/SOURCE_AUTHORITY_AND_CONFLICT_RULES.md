# Source Authority and Conflict Rules

Authority order: normative standards/official specifications > official platform documentation > adopted-library documentation > peer-reviewed research/security advisories > project ADRs/specifications > implementation > discussion.

When sources conflict, record both claims, rank authority, assess security impact, create/modify an ADR, update affected specifications, and add regression tests. Never silently overwrite a source.
