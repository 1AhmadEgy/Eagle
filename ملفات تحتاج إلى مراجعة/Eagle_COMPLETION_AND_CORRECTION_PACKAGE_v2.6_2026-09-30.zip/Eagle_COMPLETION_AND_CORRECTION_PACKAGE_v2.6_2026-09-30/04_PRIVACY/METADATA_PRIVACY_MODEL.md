# Metadata Privacy Model

Classify metadata into required, optional, sensitive, and forbidden-to-log. Model timing, identifiers, network addresses, relationship data, device information, delivery state, and operational telemetry.

Privacy claims must be stated as concrete guarantees with scope and limitations; never claim metadata anonymity unless demonstrated.
