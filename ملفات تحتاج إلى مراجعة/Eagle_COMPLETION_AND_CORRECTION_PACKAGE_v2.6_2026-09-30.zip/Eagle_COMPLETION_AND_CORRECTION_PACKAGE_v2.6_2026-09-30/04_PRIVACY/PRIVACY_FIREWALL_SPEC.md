# Privacy Firewall Specification

Telemetry pipeline: Event generation → schema validation → data classification → minimization/redaction → policy check → sampling/rate limit → export.

Private keys, plaintext content, recovery secrets, raw message payloads, and unnecessary PII are blocked by policy.
