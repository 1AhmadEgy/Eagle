# Transport Security Contract

Transport provides confidentiality/integrity where applicable but does not replace application-layer end-to-end cryptographic guarantees. Define QUIC usage, certificate/trust model where applicable, connection migration, timeouts, replay assumptions, and downgrade resistance.
