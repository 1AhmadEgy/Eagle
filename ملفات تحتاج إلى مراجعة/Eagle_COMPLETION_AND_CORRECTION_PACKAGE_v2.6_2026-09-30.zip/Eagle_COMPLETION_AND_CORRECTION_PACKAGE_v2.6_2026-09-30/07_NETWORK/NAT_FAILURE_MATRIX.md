# NAT / Connectivity Failure Matrix

Test symmetric NAT, restricted NAT, CGNAT, IPv4/IPv6 differences, blocked UDP, blocked TCP, MTU problems, packet loss, reordering, duplication, delay, relay-only operation, reconnect, and network handoff.

Expected outcome must specify safe fallback without weakening authentication or encryption.
