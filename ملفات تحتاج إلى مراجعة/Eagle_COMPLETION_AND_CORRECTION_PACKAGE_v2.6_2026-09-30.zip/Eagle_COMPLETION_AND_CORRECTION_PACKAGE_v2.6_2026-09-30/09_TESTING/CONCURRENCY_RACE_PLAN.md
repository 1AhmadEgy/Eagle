# Concurrency and Race Testing Plan

Target session state, ratchet state, key rotation, device transfer, deletion, reconnect, duplicate delivery, simultaneous sends, cancellation, and recovery.

Use deterministic scheduling where possible and retain seeds/traces for reproduction.
