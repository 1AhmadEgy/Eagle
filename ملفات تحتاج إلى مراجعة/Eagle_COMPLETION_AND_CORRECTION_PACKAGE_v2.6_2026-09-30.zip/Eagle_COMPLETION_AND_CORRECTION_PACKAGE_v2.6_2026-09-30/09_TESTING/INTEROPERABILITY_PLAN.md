# Interoperability Plan

Interoperability targets must be explicit. Test canonical encodings, version negotiation, rejection of unsupported versions, cryptographic vectors, transport behavior, and state synchronization.

Record implementation/version/platform for every interoperability participant.
