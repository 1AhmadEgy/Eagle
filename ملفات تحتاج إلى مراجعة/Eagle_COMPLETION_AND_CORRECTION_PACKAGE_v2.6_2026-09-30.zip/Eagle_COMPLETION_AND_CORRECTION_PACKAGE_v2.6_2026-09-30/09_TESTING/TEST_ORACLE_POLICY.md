# Test Oracle Policy

Every security test defines an observable oracle independent of implementation internals where possible. Oracles must cover positive, negative, malformed, boundary, concurrency, timeout, rollback, and recovery cases.

A test passing because it merely matches implementation behavior is insufficient for protocol/security correctness.
