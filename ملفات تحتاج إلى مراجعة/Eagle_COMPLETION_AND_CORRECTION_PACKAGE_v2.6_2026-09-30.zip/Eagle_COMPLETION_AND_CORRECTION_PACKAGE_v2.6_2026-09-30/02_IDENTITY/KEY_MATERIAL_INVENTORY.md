# Key Material Inventory

For every key: purpose, owner, algorithm/profile, generation, storage boundary, access policy, rotation trigger, revocation trigger, backup rule, deletion rule, audit event, and test vector reference.

Do not store private keys in telemetry, logs, crash reports, analytics, or arbitrary application storage.
