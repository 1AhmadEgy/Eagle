# Device Trust State Machine

States: UNKNOWN, ENROLLING, TRUSTED, DEGRADED, COMPROMISED, REVOKED, RETIRED.

Transitions require explicit evidence and policy evaluation. Fail closed on ambiguous state. AI cannot directly mutate trust state.
