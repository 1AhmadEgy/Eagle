# Identity Lifecycle Specification

States: UNINITIALIZED → PROVISIONING → ACTIVE → SUSPENDED → REVOKED → RETIRED.

Identity creation, binding, rotation, revocation, and retirement must be authenticated and auditable. Identity state is distinct from device trust state. No recovery path may silently elevate identity or device trust.
