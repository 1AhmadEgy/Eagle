# Claim Verification Policy

Classify claims as DOCUMENTED, IMPLEMENTED, TESTED, VERIFIED, AUDITED, or UNVERIFIED. A stronger status requires all lower-level evidence plus its own acceptance criteria.

No UI label, README statement, marketing statement, or AI-generated text can substitute for evidence.
