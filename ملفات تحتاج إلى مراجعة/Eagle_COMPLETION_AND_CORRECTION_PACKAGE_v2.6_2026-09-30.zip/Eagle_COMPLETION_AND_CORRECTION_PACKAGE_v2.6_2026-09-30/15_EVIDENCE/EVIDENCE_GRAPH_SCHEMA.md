# Evidence Graph Schema

Nodes: SOURCE, CLAIM, REQUIREMENT, THREAT, CONTROL, ADR, SPECIFICATION, IMPLEMENTATION, TEST, RESULT, EVIDENCE, VERIFICATION, RELEASE, RUNTIME, DRIFT, FINDING.

Edges are typed and immutable in meaning. Every release claim must trace backward to evidence.
