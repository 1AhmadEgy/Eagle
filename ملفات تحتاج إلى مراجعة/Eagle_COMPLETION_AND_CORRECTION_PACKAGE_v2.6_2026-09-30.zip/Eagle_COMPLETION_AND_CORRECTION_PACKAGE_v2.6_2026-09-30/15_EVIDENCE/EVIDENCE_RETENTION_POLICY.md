# Evidence Retention Policy

Retain test logs, artifact hashes, environment/toolchain identity, source commit, SBOM, provenance/attestation, verifier output, review decisions, and regression linkage according to project retention policy.

Sensitive evidence must be minimized and access-controlled.
