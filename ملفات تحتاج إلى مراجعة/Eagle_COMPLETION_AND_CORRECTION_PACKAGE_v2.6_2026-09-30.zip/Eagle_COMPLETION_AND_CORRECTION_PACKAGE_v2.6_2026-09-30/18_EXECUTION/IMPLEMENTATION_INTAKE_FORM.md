# Implementation Intake Form

Repository URL/path
Commit/tag
Workspace/toolchain
Build command
Lockfile/manifest
Source paths
Components covered
Unit/integration/protocol/security tests
Fuzz/property/state tests
Artifacts and hashes
SBOM
Provenance/attestation
Reviewer
Independent verifier
Known gaps

Status: NOT_SUBMITTED / INCOMPLETE / ACCEPTED / VERIFIED / REJECTED
