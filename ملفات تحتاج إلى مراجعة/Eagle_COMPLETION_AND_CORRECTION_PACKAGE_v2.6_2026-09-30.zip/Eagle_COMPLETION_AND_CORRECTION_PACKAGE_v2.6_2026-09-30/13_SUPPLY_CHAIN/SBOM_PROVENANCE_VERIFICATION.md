# SBOM / Provenance Verification Procedure

Required chain: source commit → controlled build → tests → SBOM → provenance → attestation → signed artifact → independent verification.

SLSA v1.2 is the current approved specification. Verification must record exact artifact digest and verifier result.
