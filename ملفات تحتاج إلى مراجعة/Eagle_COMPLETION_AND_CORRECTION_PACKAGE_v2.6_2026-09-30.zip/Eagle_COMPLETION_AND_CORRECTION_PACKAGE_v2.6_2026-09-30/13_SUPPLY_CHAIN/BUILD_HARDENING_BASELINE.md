# Build Hardening Baseline

Pin toolchain/dependencies, protect CI credentials, minimize build permissions, isolate build jobs, verify provenance, prohibit secret exfiltration, retain logs, and verify release artifacts independently.
