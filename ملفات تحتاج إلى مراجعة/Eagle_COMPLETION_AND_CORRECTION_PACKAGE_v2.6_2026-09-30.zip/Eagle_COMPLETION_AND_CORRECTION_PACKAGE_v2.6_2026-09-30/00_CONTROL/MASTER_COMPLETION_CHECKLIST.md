# Master Completion Checklist

1. Governance and source authority
2. Requirements and ADR closure
3. Architecture and trust boundaries
4. Identity/device trust/key management
5. Protocol/session/message semantics
6. Crypto implementation qualification
7. Network and server contracts
8. Storage/deletion/recovery
9. Mobile platform controls
10. Privacy/metadata
11. Test lab and negative testing
12. Supply chain and release
13. AI/MCP governance
14. Operations/incident response
15. Evidence and independent verification
16. Release decision

A project item is not VERIFIED until its required evidence exists.
