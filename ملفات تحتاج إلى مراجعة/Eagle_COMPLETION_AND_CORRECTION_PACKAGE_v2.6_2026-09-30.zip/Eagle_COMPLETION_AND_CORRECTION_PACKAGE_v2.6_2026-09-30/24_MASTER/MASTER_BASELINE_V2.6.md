# Eagle Master Baseline v2.6

Eagle is a security-first private communications project. Core principles: small core, strong standards, mature implementations, explicit contracts, deterministic security policy, fail closed, least privilege, local ownership of sensitive state, evidence-driven testing, auditable decisions.

Current state: documentation baseline substantially expanded; implementation and release evidence remain blocked until real source/build/test evidence is supplied.

Canonical flow:
Source → Requirement → Threat → ADR → Specification → Implementation → Test → Evidence → Independent Verification → Release → Runtime Monitoring → Drift → Reassessment.
