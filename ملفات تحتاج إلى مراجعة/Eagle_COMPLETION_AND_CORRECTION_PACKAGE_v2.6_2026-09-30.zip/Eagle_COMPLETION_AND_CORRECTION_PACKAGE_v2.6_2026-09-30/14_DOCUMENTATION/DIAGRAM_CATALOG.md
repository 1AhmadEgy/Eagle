# Diagram Catalog

Required diagrams: system context, trust boundaries, data flow, protocol state machine, identity lifecycle, device trust, key lifecycle, network connectivity, server data flow, storage lifecycle, deletion lifecycle, recovery/device transfer, mobile trust, AI permission graph, MCP gateway, CI/supply chain, evidence graph, release gates, incident response.

Each diagram has ID, source file, owner, version, date, and linked requirements/ADR.
