# Documentation Style Guide

Normative requirements use MUST/SHOULD/MAY consistently. Separate normative specification, rationale, implementation notes, test procedure, evidence, and open questions. Every security claim includes scope and source.
