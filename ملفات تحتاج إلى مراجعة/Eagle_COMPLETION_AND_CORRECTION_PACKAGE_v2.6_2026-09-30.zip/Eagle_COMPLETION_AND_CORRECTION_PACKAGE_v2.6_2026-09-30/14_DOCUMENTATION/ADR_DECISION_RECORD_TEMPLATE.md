# ADR Template

ADR-ID
Title
Status
Context
Problem
Options
Decision
Security impact
Compatibility
Alternatives rejected
References
Affected requirements/specs
Tests
Evidence
Reviewers
Supersedes/Superseded by
