# Mobile Release Matrix

Axes: Android/iOS, debug/release, supported OS range, device trust capability, hardware-backed key capability, attestation availability, network state, storage state, jailbreak/root condition, accessibility exposure, backup configuration, and update path.

Each cell maps to tests and evidence; unsupported capabilities must fail safely or use an explicitly reviewed fallback.
