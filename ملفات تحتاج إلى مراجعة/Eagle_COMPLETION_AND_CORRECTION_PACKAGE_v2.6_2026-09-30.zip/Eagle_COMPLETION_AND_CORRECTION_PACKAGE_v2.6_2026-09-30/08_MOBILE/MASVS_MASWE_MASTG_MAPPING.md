# MASVS → MASWE → MASTG → Eagle Mapping

Eagle mobile verification record:
MASVS control → MASWE weakness → MASTG test/demo → Eagle TEST-ID → implementation path → evidence artifact → independent verification.

Use stable MASWE v1.0.0 identifiers and MASTG v2 metadata rather than obsolete checklist artifacts.
