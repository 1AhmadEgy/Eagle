# OI-001..OI-008 Closure Worksheet

For each OI: current question, authoritative sources, candidate decision, security impact, compatibility impact, implementation impact, required tests, evidence required, reviewer, verifier, ADR, status.

OI-001 exact Signal implementation/version
OI-002 final PQXDH profile
OI-003 V1 transport boundary
OI-004 server ciphertext retention
OI-005 recovery protocol
OI-006 deletion guarantees
OI-007 server retention policy
OI-008 device trust states
