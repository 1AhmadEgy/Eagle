# Remaining Gaps Register v2.6

GAP-001: Verified production source tree — BLOCKED.
GAP-002: Exact crypto library/version/license/maintenance decision — PENDING.
GAP-003: Final PQXDH profile — PENDING.
GAP-004: V1 transport boundary — PENDING.
GAP-005: Server ciphertext retention — PENDING.
GAP-006: Recovery protocol — PENDING.
GAP-007: Deletion guarantees — PENDING.
GAP-008: Server retention policy — PENDING.
GAP-009: Device trust states — PENDING.
GAP-010: Executable test evidence — BLOCKED until source tree exists.
GAP-011: Reproducible build evidence — BLOCKED.
GAP-012: SBOM/provenance/attestation/signature verification — BLOCKED.
GAP-013: Independent security verification — BLOCKED.
GAP-014: External security audit — BLOCKED.

No gap is marked closed solely because a document exists.
