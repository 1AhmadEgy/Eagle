# AI Evaluation Gates

Evaluate instruction following, security-policy adherence, tool authorization, secret handling, prompt-injection resistance, hallucination rate, evidence citation, regression detection, rollback behavior, and refusal of prohibited actions.

AI suggestions require deterministic policy and human/independent verification before security-sensitive changes.
