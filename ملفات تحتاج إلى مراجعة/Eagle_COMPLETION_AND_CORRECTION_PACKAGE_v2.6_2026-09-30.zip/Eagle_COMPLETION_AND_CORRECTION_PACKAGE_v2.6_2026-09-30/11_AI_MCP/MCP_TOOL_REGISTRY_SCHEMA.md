# MCP Tool Registry Schema

Fields: TOOL-ID, owner, purpose, schema, auth, authorization scope, allowlist, network access, secret access, sandbox, rate limit, audit events, timeout, output classification, failure behavior, verifier, rollback, review date, adoption status.
