# Readiness Scorecard

Use statuses only: VERIFIED-AS-DOCUMENTATION, IMPLEMENTATION-EVIDENCE-PENDING, TEST-EVIDENCE-PENDING, INDEPENDENT-VERIFY-PENDING, AUDIT-PENDING, BLOCKED.

Do not convert these states into a percentage or maturity score without a formally approved scoring model.
