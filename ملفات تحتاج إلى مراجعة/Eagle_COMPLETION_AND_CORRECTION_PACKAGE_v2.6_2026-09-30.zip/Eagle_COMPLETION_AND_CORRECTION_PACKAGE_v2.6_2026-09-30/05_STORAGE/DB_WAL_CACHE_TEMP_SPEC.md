# Database / WAL / Cache / Temporary Data Specification

Track primary DB, WAL/journal, temporary files, caches, attachments, thumbnails, indexes, crash dumps, backups, and OS-managed storage.

Deletion conformance must test each artifact class and distinguish logical deletion, cryptographic deletion, application-level cleanup, filesystem behavior, backup restoration, and forensic residuals.
