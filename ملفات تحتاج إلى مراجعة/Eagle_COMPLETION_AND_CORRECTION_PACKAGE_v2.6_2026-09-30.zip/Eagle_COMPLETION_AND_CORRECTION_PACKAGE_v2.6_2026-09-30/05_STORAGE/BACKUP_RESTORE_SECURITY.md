# Backup and Restore Security

Backups require explicit classification, encryption/key ownership, authorization, retention, deletion, restore authentication, rollback protection, and post-restore trust evaluation.

A restored device is not automatically trusted merely because data was restored.
