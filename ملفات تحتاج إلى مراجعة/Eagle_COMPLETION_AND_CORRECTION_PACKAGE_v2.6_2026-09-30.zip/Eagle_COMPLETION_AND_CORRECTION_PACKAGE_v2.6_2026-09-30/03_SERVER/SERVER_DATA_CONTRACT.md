# Minimal Server Data Contract

Server responsibilities are limited to explicitly specified identity support, prekey/rendezvous/discovery/relay functions. No central message-history assumption is permitted unless an explicit ADR changes it.

For each endpoint define authentication, authorization, input schema, output schema, retention, logging restrictions, rate limits, abuse controls, error semantics, versioning, and deletion behavior.
