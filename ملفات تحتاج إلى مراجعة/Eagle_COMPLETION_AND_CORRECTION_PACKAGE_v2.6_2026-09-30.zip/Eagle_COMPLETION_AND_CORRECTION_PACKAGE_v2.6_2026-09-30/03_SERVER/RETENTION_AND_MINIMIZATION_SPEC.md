# Server Retention and Minimization Specification

For each server datum define purpose, minimum fields, retention duration, deletion trigger, legal/operational exception, access control, logging policy, and verification test.

No telemetry or debugging feature may silently expand retention.
