# Security Invariant Catalog v2

INV-01: unauthorized actors cannot become trusted devices.
INV-02: security policy cannot be bypassed by AI or tools.
INV-03: cryptographic state cannot be silently downgraded.
INV-04: plaintext/private key material is not exported to telemetry.
INV-05: recovery cannot silently grant higher trust.
INV-06: deletion policy cannot be bypassed by ordinary application paths.
INV-07: malformed/untrusted input cannot cause unsafe state transition.
INV-08: release artifacts require verifiable provenance and integrity evidence.
