# Security Kernel Test Catalog

Test categories: authorization, fail-closed behavior, trust transition, downgrade refusal, secret boundary, tool permission, recovery authorization, deletion policy, audit event integrity, rollback safety.

Every invariant must map to at least one positive and one negative test before release.
