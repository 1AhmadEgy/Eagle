# Standards Crosswalk

Project crosswalk targets: Signal specifications, IETF transport/network standards, NIST PQC/SSDF, OWASP MASVS/MASWE/MASTG, SLSA, SPDX/CycloneDX, platform security documentation.

This is a mapping aid, not a claim of formal compliance or certification.
