# Security Incident Runbook

Detect → contain → preserve evidence → classify → scope impact → revoke/rotate → patch → regression test → independent verify → communicate → recover → post-incident review → update threat model/ADR.

Never silently erase evidence needed for security investigation.
