# Key Compromise Runbook

Trigger immediate trust-state review, affected-key identification, revocation/rotation, session invalidation where required, device assessment, evidence preservation, recovery path review, and regression coverage.

Do not claim retroactive recovery of plaintext already exposed.
