# Release Rollback Runbook

Define artifact identity, affected versions, rollback authorization, compatibility, trust implications, key/revocation effects, client/server version interactions, data migration reversal, and post-rollback verification.
