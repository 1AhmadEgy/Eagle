# Red Team Rules of Engagement

Define authorized targets, environments, accounts, data handling, prohibited actions, escalation path, evidence handling, stop conditions, and cleanup.

Red-team findings require reproducibility, impact analysis, remediation, regression testing, and independent verification.
