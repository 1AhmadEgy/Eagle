# Defensive Attack Scenario Catalog

Families: identity confusion, auth bypass, trust escalation, key exposure, downgrade, replay, malformed protocol input, server compromise, metadata leakage, storage residuals, recovery abuse, supply-chain compromise, CI tampering, AI prompt injection, tool poisoning, MCP confused deputy.

This is a defensive test catalog, not an authorization to attack third-party systems.
