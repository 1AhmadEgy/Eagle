# Protocol Conformance Requirements

Conformance requires normative message/state rules, serialization rules, version negotiation, rejection behavior, replay handling, ordering semantics, timeout rules, and negative cases.

Every normative rule maps to a TEST-ID and evidence artifact.
