# Test Vector Catalog

Required vector families: identity, key agreement, ratchet initialization, send/receive, skipped messages, out-of-order delivery, replay, malformed encoding, version mismatch, downgrade attempt, attachment metadata, deletion state, recovery state.

Vectors must have stable IDs, canonical input, expected output/state, source reference, and integrity hash.
