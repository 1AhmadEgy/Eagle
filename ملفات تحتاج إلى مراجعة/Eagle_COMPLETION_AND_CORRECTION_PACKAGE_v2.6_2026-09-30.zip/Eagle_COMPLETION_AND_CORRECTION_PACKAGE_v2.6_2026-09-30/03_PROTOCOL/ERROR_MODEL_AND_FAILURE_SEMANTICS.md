# Error Model and Failure Semantics

Define stable error classes for authentication failure, trust failure, cryptographic failure, malformed input, replay, version mismatch, downgrade attempt, transport failure, server refusal, local storage failure, recovery failure, and policy denial.

Errors must not reveal secrets or create oracle behavior. Security failures fail closed and produce minimal auditable reason codes.
