# Source Record Template

SOURCE-ID, title, publisher, URL/document, version/date, source type, authority, domain, claim supported, component, license, maintenance, security relevance, project status, ADR, specification, tests, evidence, notes.
