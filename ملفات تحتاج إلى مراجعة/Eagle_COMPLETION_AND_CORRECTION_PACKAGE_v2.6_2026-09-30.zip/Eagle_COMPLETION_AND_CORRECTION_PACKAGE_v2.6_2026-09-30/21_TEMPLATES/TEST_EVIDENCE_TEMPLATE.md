# Test Evidence Template

TEST-ID, requirement, component, type, environment, preconditions, input, expected, actual, result, logs, artifact hashes, seed/trace, regression classification, reviewer, independent verifier.
