# Security Finding Template

SEC-ID, title, component, threat, severity, exploitability, impact, evidence, reproduction, affected versions, root cause, fix, regression test, verification, disclosure decision, status.
