# Version Compatibility Policy

Define protocol version, client/server compatibility window, capability negotiation, deprecation period, mandatory security updates, rollback constraints, and downgrade refusal.

Security-critical incompatibilities must fail closed rather than silently weakening controls.
