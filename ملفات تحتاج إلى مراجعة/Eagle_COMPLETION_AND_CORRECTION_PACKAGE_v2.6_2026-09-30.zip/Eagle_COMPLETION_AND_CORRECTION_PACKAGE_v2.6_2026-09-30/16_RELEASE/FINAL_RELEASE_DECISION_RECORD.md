# Final Release Decision Record

Release decision fields: version, commit, artifact digest, requirements status, security findings, test summary, SBOM, provenance, attestation, signature verification, independent verification, external audit status, known limitations, rollback plan, approvers, decision date.

Possible outcomes: BLOCKED, CONDITIONAL, APPROVED_FOR_LIMITED_TESTING, RELEASED. Production release cannot be inferred from documentation completeness.
