# Supply Chain Evidence

Baseline references:
- SLSA 1.2 Approved: source and build tracks, provenance/verification concepts.
- NIST SP 800-218 (SSDF 1.1): Final.
- NIST SP 800-218A: Final AI-focused SSDF Community Profile.

Required Eagle evidence:
- dependency lock/pinning
- vulnerability/advisory scan
- SBOM
- build provenance
- artifact signing
- release verification
- CI policy enforcement
- reproducibility evidence where required

Current project status: POLICY_DEFINED / EVIDENCE_PENDING.
