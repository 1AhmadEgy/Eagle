# Component Evidence Map

| Component | Expected role | Evidence currently available | Status | Required next evidence |
|---|---|---|---|---|
| Rust Core | protocol/security kernel | documentation only in current baseline | PENDING | repository + build + tests |
| Identity | identity lifecycle | specification draft/reference | PENDING | implementation + protocol tests |
| Device Trust | trusted-device policy | specification/reference | PENDING | platform evidence + negative tests |
| Key Management | key lifecycle | specification/reference | PENDING | implementation + crypto tests |
| Session | PQXDH/ratchet boundary | reference/open decision | PENDING | exact implementation/version + vectors |
| Network | direct/relay transport | architecture/reference | PENDING | QUIC/ICE/TURN implementation tests |
| Storage | local sensitive state | candidate/reference | PENDING | encryption/WAL/cache/deletion tests |
| Recovery | identity/data recovery | specification/open decision | PENDING | protocol implementation + abuse tests |
| Deletion | deletion semantics | specification/reference | PENDING | residual/backup/restore evidence |
| Android | platform trust | platform references | PENDING | actual app evidence + MASVS/MASTG tests |
| Apple | platform trust | platform references | PENDING | actual app evidence + platform tests |
| AI Governance | policy boundary | governance docs | PENDING | agent/tool boundary tests |
| MCP/Tools | tool security gateway | governance/reference | PENDING | allowlist/schema/sandbox/audit tests |
| Supply Chain | build/release integrity | policy/reference | PENDING | SBOM/provenance/signing/verification evidence |
