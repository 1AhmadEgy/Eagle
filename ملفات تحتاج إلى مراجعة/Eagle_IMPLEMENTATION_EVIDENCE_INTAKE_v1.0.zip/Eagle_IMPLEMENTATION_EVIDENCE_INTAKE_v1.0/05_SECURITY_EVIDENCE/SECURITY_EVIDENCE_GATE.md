# Security Evidence Gate

Critical security areas requiring explicit evidence:
- authentication and authorization
- device trust
- key generation/storage/use/destruction
- session establishment and ratchet state
- downgrade/capability negotiation
- plaintext/secret leakage
- recovery abuse and unauthorized recovery
- deletion and residual data
- tool/MCP authorization and sandboxing
- dependency/build/release compromise

Gate: BLOCKED until required evidence exists and independent verification is recorded.
