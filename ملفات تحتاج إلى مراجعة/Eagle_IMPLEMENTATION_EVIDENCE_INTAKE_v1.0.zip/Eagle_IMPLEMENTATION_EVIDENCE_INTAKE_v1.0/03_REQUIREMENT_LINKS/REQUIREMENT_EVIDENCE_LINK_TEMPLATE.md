# Requirement → Evidence Link Template

| REQ-ID | Specification | Implementation | Test ID | Evidence artifact | Verification | Status |
|---|---|---|---|---|---|---|
| REQ-XXXX | SPEC-XXXX | pending | TEST-XXXX | pending | pending | PENDING |

Rules:
1. A requirement cannot become VERIFIED without implementation and test evidence.
2. Security-critical requirements require security/negative testing where applicable.
3. Evidence must be reproducible and attributable to an exact version/commit/environment.
