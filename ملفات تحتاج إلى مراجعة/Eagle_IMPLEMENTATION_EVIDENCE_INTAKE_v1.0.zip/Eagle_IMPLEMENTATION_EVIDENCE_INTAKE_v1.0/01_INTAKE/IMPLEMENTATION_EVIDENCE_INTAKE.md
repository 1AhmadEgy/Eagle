# Implementation Evidence Intake

## Required evidence per component
- Repository / commit identifier
- Exact source path(s)
- Build command and toolchain version
- Dependency lockfile / manifest
- Static-analysis results
- Unit-test results
- Integration/protocol-test results where applicable
- Negative/failure-test results
- Security-test results where applicable
- Reproducible evidence artifact
- Reviewer / verifier identity
- Date and environment

## Status
NOT_SUBMITTED / SUBMITTED / INCOMPLETE / ACCEPTED / VERIFIED / REJECTED

## Stop-the-line conditions
Crypto/auth/trust bypass, key leakage, plaintext leakage, recovery bypass, deletion bypass, downgrade weakness, critical dependency/build compromise, or ambiguous security policy.
