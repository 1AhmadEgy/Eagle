# Minimum Test Evidence

For each test:
- TEST-ID
- Requirement / component
- Test type
- Exact environment
- Preconditions
- Input / scenario
- Expected result
- Actual result
- PASS/FAIL/BLOCKED/NOT_RUN/NOT_APPLICABLE
- Logs/artifacts/hash
- Regression classification
- Independent verification

Documentation-only claims are NOT test evidence.
