# Open Decision Closure Gate Matrix

| Decision | Required closure evidence | Current state |
|---|---|---|
| OI-001 exact Signal implementation/version | exact implementation + license + maintenance + security review + vectors/tests | PENDING |
| OI-002 final PQXDH profile | selected profile + interoperability + negative tests | PENDING |
| OI-003 V1 transport boundary | protocol boundary + QUIC/ICE/TURN tests | PENDING |
| OI-004 server ciphertext retention | explicit data contract + threat analysis + tests | PENDING |
| OI-005 recovery protocol | state machine + abuse/failure tests | PENDING |
| OI-006 deletion guarantees | precise guarantee scope + residual/backup tests | PENDING |
| OI-007 server retention policy | explicit retention matrix + verification | PENDING |
| OI-008 device trust states | state machine + platform evidence + downgrade tests | PENDING |

No decision is marked ACCEPTED solely because it appears in a reference document.
