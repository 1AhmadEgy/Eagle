# External Supply-Chain Baseline — v1.1

## Verified external references
- SLSA v1.2 — Approved specification; Source and Build tracks; provenance/attestation guidance.
- NIST SP 800-218 (SSDF v1.1) — Final.
- NIST SP 800-218 Rev.1 / SSDF v1.2 — Draft; do not treat as final.
- NIST SP 800-218A — Final profile for secure development of Generative AI and dual-use foundation models.

## Project mapping
- Source integrity/provenance → Source Registry + release provenance.
- Build integrity → CI/build gate + artifact provenance.
- AI development security → AI Governance + agent verification + evaluation.
- Vulnerability/dependency management → Third-Party Component Registry + advisory monitoring.

Adoption remains subject to Eagle ADR/review; listing a standard does not imply adoption.
