# Open Decision Closure — Execution Plan v1.1

All OI items remain OPEN until their required evidence exists.

1. OI-001 Signal implementation/version: identify exact implementation, release, license, advisories, maintenance state, supported protocol profile, and test vectors.
2. OI-002 PQXDH profile: freeze protocol parameters and implementation mapping; require positive, negative, downgrade and interoperability tests.
3. OI-003 transport: freeze V1 boundary for direct/QUIC/ICE/TURN and define server/relay trust assumptions.
4. OI-004 server retention: specify whether ciphertext is retained, for how long, deletion semantics, and compromise consequences.
5. OI-005 trust states: define deterministic identity/device states and allowed transitions.
6. OI-006 linking: define authenticated device-to-device linking, revocation and rollback resistance.
7. OI-007 recovery: separate identity/account recovery from data recovery and specify abuse controls.
8. OI-008 deletion: specify logical, cryptographic, application, backup and forensic guarantees without claiming impossible physical destruction.

Gate rule: no decision is ACCEPTED solely because it appears in a proposal/spec draft; it requires ADR + specification update + required tests + evidence.
