# Conflict Register — v1.1

| ID | Conflict | Current decision | Required closure |
|---|---|---|---|
| CON-001 | Source classification vs adoption lifecycle vocabularies | keep both concepts separate | governance mapping ADR |
| CON-002 | Eagle_MASTER_REFERENCE_INDEX vs EAGLE_REFERENCE_INDEX_V2 role overlap | not resolved | direct file comparison + canonical-role ADR |
| CON-003 | Eagle_MASTER_PROJECT_REFERENCE vs PRIVATE_MESH_MASTER_PROJECT_REFERENCE | both preserved; roles differ | authority/role ADR |
| CON-004 | Signal implementation/version | open | implementation + advisory/license/maintenance review + tests |
| CON-005 | PQXDH profile | open | protocol conformance/interoperability/downgrade tests |
| CON-006 | V1 transport boundary | open | threat model + network tests |
| CON-007 | server ciphertext retention | open | privacy/threat model + deletion/compromise tests |
| CON-008 | device trust/linking | open | state-machine + negative tests |
| CON-009 | recovery | open | abuse/rollback/revocation tests |
| CON-010 | deletion guarantees | open | storage/WAL/cache/backup/forensic evidence |
