# File Reconciliation — v1.1

| Item | Evidence | Result | Status |
|---|---|---|---|
| Eagle_MASTER_REFERENCE_INDEX.md | SHA-256: 4ee646de6535c2bb9d4e2cfe96a74f75ff4c78151fd2f169d6868f0230689935 | exact local hash recorded | VERIFIED |
| Eagle_MASTER_PROJECT_REFERENCE.md | SHA-256: b219f7cb551e5ac245505b0a1c9a575b90133f9aae931a96ba2cc9a2c3fab5f2 | exact local hash recorded | VERIFIED |
| PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md | SHA-256: ad82fb02da2fe313f0027d9389d67753c06e1b6a1f388d3fa8a39a67a582c3c7 | exact local hash recorded | VERIFIED |
| EAGLE_REFERENCE_INDEX_V2.md | not present as a separately verified working-file path | cannot perform exact hash comparison here | PENDING |
| CORRECTED package | archive exists and was inspected | 24 archive entries | VERIFIED |
| MASTERIZATION package | archive exists and was inspected | 38 archive entries | VERIFIED |

Conclusion: the previously identified overlap between the two reference indexes remains a semantic/governance issue, not an exact-file equality finding, until EAGLE_REFERENCE_INDEX_V2.md is available for direct comparison.
