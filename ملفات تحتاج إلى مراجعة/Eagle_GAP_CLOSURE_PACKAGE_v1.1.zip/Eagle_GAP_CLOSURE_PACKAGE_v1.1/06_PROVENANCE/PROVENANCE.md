# Provenance v1.1

Parent artifacts:
- Eagle_GAP_CLOSURE_PACKAGE_v1.0.zip
- Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip
- Eagle_MASTERIZATION_PACKAGE_v1.0.zip
- Eagle_MASTERIZATION_COMPARISON_REPORT_v1.0.md

This package adds verified local hash/reconciliation data and updated gate definitions. It does not replace historical packages.
