# Test Gate Expansion v1.1

| Gate | Required evidence before PASS |
|---|---|
| Identity/Auth | reproducible positive/negative/state-transition tests |
| Session/Crypto | protocol vectors, failure handling, replay/out-of-order tests |
| PQXDH | conformance, interoperability, downgrade and malformed-input tests |
| Transport | QUIC/ICE/TURN/NAT, timeout, resource exhaustion and failure-injection tests |
| Storage | key protection, encryption, WAL/journal/cache/temp/backup behavior |
| Deletion | logical/crypto/app/backup/restore/forensic-residual evidence |
| Recovery | trusted-device transfer, revocation, rollback, abuse and lockout tests |
| Mobile | MASVS/MASTG evidence for Android/iOS |
| AI/MCP | authorization, sandbox, prompt injection, tool poisoning, argument validation, excessive-agency tests |
| Supply Chain | dependency audit, SBOM, provenance, signature verification, vulnerability review |
| Fuzz/Property | corpus, seed, minimized reproducer, regression artifact |
| External Audit | independent report, findings, remediation and verification |

No gate is PASS because a test is planned. PASS requires actual reproducible evidence.
