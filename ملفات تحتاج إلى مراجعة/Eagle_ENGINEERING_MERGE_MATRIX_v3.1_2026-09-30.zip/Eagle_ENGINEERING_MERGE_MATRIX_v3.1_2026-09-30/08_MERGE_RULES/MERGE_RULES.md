# Merge Rules v3.1

1. Preserve every uploaded package in provenance.
2. Deduplicate only exact byte-identical archives/files operationally.
3. Never merge solely by filename similarity.
4. Version families are compared by path + content + semantic role.
5. Canonical status is determined by authority layer, not filename.
6. Unresolved ADRs remain unresolved.
7. Documentation never upgrades implementation status.
8. Implementation never upgrades security assurance without executed evidence.
9. Security claims must match demonstrated controls.
10. Production release remains blocked until release gates are evidenced.
