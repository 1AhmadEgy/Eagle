# Eagle / PrivateMesh — Canonical Baseline v3.1

## Authority model

The active baseline is layered. No single historical ZIP is declared the entire project.

### Layer A — Project identity and non-negotiable security principles
Use the master project reference / constitutional material.

### Layer B — Reference and standards index
Use the master reference index to locate standards, libraries, projects, and research. Presence in the index does not mean adoption.

### Layer C — Architecture and specification
Use the baseline/specification and corrected specification material, but only where decisions are closed.

### Layer D — Decisions / ADRs
An unresolved decision remains unresolved. It cannot be closed by repetition across documents.

### Layer E — Implementation
Only actual source code and build manifests establish implementation.

### Layer F — Tests and evidence
Only executed, attributable evidence establishes verification.

### Layer G — Release
Production is allowed only after all required implementation, security, verification, and release gates are satisfied.

## Historical packages

All uploaded packages remain provenance. A package named FINAL, MASTER, COMPLETE, or PRODUCTION does not automatically override a lower layer.

## Exact duplicate uploads

Exact byte-identical uploads may be represented once operationally, but their original filenames and hashes remain in provenance.

## Security principle

Never create placeholder cryptography, networking, recovery, deletion, identity, or authorization code merely to close a gap or make tests/builds pass.
