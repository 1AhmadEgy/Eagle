# Security Release Gate v3.1

## Current state: BLOCKED

The project cannot be promoted to production from documentation alone.

### Mandatory evidence
- complete source tree
- dependency manifests + lockfiles
- reproducible clean build
- executable unit/integration tests
- protocol/crypto test vectors
- negative/downgrade/authorization tests
- fuzz/property/state-machine testing where applicable
- SBOM generated from actual build
- artifact provenance and signing verification
- independent verification
- external security audit

### Non-negotiable
Do not implement custom cryptography or security placeholders to satisfy a documentation gap.
Do not weaken a gate because a document has a newer filename.
