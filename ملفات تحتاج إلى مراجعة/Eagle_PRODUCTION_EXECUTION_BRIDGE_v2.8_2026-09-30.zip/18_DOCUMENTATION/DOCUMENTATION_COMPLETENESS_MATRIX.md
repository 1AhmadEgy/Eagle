# Documentation Completeness Matrix

For every component:
Purpose
Scope
Threats
Requirements
Architecture
Interfaces
Failure modes
Security invariants
Tests
Evidence
Operations
Recovery
Rollback
References
Owner
Version
Status

Missing critical fields are tracked as documentation gaps.
