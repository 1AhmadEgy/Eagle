# Security Invariant Catalog v2

Examples:
SI-001 unauthenticated peers cannot enter an authenticated session.
SI-002 unauthorized actions cannot mutate trust state.
SI-003 private key material never enters ordinary telemetry.
SI-004 unsupported protocol versions cannot silently downgrade.
SI-005 failed verification cannot be converted into success by retry logic.
SI-006 recovery cannot bypass device-trust policy.
SI-007 deletion policy cannot be bypassed by cache/WAL/temp/backup paths.
SI-008 AI cannot override deterministic security policy.
SI-009 tools cannot exceed declared authority.
SI-010 release artifacts must satisfy provenance/signature policy.

Each invariant requires at least one positive, negative, regression, and evidence-producing test where applicable.
