# Abuse Case Catalog

Minimum defensive scenarios:
- stolen device
- cloned device state
- compromised server
- malicious relay
- replay
- downgrade
- malformed message
- key substitution
- recovery abuse
- deletion bypass
- dependency compromise
- poisoned build
- malicious CI change
- prompt injection
- tool poisoning
- confused deputy
- excessive agent authority
- telemetry leakage
- resource exhaustion

Each case must map to Threat → Control → Implementation → Test → Evidence.
