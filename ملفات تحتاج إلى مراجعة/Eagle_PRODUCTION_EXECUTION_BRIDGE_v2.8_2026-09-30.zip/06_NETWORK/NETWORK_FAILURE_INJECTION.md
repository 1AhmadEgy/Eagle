# Network Failure Injection

Required defensive tests:
- packet loss
- delay
- duplication
- reordering
- connection reset
- NAT rebinding
- relay fallback
- DNS failure
- timeout
- partial connectivity
- resource exhaustion

Expected behavior must remain within protocol and security invariants.
