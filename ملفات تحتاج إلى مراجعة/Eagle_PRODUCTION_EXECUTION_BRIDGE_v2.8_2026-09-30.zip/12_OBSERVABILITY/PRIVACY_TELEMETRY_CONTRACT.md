# Privacy Telemetry Contract

Telemetry must minimize sensitive data.

Never export by default:
- private keys
- session secrets
- recovery secrets
- message plaintext
- attachment plaintext
- unnecessary personal data

Events should favor identifiers, policy decisions, reason codes, severity, and references to retained evidence rather than secret contents.
