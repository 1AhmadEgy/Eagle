# Drift-to-Change Pipeline

Observe standards/dependencies/platforms → detect drift → classify impact → create finding → map requirements → review ADR/spec impact → generate tests → execute → verify → update evidence → release gate.

No silent drift-driven production changes.
