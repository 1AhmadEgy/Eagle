# Test Evidence Rules

Documentation is not execution evidence.
A claim becomes VERIFIED only when:
- exact implementation is identified
- test actually ran
- result is recorded
- evidence is retained
- environment is identified
- independent verification is completed when required

Screenshots alone are insufficient for critical security claims unless the evidence policy explicitly accepts them.
