# Test Execution Record

Required fields:
TEST-ID
Requirement
Component
Version/Commit
Environment
Preconditions
Input
Expected
Actual
Result
Logs/Artifacts
Artifact Hash
Regression Classification
Reviewer
Independent Verifier
Date

Results: PASS / FAIL / BLOCKED / NOT_RUN / NOT_APPLICABLE.
