# Consume-Side Supply Chain Verification

Do not only produce SBOM/provenance/signatures; verify them before consumption/release.

Required checks:
- expected source
- expected builder
- expected artifact digest
- provenance validity
- attestation validity
- signature validity
- dependency policy
- vulnerability policy
- policy decision recorded

Verification failure is a release blocker.
