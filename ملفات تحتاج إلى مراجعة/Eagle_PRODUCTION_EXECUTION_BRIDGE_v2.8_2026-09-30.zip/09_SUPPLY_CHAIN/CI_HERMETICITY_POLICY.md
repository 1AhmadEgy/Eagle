# CI Hermeticity Policy

Preferred controls:
- pinned actions/dependencies
- committed lockfiles
- immutable artifact references
- controlled network access
- no uncontrolled remote scripts
- isolated build runners
- least-privilege CI tokens
- reproducible build inputs
- recorded toolchain
- release artifact verification
