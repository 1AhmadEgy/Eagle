# Release Blocker Catalog v2

Automatic blocker:
- unresolved critical security finding
- failed security invariant
- failed cryptographic/protocol conformance
- unverified build provenance
- invalid/missing artifact signature
- unknown dependency risk
- unreproduced release
- missing required test evidence
- failed independent verification
- unresolved critical open decision
- security policy ambiguity
