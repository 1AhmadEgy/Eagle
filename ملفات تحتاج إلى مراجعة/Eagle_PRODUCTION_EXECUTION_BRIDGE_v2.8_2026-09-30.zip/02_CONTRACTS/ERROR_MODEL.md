# Error Model

Errors must be typed and stable enough for deterministic policy.

Classes:
AUTHENTICATION_FAILURE
AUTHORIZATION_FAILURE
INVALID_INPUT
UNSUPPORTED_VERSION
DOWNGRADE_REJECTED
CRYPTO_FAILURE
TRUST_FAILURE
STATE_VIOLATION
NETWORK_FAILURE
STORAGE_FAILURE
RECOVERY_FAILURE
POLICY_BLOCK
RATE_LIMITED
INTERNAL_FAILURE

Do not expose secrets, private keys, recovery material, or unnecessary internal state in user/server error responses.
