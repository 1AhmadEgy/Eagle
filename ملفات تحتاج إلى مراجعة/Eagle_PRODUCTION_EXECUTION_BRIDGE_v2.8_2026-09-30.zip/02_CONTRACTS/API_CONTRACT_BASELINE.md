# API Contract Baseline

Every externally reachable interface must define:
- authentication and authorization
- input schema and bounds
- output schema
- error codes
- timeout/retry behavior
- idempotency
- rate limits
- version negotiation
- downgrade handling
- sensitive-data rules
- audit/event semantics
- compatibility policy

Unknown, malformed, unauthorized, or unsupported input must fail closed.
