# Rollback Runbook

Rollback prerequisites:
- known-good artifact
- verified digest/signature
- compatible rollback target
- migration reversal plan
- security impact assessment
- evidence capture
- approval record

Never rollback blindly across incompatible cryptographic or state migrations.
