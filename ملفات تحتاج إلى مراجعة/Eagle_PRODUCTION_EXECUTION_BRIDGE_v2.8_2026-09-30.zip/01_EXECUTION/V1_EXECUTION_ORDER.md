# V1 Execution Order

1. Workspace/bootstrap and deterministic build.
2. Security policy and invariant enforcement.
3. Identity and device lifecycle.
4. Device trust.
5. Key management.
6. Session establishment and protocol state machines.
7. PQXDH/Double Ratchet integration behind explicit interfaces.
8. Message serialization/versioning.
9. Server contract and minimal trust boundary.
10. Transport boundary.
11. Local storage and deletion semantics.
12. Recovery/device transfer.
13. Android/iOS integration.
14. Full test matrix.
15. Supply-chain evidence.
16. Independent verification.
17. Release candidate gate.

No later stage may override a failed earlier security gate.
