# Implementation Intake Gate

Required:
1. Repository identity and commit/tag.
2. Exact source-tree inventory.
3. Rust/toolchain versions and lockfile.
4. Build command and clean-build evidence.
5. Dependency manifests and checksums.
6. Unit/integration/protocol tests.
7. Negative/security tests.
8. Fuzz/property/state-machine harnesses.
9. Reproducible artifact.
10. SBOM.
11. Provenance/attestation.
12. Artifact signature and verification.
13. Reviewer and independent verifier identities.

States: NOT_SUBMITTED / INCOMPLETE / ACCEPTED / VERIFIED / REJECTED.
