# MCP Tool Authorization Matrix

Every tool must declare:
Tool ID
Owner
Purpose
Input schema
Allowed data
Forbidden data
Allowed actions
Forbidden actions
Required privileges
Network access
Secret access
Sandbox
Rate limit
Audit event
Approval requirement
Rollback
Verifier

Unknown tool or schema = deny.
