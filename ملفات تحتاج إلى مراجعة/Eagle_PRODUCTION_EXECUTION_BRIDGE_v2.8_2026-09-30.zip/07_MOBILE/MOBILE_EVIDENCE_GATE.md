# Mobile Evidence Gate

Trace:
MASVS control → MASWE weakness → MASTG test → Eagle TEST-ID → tool/environment → result → artifact/hash → independent verification.

Android and iOS platform claims must be tied to the exact OS/device/toolchain tested.
