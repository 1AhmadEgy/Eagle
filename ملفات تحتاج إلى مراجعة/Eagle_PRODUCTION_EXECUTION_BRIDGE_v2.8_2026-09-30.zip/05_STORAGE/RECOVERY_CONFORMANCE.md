# Recovery Conformance

Recovery must distinguish:
1. identity/account recovery
2. trusted-device recovery
3. data recovery

Tests must cover stolen device, lost device, compromised recovery channel, replayed transfer, partial transfer, interrupted transfer, and rollback.
