# Storage Conformance

Verify:
- encryption/key separation
- WAL/journal behavior
- cache behavior
- temporary files
- attachments/thumbnails
- indexes
- crash recovery
- backup/restore
- logical deletion
- cryptographic deletion where applicable
- OS/filesystem residual limitations

Never claim absolute physical destruction unless the platform actually provides a defensible guarantee.
