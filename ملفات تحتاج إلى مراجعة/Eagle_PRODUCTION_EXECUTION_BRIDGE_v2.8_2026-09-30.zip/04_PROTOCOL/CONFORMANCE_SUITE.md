# Protocol Conformance Suite

Conformance dimensions:
- serialization
- state transitions
- version negotiation
- authentication
- session establishment
- ratchet transitions
- replay handling
- duplicate handling
- ordering
- malformed inputs
- timeout/retry
- peer incompatibility
- downgrade rejection

Golden vectors must be versioned, hashed, reviewed, and regression-tested.
