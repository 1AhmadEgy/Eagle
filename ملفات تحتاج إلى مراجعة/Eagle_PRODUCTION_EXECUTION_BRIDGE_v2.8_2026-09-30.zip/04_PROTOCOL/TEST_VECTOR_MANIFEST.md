# Test Vector Manifest

Fields:
VECTOR-ID
Protocol Version
Component
Input Encoding
Expected Output
Expected State
Security Invariant
Source/Reference
Hash
Generator
Review Status
Regression Status

Vectors are evidence artifacts, not informal examples.
