# AI Autonomy Promotion Policy

Autonomy promotion requires measurable evidence.

A0: advisory only.
A1: analysis.
A2: test generation.
A3: patch proposal.
A4: sandboxed patch execution with mandatory review.
A5: bounded repository changes with independent verification.
A6: bounded continuous operation with enforced policy gates.
A7: reserved; requires exceptional governance and evidence.

Security incidents cause immediate demotion. AI never becomes the security authority.
