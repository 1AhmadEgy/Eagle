# Controlled Self-Healing Loop

Observe → Detect → Reproduce → Propose → Patch → Sandbox Test → Security Test → Independent Verify → Evidence → Approval Gate → Merge/Release → Monitor → Regression.

Automatic production mutation is prohibited unless a separately approved policy explicitly permits it and all required gates pass.
