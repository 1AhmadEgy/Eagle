# Research Adoption Gate v2

Source → Authority Review → Security Review → Maturity → License → Maintenance → Compatibility → Threat Model → Prototype → Tests → ADR → Specification → Adoption Status.

Research is evidence/input, not automatic architecture.
