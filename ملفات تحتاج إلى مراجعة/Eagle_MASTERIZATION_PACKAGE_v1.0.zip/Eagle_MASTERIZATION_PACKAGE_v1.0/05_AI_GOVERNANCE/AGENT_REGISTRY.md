# Agent Registry

Roles: Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

Each agent record requires: ID, role, authority, tools, allowed data, forbidden data, allowed actions, forbidden actions, runtime/cost/tool-call limits, sandbox, approval requirement, evidence requirement, verifier, rollback, audit policy.
