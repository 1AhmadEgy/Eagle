# Controlled Self-Healing

Loop:
Observe → Detect → Investigate → Model → Generate → Test → Attack/Failure Injection → Fix → Verify → Regress → Stabilize → Document → Learn → Reassess.

Self-healing is permitted only inside explicit authority boundaries. Security-critical changes require approval and independent verification.
