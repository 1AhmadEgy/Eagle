# Eagle AI Governance

AI roles may include planning, analysis, detection, scenario generation, code assistance, RCA, and recommendation.

AI must not independently alter trust state, bypass authentication, recover secrets, delete protected data, modify cryptographic policy, approve its own findings, disable controls, or access arbitrary tools.

Deterministic policy remains authoritative.
