# Agent Verification

An agent is not trusted merely because its model is capable.

Verification requires deterministic policy checks, permission-bound tool access, adversarial evaluation, reproducibility where applicable, evidence generation, rollback capability, and independent verification for security-sensitive actions.
