# Model Evaluation

Track task accuracy, false-positive/false-negative behavior, security-policy violations, unsafe tool calls, reproducibility, regression escape rate, evidence quality, and rollback success.

No model metric alone establishes production safety.
