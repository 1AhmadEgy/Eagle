# Open Decisions Register

OI-001 exact Signal implementation/version
OI-002 PQXDH integration profile
OI-003 V1 transport boundary
OI-004 server ciphertext retention
OI-005 identity/device trust states
OI-006 device linking
OI-007 recovery protocol
OI-008 deletion guarantees

Each decision requires: context → options → security analysis → decision → consequences → ADR → affected specs → tests → verification.
