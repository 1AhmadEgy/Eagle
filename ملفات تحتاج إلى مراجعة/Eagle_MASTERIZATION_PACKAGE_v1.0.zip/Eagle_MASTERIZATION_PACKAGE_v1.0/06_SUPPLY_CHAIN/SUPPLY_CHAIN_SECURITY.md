# Supply Chain Security

Required controls: dependency pinning, vulnerability monitoring, SBOM, provenance, reproducible builds where feasible, signed releases, CI verification, license tracking, and review of third-party components.

Candidate tools/standards remain non-adopted until project-specific review and ADR approval.
