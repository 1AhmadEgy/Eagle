# Third-Party Component Registry

Fields: component, version, source, license, maintenance, advisories, platforms, purpose, security relevance, status, ADR, tests, evidence.

Presence in this registry does not imply adoption.
