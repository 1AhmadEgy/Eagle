# Eagle Security Kernel

## Purpose
Deterministic authority for trust, authentication/authorization, key handling policy, recovery policy, deletion policy, and security invariants.

## Boundary
AI, UI, telemetry, plugins, MCP tools, and convenience services cannot override kernel decisions.

## Principles
Fail closed; least privilege; explicit trust states; no custom cryptography; no implicit recovery bypass; no security decision based solely on AI output.

## Required evidence
Every security-state transition must be attributable to a policy/versioned decision and testable invariant.
