# Security Invariants

1. Unauthenticated actors cannot access protected session state.
2. Authorization is explicit and scoped.
3. Trust cannot be silently elevated.
4. Key material is never emitted to telemetry.
5. Recovery cannot silently bypass device trust policy.
6. Deletion policy cannot be disabled by ordinary application flow.
7. Protocol downgrade must be detected and rejected when policy requires.
8. AI cannot override deterministic security policy.
9. Security failures fail closed unless an explicit, reviewed exception exists.
10. Every invariant must map to tests and evidence before verification.
