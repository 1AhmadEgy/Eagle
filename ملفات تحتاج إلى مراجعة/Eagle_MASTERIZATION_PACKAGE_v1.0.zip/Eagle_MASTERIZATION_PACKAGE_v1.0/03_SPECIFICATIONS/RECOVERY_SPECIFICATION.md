# Recovery Specification — Controlled Draft

Separate identity/account recovery from data recovery.

Preferred early model: trusted-device-assisted transfer to a new trusted device, subject to explicit authentication and trust policy.

Exact protocol remains open decision OI-007 until specified, tested, and verified.
