# Device Trust Specification — Controlled Draft

Define device states, enrollment, attestation inputs, trust transitions, revocation, replacement, and downgrade resistance.

Platform-specific mechanisms are references until capability, policy, interoperability, and tests establish adoption.
