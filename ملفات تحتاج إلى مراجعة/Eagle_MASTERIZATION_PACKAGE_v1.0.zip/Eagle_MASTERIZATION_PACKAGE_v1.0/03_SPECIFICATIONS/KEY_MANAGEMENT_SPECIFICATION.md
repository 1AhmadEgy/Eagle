# Key Management Specification — Controlled Draft

Define key classes, lifecycle, storage boundary, rotation, compromise response, backup/recovery handling, zeroization expectations, and audit evidence.

No custom cryptographic construction is permitted.
