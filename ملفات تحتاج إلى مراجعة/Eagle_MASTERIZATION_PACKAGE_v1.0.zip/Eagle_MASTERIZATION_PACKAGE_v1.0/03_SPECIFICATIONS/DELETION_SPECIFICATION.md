# Deletion Specification — Controlled Draft

Deletion scope must cover database records, WAL/journals, caches, attachments, thumbnails, temporary files, metadata, indexes, key material, derived state, backups/restores, and forensic residuals.

Claims must distinguish logical deletion, cryptographic deletion, application/OS/filesystem behavior, backup behavior, and residual-data guarantees.

Exact guarantees remain open decision OI-008.
