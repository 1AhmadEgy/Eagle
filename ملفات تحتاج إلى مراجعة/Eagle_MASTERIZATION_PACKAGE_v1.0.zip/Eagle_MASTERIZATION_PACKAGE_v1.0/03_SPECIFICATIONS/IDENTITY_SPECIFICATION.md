# Identity Specification — Controlled Draft

Scope: identity lifecycle, device identity, account/device relationship, authentication, trust states, linking, revocation, and transitions.

This is a controlled specification skeleton. Exact production semantics remain gated by the open decisions registry.
