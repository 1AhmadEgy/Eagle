# Requirement Registry

Canonical record: REQ-ID, title, description, rationale, priority, source, security impact, affected components, acceptance criteria, implementation status, test IDs, verification evidence.

Statuses: PROPOSED, APPROVED, IN_PROGRESS, IMPLEMENTED, TESTED, VERIFIED, DEPRECATED, REJECTED.

No requirement is VERIFIED without linked evidence.
