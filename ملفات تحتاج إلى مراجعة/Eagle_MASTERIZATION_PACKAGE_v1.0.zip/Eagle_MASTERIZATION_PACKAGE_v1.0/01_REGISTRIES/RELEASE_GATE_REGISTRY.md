# Release Gate Registry

Gate chain:
1. Source and dependency review
2. Static analysis
3. Unit tests
4. Integration/protocol tests
5. Security tests
6. Fuzz/property/state-machine testing as applicable
7. Storage/deletion/recovery tests
8. Platform tests
9. Supply-chain checks
10. Build/provenance/SBOM/signing verification
11. Security review
12. Required external audit
13. Independent release verification

No failed P0 gate may be silently waived.
