# ADR Registry

ADR fields: ADR-ID, title, context, problem, options, decision, consequences, security impact, alternatives rejected, references, implementation, tests, status.

Statuses: PROPOSED, ACCEPTED, SUPERSEDED, DEPRECATED, REJECTED.

Initial tracked decisions include Rust core, Signal-family 1:1, minimal server trust, local-first sensitive state, deterministic security kernel, direct connectivity plus relay fallback, AI policy boundary, and V1/V2/V3 separation.
