# Security Findings Registry

Fields: SEC-ID, title, component, threat, severity, exploitability, impact, evidence, reproduction, fix, regression test, verification, status.

Statuses: OPEN, TRIAGED, IN_PROGRESS, FIXED, VERIFIED, ACCEPTED_RISK, CLOSED.

Stop-the-line findings must block progression until containment, investigation, fix, regression test, independent verification, and documentation are complete.
