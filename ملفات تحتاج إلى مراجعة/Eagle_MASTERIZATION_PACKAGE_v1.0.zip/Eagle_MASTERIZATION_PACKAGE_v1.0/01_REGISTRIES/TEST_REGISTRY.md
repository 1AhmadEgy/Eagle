# Test Registry

Fields: TEST-ID, requirement, component, type, environment, preconditions, input, expected, actual, evidence, result, regression.

Results: PASS, FAIL, BLOCKED, NOT_RUN, NOT_APPLICABLE.

A test result without reproducible evidence is not a verification claim.
