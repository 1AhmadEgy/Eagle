# Eagle Test Strategy

Test layers: unit, integration, protocol, interoperability, cryptographic, property-based, fuzz, state-machine, network/NAT/ICE, transport, storage, deletion, recovery, attestation/platform, performance, concurrency, failure injection, regression, supply chain, static analysis, dependency audit, and external security testing.

Test pipeline:
Governance → Orchestrator → Scenario Selection → Generator → Safety Preflight → Injector → SUT → Telemetry → Detector → Classifier → RCA → Remediation → Independent Verification → Regression → Evidence → Report.
