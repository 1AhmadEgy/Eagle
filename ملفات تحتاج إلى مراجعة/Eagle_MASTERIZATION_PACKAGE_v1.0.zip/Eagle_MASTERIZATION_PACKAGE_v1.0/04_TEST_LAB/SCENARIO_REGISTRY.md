# Scenario Registry

Scenario record: ID, domain, preconditions, actor, capability, trigger, sequence, expected behavior, security invariant, detection, containment, recovery, evidence, regression test, severity, likelihood, impact, dependencies, version, status, source, ADR, requirement, test case.
