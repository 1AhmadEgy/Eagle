# Test Matrix

Domains A–Z are tracked from normal operations through identity, crypto/PQ, messaging, server compromise, transport, storage/deletion, recovery, metadata privacy, platforms, telemetry, supply chain, build/release, AI, MCP/tools, abuse, performance, disaster recovery, governance, social engineering, and compound scenarios.

Each scenario must link to requirement, threat, expected invariant, detection, evidence, regression test, and status.
