# خارطة طريق V1 — Foundation

## P0 — يجب أن يسبق أي ادعاء أمني
1. Threat Model + Security Invariants.
2. ADR للتشفير وإدارة المفاتيح.
3. تعريف هوية الجهاز والحساب وحالة الثقة.
4. تعريف حدود metadata وعقد الخادم.
5. CI: build + tests + formatting + linting + dependency audit.

## P1 — النواة
1. Identity/session state machine.
2. Policy engine fail-closed.
3. Encrypted local storage abstraction.
4. Error model لا يكشف أسرارًا.
5. Key lifecycle.

## P2 — الاتصال
1. QUIC transport.
2. ICE/TURN كآلية وصول فقط.
3. فصل transport identity عن cryptographic identity.
4. Replay/downgrade protections.

## P3 — المراسلة
1. 1:1 session establishment.
2. Double Ratchet integration عبر مكتبة مراجعة.
3. Attachment encryption.
4. Offline queue مع metadata minimization.

## P4 — الاسترداد والحذف
1. Recovery protocol.
2. Device revocation.
3. Deletion semantics.
4. Backup/key destruction model.

## P5 — الاختبار والمراجعة
- Unit / integration / property tests.
- Protocol test vectors.
- Fuzzing للـ parsers وstate machines.
- Dependency/SBOM review.
- مراجعة أمنية مستقلة.
