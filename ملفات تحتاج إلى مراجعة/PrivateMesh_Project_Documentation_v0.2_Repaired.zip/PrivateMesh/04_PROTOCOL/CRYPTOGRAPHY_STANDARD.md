# معيار التشفير — Draft / ADR Required

## المبدأ
يُمنع ابتكار خوارزميات تشفير أو بروتوكولات خاصة بـ PrivateMesh.

## فصل الطبقات
1. **Establishment / Handshake:** بروتوكول جلسة محدد في ADR.
2. **Message Encryption:** Double Ratchet أو بديل موثّق ومراجع.
3. **Post-Quantum Components:** ML-KEM / ML-DSA / SLH-DSA عند الحاجة، وفق
   معايير NIST والنسخ المعتمدة من المكتبات.
4. **Key lifecycle:** توليد، تخزين، تدوير، إبطال، وحذف المفاتيح يجب أن تكون
   محددة بشكل مستقل عن اختيار الخوارزمية.

## متطلبات قبل التنفيذ
- تحديد threat model.
- تحديد cryptographic agility strategy.
- تحديد version pinning للمكتبات.
- اختبارات vectors رسمية.
- اختبار downgrade / replay / nonce misuse / key-compromise scenarios.
- مراجعة مستقلة قبل وصف النظام بأنه "secure" أو "production-ready".

## ممنوع
- تشفير مخصص.
- خلط أسماء المعايير بالبروتوكولات.
- اعتبار وجود QUIC/ICE/TURN ضمانًا للسرية أو الهوية.
