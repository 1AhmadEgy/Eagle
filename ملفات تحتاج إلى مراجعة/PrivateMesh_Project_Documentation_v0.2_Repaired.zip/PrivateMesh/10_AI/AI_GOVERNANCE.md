# حوكمة الذكاء الاصطناعي v0.2

## مسموح
- anomaly detection
- diagnostics
- log analysis بعد إزالة الأسرار
- اقتراحات للمستخدم/المشغل

## ممنوع
- تغيير Trust State.
- منح أو سحب صلاحيات مباشرة.
- استعادة أو استخراج الأسرار.
- تعطيل Policy Engine.
- تعديل cryptographic configuration وقت التشغيل.

## قاعدة تنفيذية
AI outputs تعامل كبيانات غير موثوقة (untrusted input). أي إجراء حساس يمر
بسياسة حتمية مستقلة عن النموذج، مع audit trail مناسب دون تسريب أسرار.
