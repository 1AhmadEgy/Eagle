//! Cryptographic boundary.
//!
//! No cryptographic algorithm is implemented in this module.
//! Approved primitives must be introduced through a reviewed ADR and
//! version-pinned, maintained libraries.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CryptoStatus {
    NotConfigured,
    Configured,
}

pub struct CryptoProvider {
    status: CryptoStatus,
}

impl CryptoProvider {
    pub const fn new() -> Self {
        Self { status: CryptoStatus::NotConfigured }
    }

    pub const fn status(&self) -> CryptoStatus {
        self.status
    }
}

impl Default for CryptoProvider {
    fn default() -> Self { Self::new() }
}
