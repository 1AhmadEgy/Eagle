//! Network boundary.
//!
//! Transport, ICE/TURN and peer discovery are deliberately kept outside
//! the security-policy implementation. Network reachability is never
//! treated as proof of identity or trust.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Transport {
    Quic,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PeerEndpoint {
    pub transport: Transport,
}
