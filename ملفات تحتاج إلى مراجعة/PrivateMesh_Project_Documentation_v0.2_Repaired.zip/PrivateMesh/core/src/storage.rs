//! Local encrypted-storage boundary.
//!
//! This module defines no plaintext persistence API. Storage implementations
//! must enforce encryption-at-rest and explicit deletion semantics before use.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StorageState {
    Locked,
    Ready,
}

pub struct SecureStore {
    state: StorageState,
}

impl SecureStore {
    pub const fn new() -> Self {
        Self { state: StorageState::Locked }
    }

    pub const fn state(&self) -> StorageState {
        self.state
    }
}

impl Default for SecureStore {
    fn default() -> Self { Self::new() }
}
