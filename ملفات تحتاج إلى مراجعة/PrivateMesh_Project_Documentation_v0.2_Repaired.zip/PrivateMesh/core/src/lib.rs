//! PrivateMesh core foundation.
//!
//! This crate intentionally contains interfaces and policy boundaries only.
//! Cryptographic and transport primitives must be supplied by reviewed,
//! maintained implementations; no custom cryptography is implemented here.

pub mod crypto;
pub mod network;
pub mod storage;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelState {
    Uninitialized,
    Ready,
    FailedClosed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelError {
    AlreadyInitialized,
    InitializationFailed,
}

pub struct Kernel {
    state: KernelState,
}

impl Kernel {
    pub const fn new() -> Self {
        Self { state: KernelState::Uninitialized }
    }

    pub fn initialize(&mut self) -> Result<(), KernelError> {
        match self.state {
            KernelState::Uninitialized => {
                // Real initialization will be added only after dependency/ADR review.
                self.state = KernelState::Ready;
                Ok(())
            }
            KernelState::Ready | KernelState::FailedClosed => Err(KernelError::AlreadyInitialized),
        }
    }

    pub const fn state(&self) -> KernelState {
        self.state
    }
}

impl Default for Kernel {
    fn default() -> Self { Self::new() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn kernel_starts_uninitialized() {
        assert_eq!(Kernel::new().state(), KernelState::Uninitialized);
    }

    #[test]
    fn initialization_is_explicit() {
        let mut kernel = Kernel::new();
        assert_eq!(kernel.initialize(), Ok(()));
        assert_eq!(kernel.state(), KernelState::Ready);
        assert_eq!(kernel.initialize(), Err(KernelError::AlreadyInitialized));
    }
}
