# Traceability Seed v1.0

| Chain | Current state | Gap |
|---|---|---|
| Source → Requirement | PARTIAL | populate source IDs and requirement links |
| Requirement → ADR | PARTIAL | map approved decisions |
| ADR → Specification | PARTIAL | link exact spec sections |
| Specification → Implementation | BLOCKED | production implementation not verified in current baseline |
| Implementation → Test | BLOCKED | requires source code/test execution |
| Test → Evidence | NOT_RUN | requires actual test artifacts |
| Evidence → Independent Verification | NOT_RUN | independent verifier required |
| Verification → Release Gate | BLOCKED | release evidence not present |
