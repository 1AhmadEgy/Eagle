# Master Test Gate Seed

No test execution is claimed by this package. These are gate definitions.

| TEST-GATE | Area | Minimum evidence | Status |
|---|---|---|---|
| TG-001 | identity/auth | reproducible positive + negative cases | NOT_RUN |
| TG-002 | crypto/session | protocol vectors + failure cases | NOT_RUN |
| TG-003 | PQXDH | conformance/interoperability/downgrade tests | NOT_RUN |
| TG-004 | transport | QUIC/ICE/TURN/NAT/failure/resource tests | NOT_RUN |
| TG-005 | storage | encryption/key protection/WAL/cache/temp tests | NOT_RUN |
| TG-006 | deletion | logical/crypto/app/backup/forensic-residual evidence | NOT_RUN |
| TG-007 | recovery | trusted-device transfer + abuse/rollback tests | NOT_RUN |
| TG-008 | mobile | MASVS/MASTG evidence across Android/iOS | NOT_RUN |
| TG-009 | AI/MCP | authorization, sandbox, injection, tool poisoning, excessive agency tests | NOT_RUN |
| TG-010 | supply chain | dependency audit, SBOM, provenance, signature verification | NOT_RUN |
| TG-011 | fuzz/property/state | reproducible corpus and regression artifacts | NOT_RUN |
| TG-012 | external audit | independent audit report and remediation evidence | BLOCKED |
