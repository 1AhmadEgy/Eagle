# Open Decision Closure Matrix

| OI | Decision | Required inputs | Required tests | Gate | Status |
|---|---|---|---|---|---|
| OI-001 | exact Signal implementation/version | official docs, version, advisories, license, maintenance | protocol/conformance/security/regression | P0 | OPEN |
| OI-002 | PQXDH integration profile | Signal PQXDH spec + implementation review | vectors/interoperability/downgrade/failure | P0 | OPEN |
| OI-003 | V1 transport boundary | QUIC/ICE/TURN scope + threat model | network/NAT/replay/resource exhaustion | P0/P1 | OPEN |
| OI-004 | server ciphertext retention | privacy model + server threat model | retention/deletion/compromise | P0 | OPEN |
| OI-005 | identity/device trust states | identity model + platform capabilities | auth/trust transitions/negative tests | P0 | OPEN |
| OI-006 | device linking | threat model + secure channel | linking/revocation/rollback | P0 | OPEN |
| OI-007 | recovery protocol | account-vs-data recovery separation | recovery abuse/rollback/lockout | P0 | OPEN |
| OI-008 | deletion guarantees | storage layout + OS/filesystem/backup semantics | DB/WAL/cache/backup/forensic residual tests | P0 | OPEN |
