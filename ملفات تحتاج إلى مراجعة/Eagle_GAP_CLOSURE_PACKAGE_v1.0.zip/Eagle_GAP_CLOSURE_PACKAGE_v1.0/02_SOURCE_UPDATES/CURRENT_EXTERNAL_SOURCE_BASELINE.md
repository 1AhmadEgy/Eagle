# Current External Source Baseline

## EXTERNAL_VERIFIED
- SLSA v1.2: Approved current specification; includes Source and Build tracks and provenance/attestation guidance.
- NIST SP 800-218 SSDF v1.1: Final.
- NIST SP 800-218 Rev.1 / SSDF v1.2: Draft as of the checked official NIST publication page; not to be treated as final.
- NIST SP 800-218A: Final community profile for secure development practices for Generative AI and dual-use foundation models.
- OWASP MASVS: current mobile security verification baseline; includes STORAGE, CRYPTO, AUTH, NETWORK, PLATFORM, CODE, RESILIENCE, PRIVACY control groups.

## Project action
Map these external sources into the Source Registry with source type, authority, version/date, project status, affected requirements, and tests. Adoption remains a project decision.
