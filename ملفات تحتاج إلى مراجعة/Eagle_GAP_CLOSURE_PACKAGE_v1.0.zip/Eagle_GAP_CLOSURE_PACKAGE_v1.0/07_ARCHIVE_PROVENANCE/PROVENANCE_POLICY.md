# Provenance Policy

- Preserve original packages and source files.
- Every generated package records its parent baseline.
- Do not overwrite historical artifacts without versioned replacement evidence.
- Archive comparison reports with hashes.
- A package can be canonical for a role without making all source material obsolete.

Parent baselines:
- Eagle_CORRECTED_ADDITIONAL_FILES_v1.0
- Eagle_MASTERIZATION_PACKAGE_v1.0
- Eagle_MASTERIZATION_COMPARISON_REPORT_v1.0
