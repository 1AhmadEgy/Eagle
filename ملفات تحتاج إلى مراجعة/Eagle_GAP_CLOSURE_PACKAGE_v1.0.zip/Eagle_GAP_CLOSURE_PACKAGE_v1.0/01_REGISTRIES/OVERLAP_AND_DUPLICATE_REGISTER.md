# Overlap / Duplicate Register v1.0

| ID | Items | Finding | Status | Required action |
|---|---|---|---|---|
| DUP-001 | Eagle_MASTER_REFERENCE_INDEX.md ↔ EAGLE_REFERENCE_INDEX_V2.md | heavy functional overlap; exact equality not established | PENDING | exact content/hash comparison; preserve both until resolved |
| DUP-002 | Eagle_MASTER_PROJECT_REFERENCE.md ↔ PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md | substantial overlap with different roles/terminology | PENDING | authority/role reconciliation via ADR/governance |
| DUP-003 | CORRECTED package ↔ MASTERIZATION package | no identical archive paths; functions redistributed/expanded | VERIFIED_FROM_SOURCE | retain both; map provenance, do not delete |
| DUP-004 | adoption status vocabularies | two vocabularies exist | VERIFIED_FROM_SOURCE | normalize by mapping, not silent replacement |
