# Conflict Register — Populated Seed v1.0

| ID | Topic | Current state | Security impact | Gate |
|---|---|---|---|---|
| CON-001 | Signal implementation/version | Open decision OI-001 | Critical | P0 |
| CON-002 | PQXDH integration profile | Open decision OI-002 | Critical | P0 |
| CON-003 | V1 transport boundary | Open decision OI-003 | High | P0/P1 |
| CON-004 | Server ciphertext retention | Open decision OI-004 | High | P0 |
| CON-005 | Identity/device trust states | Open decision OI-005 | Critical | P0 |
| CON-006 | Device linking | Open decision OI-006 | Critical | P0 |
| CON-007 | Recovery protocol | Open decision OI-007 | Critical | P0 |
| CON-008 | Deletion guarantees | Open decision OI-008 | High/Critical | P0 |
| CON-009 | Source/adoption status vocabulary | governance inconsistency | Medium | Governance gate |
