# Master File Registry — Populated Seed v1.0

Status: PARTIAL / EVIDENCE-BASED

| FILE-ID | File | Role | Status | Canonical/Relationship | Evidence |
|---|---|---|---|---|---|
| FILE-001 | Eagle_MASTER_REFERENCE_INDEX.md | master reference index | VERIFIED_FROM_SOURCE | canonical reference candidate | uploaded project reference |
| FILE-002 | Eagle_MASTER_PROJECT_REFERENCE.md | operational project reference | VERIFIED_FROM_SOURCE | canonical operational reference | uploaded project reference |
| FILE-003 | PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md | legacy/technical master reference | VERIFIED_FROM_SOURCE | preserve; reconcile through governance | uploaded project reference |
| FILE-004 | EAGLE_REFERENCE_INDEX_V2.md | source/reference index | VERIFIED_FROM_SOURCE | preserve; normalize with source registry | project reference context |
| FILE-005 | Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip | corrected registries/governance additions | VERIFIED_FROM_SOURCE | preserve as provenance package | archive inspection |
| FILE-006 | Eagle_MASTERIZATION_PACKAGE_v1.0.zip | masterization baseline | VERIFIED_FROM_SOURCE | current masterization baseline | archive inspection |
| FILE-007 | Eagle_MASTERIZATION_COMPARISON_REPORT_v1.0.md | comparison evidence/report | VERIFIED_FROM_SOURCE | supporting artifact | file exists in /mnt/data |

## Important
This is not a complete Library inventory. It is the currently verified seed inventory available in the working environment.
