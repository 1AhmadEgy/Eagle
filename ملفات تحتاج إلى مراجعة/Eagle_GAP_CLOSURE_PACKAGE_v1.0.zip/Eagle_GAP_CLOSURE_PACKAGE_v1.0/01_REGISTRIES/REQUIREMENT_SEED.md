# Requirement Seed — Evidence-Based

| REQ-ID | Requirement | Priority | Acceptance criterion | Status |
|---|---|---|---|---|
| REQ-SEC-001 | deterministic security policy is authoritative over AI | P0 | AI cannot alter trust/auth/recovery/deletion/crypto policy | APPROVED_BY_PROJECT_REFERENCE |
| REQ-SEC-002 | fail-closed behavior for security-critical ambiguity/failure | P0 | undefined/invalid security state rejects operation | APPROVED_BY_PROJECT_REFERENCE |
| REQ-SEC-003 | sensitive state remains local-first | P0 | server does not become authoritative holder of sensitive local state | APPROVED_BY_PROJECT_REFERENCE |
| REQ-SEC-004 | no custom cryptography | P0 | use reviewed standard protocols/implementations with explicit review | APPROVED_BY_PROJECT_REFERENCE |
| REQ-TEST-001 | no verification claim without reproducible evidence | P0 | every PASS/VERIFIED links evidence | APPROVED_BY_PROJECT_REFERENCE |
| REQ-REL-001 | external security audit required before production release | P0 | independent audit evidence linked to release gate | APPROVED_BY_PROJECT_REFERENCE |
