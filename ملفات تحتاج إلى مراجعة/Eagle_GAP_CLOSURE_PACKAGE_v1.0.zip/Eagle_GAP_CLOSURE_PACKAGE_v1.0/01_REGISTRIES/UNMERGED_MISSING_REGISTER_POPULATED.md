# Unmerged / Missing Register — Populated Seed v1.0

| ID | Missing/unmerged area | Target | Priority | Action | Status |
|---|---|---|---|---|---|
| MISS-001 | exact file-level reconciliation of master reference indexes | 01_REGISTRIES | P1 | hash + exact content diff | PENDING |
| MISS-002 | normalized source records from raw source repository | MASTER_SOURCE_REGISTRY | P1 | extract/normalize each source | PENDING |
| MISS-003 | requirements populated from accepted project decisions | REQUIREMENT_REGISTRY | P0/P1 | derive only from approved source/ADR | PENDING |
| MISS-004 | ADR-to-test links for open decisions | ADR/TEST registries | P0 | create decision-specific test gates | PENDING |
| MISS-005 | implementation evidence | TEST/EVIDENCE registries | P0 | blocked until source code exists | BLOCKED |
| MISS-006 | external audit evidence | RELEASE registry | P0 | required before production release | BLOCKED |
| MISS-007 | supply-chain artifact provenance/SBOM/signatures | SUPPLY_CHAIN | P0 | implement in CI/release | PENDING |
