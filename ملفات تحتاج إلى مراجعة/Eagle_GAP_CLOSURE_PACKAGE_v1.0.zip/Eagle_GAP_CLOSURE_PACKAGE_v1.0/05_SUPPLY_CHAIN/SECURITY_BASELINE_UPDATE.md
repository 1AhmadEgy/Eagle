# Supply Chain Security Baseline Update

## External baseline
1. SLSA 1.2 — Approved; use as provenance/source/build security reference.
2. NIST SP 800-218 SSDF 1.1 — Final baseline.
3. NIST SP 800-218A — Final AI secure-development profile, used where applicable to Eagle AI engineering.
4. OWASP MASVS/MASTG — mobile verification baseline.

## Required Eagle controls
- dependency pinning and audit
- SBOM (SPDX/CycloneDX as project-selected formats)
- build provenance and artifact signing
- reproducible/verified build strategy where feasible
- CI security checks
- vulnerability/advisory monitoring
- release verification

Adoption of a tool is not implied by listing it here.
