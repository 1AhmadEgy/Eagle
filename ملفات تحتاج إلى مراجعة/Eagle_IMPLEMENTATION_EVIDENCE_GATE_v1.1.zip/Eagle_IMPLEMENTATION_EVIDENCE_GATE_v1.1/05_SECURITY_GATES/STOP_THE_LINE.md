# Security Stop-the-Line Gate

Immediate STOP conditions:
- authentication/authorization bypass;
- trust-state bypass or ambiguous trust transition;
- key/secret leakage;
- plaintext leakage;
- cryptographic misuse or unreviewed custom cryptography;
- downgrade/capability-negotiation weakness;
- recovery bypass;
- deletion bypass or misleading deletion guarantee;
- tool/MCP authorization or sandbox escape;
- critical dependency/build/release compromise;
- unverifiable security-critical claim.

Flow: STOP → CONTAIN → INVESTIGATE → FIX → REGRESSION → INDEPENDENT VERIFY → DOCUMENT → RESUME.
