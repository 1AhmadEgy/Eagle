# Component Gate Matrix

| Component | Gate | Current status | Minimum evidence |
|---|---|---|---|
| Rust Core | implementation/build/tests | BLOCKED | commit + build + unit/integration + security evidence |
| Identity | lifecycle correctness | BLOCKED | implementation + state tests + negative tests |
| Device Trust | trust transitions | BLOCKED | platform implementation + downgrade/negative tests |
| Key Management | key lifecycle | BLOCKED | crypto/storage tests + leakage/destruction evidence |
| Session | PQXDH/ratchet | BLOCKED | exact library/version + vectors + interoperability + negative tests |
| Network | QUIC/ICE/TURN | BLOCKED | implementation + NAT/transport/interoperability tests |
| Storage | local sensitive state | BLOCKED | encryption + WAL/cache/temp/backup/deletion tests |
| Recovery | recovery protocol | BLOCKED | state machine + abuse/failure tests |
| Deletion | deletion guarantees | BLOCKED | residual/restore/backup evidence |
| Android | platform security | BLOCKED | app artifact + MASVS/MASTG evidence |
| Apple | platform security | BLOCKED | app artifact + platform security evidence |
| AI Governance | deterministic policy boundary | BLOCKED | agent/tool authorization tests |
| MCP/Tools | tool security gateway | BLOCKED | allowlist/schema/sandbox/audit tests |
| Supply Chain | release integrity | BLOCKED | SBOM + provenance + signing + verification |
