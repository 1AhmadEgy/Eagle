# Required Artifact Manifest

For each implementation component submit:

1. repository URL/path and exact commit/tag;
2. source paths;
3. build command and toolchain versions;
4. dependency manifest + lockfile;
5. generated SBOM;
6. static-analysis results;
7. unit/integration/protocol/negative/security test results as applicable;
8. logs and machine-readable result artifacts;
9. artifact hashes;
10. build provenance/attestation;
11. signing and verification evidence;
12. reviewer and independent verifier records;
13. environment details sufficient for reproduction.

No VERIFIED status without attributable evidence.
