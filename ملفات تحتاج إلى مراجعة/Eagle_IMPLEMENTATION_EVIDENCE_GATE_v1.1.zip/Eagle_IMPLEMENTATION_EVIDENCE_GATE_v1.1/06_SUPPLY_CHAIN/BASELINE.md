# Supply Chain Baseline

Current external baseline:
- SLSA 1.2 — Approved.
- NIST SP 800-218 / SSDF 1.1 — Final.
- NIST SP 800-218A — Final AI-focused SSDF Community Profile.
- NIST SP 800-218 Rev.1 / SSDF 1.2 — Initial Public Draft; not treated as a final normative baseline.

Required evidence remains: dependency pinning/lockfiles, advisory scanning, SBOM, provenance, signing, verification, CI enforcement, and reproducibility where required.
