# Requirement Verification Rules

A requirement may be marked VERIFIED only when:

- its specification is identified;
- the implementation artifact is identified by exact version/commit;
- required tests exist and have recorded results;
- evidence is reproducible and attributable;
- security-critical requirements have appropriate negative/security tests;
- independent verification is recorded.

Allowed states: PROPOSED, APPROVED, IN_PROGRESS, IMPLEMENTED, TESTED, VERIFIED, DEPRECATED, REJECTED.
