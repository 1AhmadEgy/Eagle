# Open Decision Gate

OI-001 exact Signal implementation/version — PENDING
OI-002 final PQXDH profile — PENDING
OI-003 V1 transport boundary — PENDING
OI-004 server ciphertext retention — PENDING
OI-005 recovery protocol — PENDING
OI-006 deletion guarantees — PENDING
OI-007 server retention policy — PENDING
OI-008 device trust states — PENDING

Each decision requires explicit decision record, security impact, implementation impact, and required tests before acceptance.
