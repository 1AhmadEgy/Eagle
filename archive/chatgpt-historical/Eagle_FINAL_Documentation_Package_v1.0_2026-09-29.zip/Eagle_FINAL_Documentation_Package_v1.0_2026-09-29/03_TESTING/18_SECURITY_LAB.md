# Security Lab
## Pipeline
Governance → Orchestrator → Scenario Selection → Scenario Generator → Safety Preflight → Injector → SUT → Telemetry → Detector → Classifier → RCA → Remediation → Independent Verification → Regression → Evidence → Report.

## Lab modes
Red / Blue / Purple.

## Safety
Tests are authorized, isolated and reproducible. Real user secrets/data are excluded.

## AI
AI may generate candidates and analyze results but cannot bypass safety controls or approve its own findings.
