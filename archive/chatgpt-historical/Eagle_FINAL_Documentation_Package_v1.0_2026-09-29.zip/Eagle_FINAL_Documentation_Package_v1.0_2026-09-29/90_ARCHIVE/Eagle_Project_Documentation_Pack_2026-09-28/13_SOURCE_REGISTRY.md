# Source Registry

## Project/reference documents
| Source | Classification | Role |
|---|---|---|
| EAGLE_REFERENCE_INDEX_V2.md | REFERENCE INDEX | compact source taxonomy |
| Eagle_MASTER_PROJECT_REFERENCE.md | PROJECT MASTER | conversation/document map |
| PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md | PROJECT MASTER | consolidated architecture/security reference |
| Eagle_MASTER_REFERENCE_INDEX.md | REFERENCE INDEX | technical source map |

## Research
| Source | Classification | Use |
|---|---|---|
| A Decade of GHOSTS in the Machine... | RESEARCH / ENGINEERING | observability, maintainability, realism, sustainment |
| DeepSeek _ Into the Unknown_.pdf | RESEARCH / TEST-LAB | cyber-range methodology, agents, scenarios, analytics |
| DeepSeek - إلى المجهول | RESEARCH / TEST-LAB NOTES | scenario lifecycle, lab structure, agent roles, templates |

## Mixed conversation/document dump
| Source | Classification | Rule |
|---|---|---|
| بالضبط_5362697558946016807.docx | MIXED PROJECT MATERIAL | mine for useful technical content; do not treat all embedded links/claims as authoritative |

## Navigation artifact
| Source | Classification |
|---|---|
| ChatGPT shared link.url | NAVIGATION POINTER only |

## Source status rule
Presence in the registry never means adoption.


## External verification — 2026-09-28

| Source | Authority | Verified point | Project use |
|---|---|---|---|
| Signal Double Ratchet Revision 4 | Signal | Current published Double Ratchet revision and PQXDH integration | protocol reference |
| Signal PQXDH specification | Signal | asynchronous initial key agreement and application parameters | protocol reference |
| NIST FIPS 203 | NIST | ML-KEM final standard + errata planning note | PQC reference |
| NIST FIPS 204 | NIST | ML-DSA final standard + 2026 errata planning note | PQC reference |
| NIST FIPS 205 | NIST | SLH-DSA final standard | PQC reference |
| RFC 9420 | IETF | MLS Proposed Standard | V2 candidate reference |
| RFC 9000 | IETF | QUIC v1 transport | transport reference |
| RFC 8445 / RFC 8863 | IETF | ICE NAT traversal and update | connectivity reference |
| RFC 8656 | IETF | current TURN specification replacing RFC 5766 | normative transport reference |
| OWASP MASVS / MASVS 2.1 | OWASP | mobile security controls incl. privacy and CycloneDX | test baseline |
| Android Keystore / StrongBox | Android Developers | hardware-backed key protection and constraints | platform security |
| Apple Secure Enclave / App Attest | Apple Developer | hardware-bound key protection and attestation workflow | platform security |
| OpenTelemetry sensitive-data guidance | OpenTelemetry | data minimization and instrumentation review | observability security |

### External-source rule
هذه المراجع تتحكم في صحة وصف المعيار نفسه، لكنها لا تعتمد اختيار التقنية داخل PrivateMesh. الاعتماد الداخلي يتطلب ADR ودليل اختبار.
