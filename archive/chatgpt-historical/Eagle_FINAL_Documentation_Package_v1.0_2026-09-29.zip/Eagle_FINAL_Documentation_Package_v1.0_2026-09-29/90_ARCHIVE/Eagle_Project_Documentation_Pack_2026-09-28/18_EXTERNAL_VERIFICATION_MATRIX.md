# Eagle / PrivateMesh — External Verification Matrix
Version: 0.3-draft
Date: 2026-09-28

> هذه الوثيقة تفصل بين ما ورد في مصادر المشروع وما تم التحقق منه خارجيًا من مصادر رسمية حديثة. لا تُعد أي نتيجة خارجية قرار اعتماد للمشروع.

## 1. Cryptography / Protocol

| Area | External verification | Project impact | Status |
|---|---|---|---|
| Signal Double Ratchet | Signal publishes Revision 4 (2025-11-04), including Double Ratchet plus newer ratchet variants and explicit PQXDH integration guidance. | يجب تحديث سجل المصدر؛ لا يعني ذلك اعتماد Triple Ratchet أو تغيير V1 تلقائيًا. | VERIFIED-REFERENCE |
| PQXDH | Signal specification remains a reference for asynchronous initial key agreement; it explicitly states implementation parameters must be chosen by the application. | ADR-0001/0002-style protocol integration decision remains necessary. | VERIFIED-REFERENCE |
| NIST FIPS 203 | ML-KEM is finalized; NIST page includes a 2025 planning note about an issue to be corrected in a future revision. | سجل الإصدار/errata يجب أن يكون جزءًا من dependency/crypto registry. | VERIFIED-REFERENCE |
| NIST FIPS 204 | ML-DSA is finalized; NIST page has a 2026 planning note for minor corrections. | يجب تتبع errata ولا يكفي تسجيل "FIPS 204" فقط. | VERIFIED-REFERENCE |
| NIST FIPS 205 | SLH-DSA is finalized. | مرجع PQ signature بديل؛ لا اعتماد تلقائي. | VERIFIED-REFERENCE |
| MLS / RFC 9420 | RFC 9420 is an IETF Standards Track Proposed Standard for asynchronous group key establishment with FS and PCS. | يدعم إبقاء MLS كـ V2 candidate، مع ADR منفصل. | VERIFIED-REFERENCE |

## 2. Transport / Connectivity

| Area | External verification | Project impact | Status |
|---|---|---|---|
| QUIC | RFC 9000 defines QUIC v1 as a secure general-purpose transport; TLS integration is specified separately. | يجب الحفاظ على الفصل بين E2E protocol وtransport. | VERIFIED-REFERENCE |
| ICE | RFC 8445 defines ICE for NAT traversal and uses STUN/TURN; it was updated by RFC 8863. | سجل RFC update ضمن transport registry. | VERIFIED-REFERENCE |
| TURN | RFC 5766 is obsolete; RFC 8656 supersedes it. | **تصحيح مهم:** لا ينبغي أن يكون RFC 5766 هو المرجع النهائي في المواصفة. | ACTION REQUIRED |

## 3. Mobile Security

| Area | External verification | Project impact | Status |
|---|---|---|---|
| OWASP MASVS | Current MASVS covers STORAGE, CRYPTO, AUTH, NETWORK, PLATFORM, CODE, RESILIENCE and PRIVACY. | تحديث baseline الاختبارات ليتضمن MASVS-PRIVACY. | VERIFIED-REFERENCE |
| MASVS 2.1 | OWASP documents MASVS-PRIVACY and CycloneDX support. | ربط privacy + SBOM ضمن traceability. | VERIFIED-REFERENCE |
| Android StrongBox | Android documents StrongBox KeyMint availability and algorithm/performance constraints. | لا تفرض StrongBox كمتطلب مطلق؛ اجعله capability + policy decision. | VERIFIED-REFERENCE |
| Apple Secure Enclave | Apple documents hardware-isolated private-key protection. | يجب فصل "key stored in Keychain" عن "key operations protected by Secure Enclave". | VERIFIED-REFERENCE |
| Apple App Attest | Apple documents Secure-Enclave-bound keys, attestation/assertions, server validation and platform-specific limitations. | يجب تحويل App Attest إلى requirement/test cases عند اعتماد attestation. | VERIFIED-REFERENCE |

## 4. Observability

| Area | External verification | Project impact | Status |
|---|---|---|---|
| OpenTelemetry sensitive data | OTel explicitly places responsibility on implementers for sensitive-data handling and recommends data minimization. | يدعم منع plaintext/secrets من telemetry، مع مراجعة instrumentation نفسها. | VERIFIED-REFERENCE |

## 5. Required documentation corrections

1. Replace obsolete TURN reference with RFC 8656 in the normative source registry.
2. Add explicit source-version/errata fields to crypto dependencies.
3. Add MASVS-PRIVACY and CycloneDX/SBOM mapping to mobile/security traceability.
4. Add platform capability matrices for StrongBox and App Attest rather than unconditional assumptions.
5. Add instrumentation review to the observability security gate.
6. Add a "verified reference date" field to every normative source entry.

## 6. Evidence rule

External verification establishes factual source status only. Architecture adoption still requires:

`External Source → Project Relevance → Threat Model → ADR → Specification → Test → Evidence → Approval`
