# Open Issues / Decisions Required

Priority:
- P0 = blocks architecture/specification
- P1 = blocks V1 implementation
- P2 = hardening/future

| ID | Issue | Priority | Needed output |
|---|---|---:|---|
| OI-001 | exact Signal implementation/version | P0 | ADR + library record |
| OI-002 | PQXDH integration profile | P0 | protocol decision |
| OI-003 | V1 transport boundary | P0 | ADR-0006 |
| OI-004 | server ciphertext retention | P0 | ADR-0008 + data contract |
| OI-005 | identity/device trust states | P0 | state machine |
| OI-006 | device linking protocol | P0 | security specification |
| OI-007 | recovery protocol | P0 | threat model + spec |
| OI-008 | deletion guarantees | P0 | deletion specification |
| OI-009 | Web security model | P1 | platform security decision |
| OI-010 | Desktop security model | P1 | platform security decision |
| OI-011 | final local database/encryption design | P1 | storage ADR |
| OI-012 | final observability stack | P1 | telemetry ADR |
| OI-013 | MLS adoption | P2 | V2 ADR |
| OI-014 | PQ migration/hybrid design | P2 | V2 ADR |
| OI-015 | AI/MCP production scope | P2 | governance ADR |
| OI-016 | external audit scope | P1 | audit plan |

## Rule
No open issue should be “solved” by changing a master document alone. It must close through evidence and/or ADR.
