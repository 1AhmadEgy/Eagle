# Eagle / PrivateMesh — Decision & Release Gates
Version: 0.3-draft
Date: 2026-09-28

## Gate G0 — Source Integrity
- Every normative source has canonical URL.
- Version/revision/date recorded.
- Obsolete/superseded status recorded.
- Errata/updates tracked.

## Gate G1 — Architecture Freeze
Required before implementation:
- V1 platform scope
- V1 transport boundary
- server retention contract
- identity/device trust state machine
- recovery boundary
- deletion semantics

## Gate G2 — Crypto Freeze
Required:
- exact protocol revision
- exact implementation/library
- parameter profile
- serialization/interoperability profile
- key lifecycle
- migration/crypto-agility plan
- negative/conformance vectors

## Gate G3 — Mobile Security
Required:
- MASVS mapping
- secure storage tests
- authentication/authorization tests
- network tests
- resilience/attestation tests where applicable
- privacy controls
- SBOM mapping

## Gate G4 — Observability Safety
Required:
- telemetry schema review
- sensitive-field denylist
- instrumentation review
- redaction/minimization tests
- retention/access policy

## Gate G5 — Supply Chain
Required:
- pinned dependencies
- advisory review
- SBOM
- provenance
- signed artifacts
- reproducibility target
- release verification

## Gate G6 — Security Verification
Required:
- unit/integration/protocol tests
- state-machine/property/fuzz testing
- network/NAT tests
- storage/deletion/recovery tests
- platform security tests
- independent security review

## Gate G7 — Production
No production security claim until G0-G6 have evidence and unresolved P0/P1 blockers are explicitly accepted by authorized project governance.
