# Supply Chain & Release Security

## Required controls
```text
Dependency Pinning
+
Dependency Auditing
+
SBOM
+
Provenance
+
Reproducible Builds
+
Signed Releases
+
CI Verification
+
Vulnerability Monitoring
```

## Reference frameworks
- SLSA
- SPDX
- CycloneDX
- OpenSSF

## Release pipeline
```text
Source
 ↓
Review
 ↓
Static Analysis
 ↓
Dependency Audit
 ↓
Unit Tests
 ↓
Integration Tests
 ↓
Protocol Tests
 ↓
Fuzzing
 ↓
Security Tests
 ↓
Build
 ↓
SBOM
 ↓
Provenance
 ↓
Artifact Signing
 ↓
Release Verification
```

## Dependency record
Every adopted dependency must record:
- name
- repository
- official documentation
- license
- version
- maintenance state
- security advisories
- supported platforms
- integration status
- test status
- adoption status

## Adoption gate
`Source → Security Review → Maturity → License → Maintenance → Interoperability → Threat Model → PoC → Tests → Decision`
