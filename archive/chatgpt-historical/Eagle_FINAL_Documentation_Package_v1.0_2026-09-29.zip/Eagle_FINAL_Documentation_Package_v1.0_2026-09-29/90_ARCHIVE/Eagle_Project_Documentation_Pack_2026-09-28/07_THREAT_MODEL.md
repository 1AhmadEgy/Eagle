# Threat Model

## Adversaries
- network attacker
- malicious peer
- compromised endpoint
- stolen device
- malicious local process
- malicious plugin/tool
- supply-chain compromise
- metadata observer
- replay attacker
- downgrade attacker
- identity substitution
- key compromise

## Required domains
Identity, authentication, device trust, key management, session establishment, messaging, transport, NAT traversal, server compromise, client compromise, storage, deletion, recovery, supply chain, build system, dependencies, updates, telemetry, AI, tools/MCP, social engineering and metadata.

## Security properties
- confidentiality
- integrity
- authentication
- forward secrecy where applicable
- replay protection
- downgrade resistance
- key separation
- least privilege
- auditability

## Threat-model method
For each component:
1. assets
2. trust boundaries
3. entry points
4. attacker capabilities
5. abuse cases
6. security controls
7. residual risk
8. test evidence
9. owner
10. status

## Stop-the-line triggers
Development pauses for:
- cryptographic flaw
- trust bypass
- authentication bypass
- identity ambiguity
- key leakage
- plaintext leakage
- recovery bypass
- deletion-policy bypass
- downgrade vulnerability
- critical dependency issue
- build/release compromise
- serious supply-chain issue
- critical security-policy ambiguity
