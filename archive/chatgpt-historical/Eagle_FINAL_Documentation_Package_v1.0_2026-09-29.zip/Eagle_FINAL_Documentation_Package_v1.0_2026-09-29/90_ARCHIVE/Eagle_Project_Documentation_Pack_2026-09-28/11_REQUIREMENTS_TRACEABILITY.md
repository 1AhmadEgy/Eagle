# Requirements & Traceability

## Requirement classes
- Functional
- Security
- Privacy
- Protocol
- Platform
- Storage
- Recovery
- Deletion
- Network
- AI/MCP
- Supply Chain
- Observability
- QA/Release

## Requirement ID format
`REQ-<DOMAIN>-<NUMBER>`

Example:
`REQ-SEC-001`

## Required fields
- ID
- title
- statement
- rationale
- source
- security impact
- priority
- acceptance criteria
- implementation reference
- test reference
- evidence
- status

## Traceability
```text
REQ
 ↓
ADR
 ↓
SPEC
 ↓
CODE
 ↓
TEST
 ↓
EVIDENCE
```

## Initial baseline requirements
- REQ-SEC-001: Security Kernel must be deterministic and fail-closed.
- REQ-SEC-002: AI must not override critical security policy.
- REQ-CRYPTO-001: No custom cryptographic primitive.
- REQ-CRYPTO-002: Exact adopted protocol/library must be recorded before production.
- REQ-SERVER-001: Server must not receive plaintext message content.
- REQ-STORAGE-001: Sensitive local state must have explicit protection and deletion semantics.
- REQ-TEST-001: Security-critical features require negative and regression tests.
- REQ-SUPPLY-001: Release artifacts require dependency/SBOM/provenance controls.
- REQ-DOC-001: Major architectural decisions require ADRs.
