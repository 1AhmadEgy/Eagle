# System Architecture

## 1. Target model
```text
                    PrivateMesh Protocol
                           |
                    PrivateMesh Core
                           |
        +------------------+------------------+
        |                  |                  |
      Android             iOS        Desktop/Web*
        |                  |                  |
        +------------------+------------------+
                           |
                  Minimal PrivateMesh Services
                           |
              Identity / Rendezvous / Delivery
```

`*` Desktop/Web scope requires a separate security-model decision before production use.

## 2. Core
Preferred implementation direction: Rust.

Core responsibilities:
- protocol state machines
- identity
- session state
- cryptographic interfaces
- trust decisions
- recovery/deletion policy
- deterministic security policy
- serialization/model boundaries

## 3. Layering
```text
Application
  ↓
E2E Protocol
  ↓
Session / State Machines
  ↓
Transport
  ↓
Network / NAT Traversal
  ↓
Local Secure Storage
```

## 4. Components
### Client
UI + OS integration + local storage + user-facing security state.

### Security Kernel
Small, deterministic, versioned, auditable, testable and fail-closed.

### Network
Direct connectivity, QUIC, ICE and TURN are layered concerns. WebRTC is a separate real-time media concern.

### Services
Minimal services must not receive plaintext message content or private decryption keys.

## 5. Trust boundaries
Every component must specify:
- responsibility
- inputs/outputs
- trust level
- required permissions
- failure behavior
- test boundary

## 6. Architectural correction
Do not create separate protocol/crypto implementations for every platform. Platform bindings integrate the common core.

## 7. Explicitly unresolved
- exact Signal implementation/library
- exact PQXDH integration
- final group protocol
- final server delivery/retention model
- Web/Desktop security model
- final observability stack
