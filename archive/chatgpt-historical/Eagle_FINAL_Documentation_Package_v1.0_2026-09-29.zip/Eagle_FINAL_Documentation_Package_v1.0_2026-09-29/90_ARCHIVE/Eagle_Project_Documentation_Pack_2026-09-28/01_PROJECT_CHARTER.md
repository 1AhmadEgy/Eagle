# Eagle / PrivateMesh — Project Charter

## Identity
- Project: Eagle / النسر
- Technical name: PrivateMesh
- Nature: privacy-first, security-first, cross-platform communication ecosystem.
- Core direction: Rust-based common core with platform-specific clients/integration.

## Non-negotiable principles
1. Security First
2. Privacy by Design
3. Protocol First
4. Fail Closed
5. Least Privilege
6. Minimal Server Trust
7. Local Ownership of Sensitive State
8. Deterministic Security Policy
9. Auditable Decisions
10. No Security by Obscurity
11. No Reinvention of Standard Cryptography
12. Test Before Release
13. External Security Audit Before Production
14. No V2 before V1 is stable/security-tested
15. AI cannot override security policy
16. Claims must not exceed actual guarantees

## Scope baseline
### In scope
- Identity and devices
- 1:1 secure messaging
- Sessions and key lifecycle
- Local sensitive-state protection
- Minimal server services
- Network/transport foundation
- Security testing and evidence
- Cross-platform core architecture

### Deferred/candidate
- MLS/group messaging
- broader PQ migration
- privacy routing/Tor
- desktop/web security model
- advanced AI/MCP/SOC automation
- advanced monitoring
- external SDK ecosystem

## Project definition
The project is an ecosystem, not an Android-only application. The protocol/core is the authority; clients are implementations.

## Important status rule
Statements in this document are project normalization proposals unless an ADR marks them `ACCEPTED`.
