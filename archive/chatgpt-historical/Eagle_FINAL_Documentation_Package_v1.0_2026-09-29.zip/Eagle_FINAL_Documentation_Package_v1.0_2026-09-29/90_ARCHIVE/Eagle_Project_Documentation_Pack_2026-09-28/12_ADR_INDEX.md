# ADR Index

Status: baseline; decisions below are proposed/recorded from the source set and must be promoted through explicit ADRs.

| ADR | Topic | Status |
|---|---|---|
| ADR-0001 | Rust common core | PROPOSED/REFERENCE |
| ADR-0002 | Minimal server trust | PROPOSED |
| ADR-0003 | Signal-family 1:1 architecture | REFERENCE / UNDER_REVIEW |
| ADR-0004 | PQC migration strategy | OPEN |
| ADR-0005 | MLS/group messaging | DEFERRED / V2 CANDIDATE |
| ADR-0006 | QUIC/ICE/TURN layering | PROPOSED |
| ADR-0007 | Web/Desktop security model | OPEN |
| ADR-0008 | Server ciphertext delivery retention | OPEN |
| ADR-0009 | Device linking | OPEN |
| ADR-0010 | Recovery model | OPEN |
| ADR-0011 | Deletion guarantees | OPEN |
| ADR-0012 | Observability stack | OPEN |
| ADR-0013 | AI security boundary | PROPOSED |
| ADR-0014 | MCP/tool permission gateway | PROPOSED |
| ADR-0015 | Supply-chain baseline | PROPOSED |

## Rule
No “accepted” label without:
`context + options + decision + consequences + security impact + references + tests + status`.
