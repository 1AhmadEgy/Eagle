# Security Architecture

## Security Kernel
```text
Input
  ↓
Validation
  ↓
Policy
  ↓
Decision
  ├─ ALLOW
  ├─ DENY
  ├─ REQUIRE_APPROVAL
  └─ QUARANTINE
```

Properties:
- deterministic
- versioned
- auditable
- testable
- fail-closed
- independent of AI judgment

## AI boundary
AI may:
- detect anomalies
- analyze telemetry
- classify evidence
- recommend remediation
- generate test candidates

AI must not independently:
- grant trust
- accept identity keys
- recover secrets
- override deletion policy
- change critical crypto policy
- grant higher privilege
- disable controls
- approve its own security finding

## Cryptography principle
Do not invent cryptography. Use standards and mature implementations after review.

## 1:1 protocol reference
Project references Signal-family architecture:
- PQXDH
- Double Ratchet
- authenticated encryption

Status: `REFERENCE / CANDIDATE`, not final implementation approval.

## PQC
NIST FIPS 203/204/205 are reference standards. Selection requires maturity, interoperability, side-channel considerations, performance, sizes, migration strategy and independent review.

## Platform protection
Android:
- Keystore
- hardware-backed protection where available
- StrongBox where appropriate
- attestation as a separate signal

Apple:
- Keychain
- Secure Enclave where appropriate
- App Attest as an integrity signal, not a universal compromise guarantee

## Observability
Telemetry must never export:
- plaintext messages
- private keys
- recovery codes
- session secrets
- unnecessary sensitive authentication material

Use safe identifiers/hashes for evidence references.
