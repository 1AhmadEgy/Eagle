# Server Data Contract

## Core principle
The server is a minimal service layer, not the holder of plaintext conversation history.

## Must not own
- plaintext messages
- plaintext attachments
- private identity keys
- session encryption keys
- local decryption keys
- recovery secrets sufficient by themselves to restore protected data

## May need
- account/authentication identifiers
- public identity information
- public/prekey material
- rendezvous/discovery metadata
- delivery/transport metadata
- abuse/rate-limit/security metadata

## Every server-side field must have
`purpose / sensitivity / retention / access / deletion / audit`

## Important unresolved point
The source set contains two formulations:
1. “server is not message storage / no message history”
2. encrypted message delivery/storage appears in research/conversation material.

Normalization proposal:
- V1 server should be rendezvous/prekey/delivery infrastructure.
- If offline delivery requires ciphertext queues, define them as transient encrypted delivery buffers with explicit TTL and deletion semantics, not “message history”.
- Any durable ciphertext store requires an ADR and retention specification.

This is a design proposal, not an accepted decision.
