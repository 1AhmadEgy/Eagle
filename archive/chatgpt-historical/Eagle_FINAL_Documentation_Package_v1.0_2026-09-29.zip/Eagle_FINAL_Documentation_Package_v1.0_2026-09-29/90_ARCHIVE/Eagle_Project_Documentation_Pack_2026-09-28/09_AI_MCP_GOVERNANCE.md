# AI / MCP / Tool Governance

## Boundary
AI is an assistant to analysis and testing, not the final security authority.

## Allowed classes
- detection
- classification
- analysis
- recommendation
- test generation
- evidence summarization
- developer assistance

## Forbidden autonomous powers
- bypass authentication
- change trust state
- recover secrets
- alter critical crypto policy
- delete protected data outside policy
- disable controls
- unrestricted tool execution
- self-approve security findings

## Tool execution pipeline
```text
Tool Request
 ↓
Authentication
 ↓
Authorization
 ↓
Allowlist
 ↓
Schema Validation
 ↓
Argument Validation
 ↓
Sandbox
 ↓
Rate Limit
 ↓
Audit
 ↓
Execution
```

## Threats to test
- prompt injection
- tool poisoning
- argument injection
- confused deputy
- excessive agency
- data exfiltration
- privilege escalation
- cross-tool contamination

## Governance rule
Every tool needs:
- owner
- purpose
- inputs
- outputs
- permissions
- allowed environments
- rate limits
- logging policy
- failure behavior
- revocation method
- test cases

## AI model/provider independence
The source material proposes an AI gateway/adapter approach so the system is not inherently coupled to one AI provider. This remains a candidate architecture until formalized by ADR.
