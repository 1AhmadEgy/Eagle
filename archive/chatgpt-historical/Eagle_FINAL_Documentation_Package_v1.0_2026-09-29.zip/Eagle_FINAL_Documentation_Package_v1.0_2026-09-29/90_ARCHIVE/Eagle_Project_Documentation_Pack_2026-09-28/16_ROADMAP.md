# Roadmap

## V1 — Foundation
Proposed baseline:
- identity
- authentication
- 1:1 messaging
- Signal-family protocol integration
- local encrypted storage
- device trust integration
- minimal server
- deletion foundation
- test foundation

Transport details must be frozen by ADR.

## V1.x — Connectivity & hardening
Candidate:
- P2P
- ICE
- QUIC
- TURN fallback
- recovery
- device transfer
- attestation hardening
- release hardening

## V2 — Hardening & scale
Candidate:
- MLS/OpenMLS
- broader PQ migration
- privacy routing
- advanced privacy controls
- desktop
- web where security model is suitable
- SDK
- advanced monitoring

## V3 — AI & governance
Candidate:
- AI anomaly detection
- MCP security gateway
- controlled automation
- SOC integrations
- advanced governance
- cryptographic migration

## Gate
Each transition:
`implementation → tests → security review → audit gate`
