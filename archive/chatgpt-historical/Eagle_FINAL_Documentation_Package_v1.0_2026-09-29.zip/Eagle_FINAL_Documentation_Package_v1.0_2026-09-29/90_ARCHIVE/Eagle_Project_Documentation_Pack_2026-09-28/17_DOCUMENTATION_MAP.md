# Recommended Repository Documentation Map

```text
docs/
├── 00-master/
│   └── MASTER_INDEX.md
├── 01-governance/
│   ├── PROJECT_CHARTER.md
│   ├── ADR_INDEX.md
│   └── CHANGELOG.md
├── 02-architecture/
│   ├── SYSTEM_ARCHITECTURE.md
│   ├── SECURITY_ARCHITECTURE.md
│   └── TRUST_BOUNDARIES.md
├── 03-protocol/
│   ├── PROTOCOL_SPECIFICATION.md
│   ├── IDENTITY_SPECIFICATION.md
│   ├── SESSION_SPECIFICATION.md
│   └── MESSAGE_FORMAT.md
├── 04-server/
│   └── SERVER_DATA_CONTRACT.md
├── 05-storage/
│   ├── STORAGE_SPECIFICATION.md
│   ├── DELETION_SPECIFICATION.md
│   └── RECOVERY_SPECIFICATION.md
├── 06-security/
│   ├── THREAT_MODEL.md
│   ├── SECURITY_REQUIREMENTS.md
│   └── SECURITY_FINDINGS/
├── 07-testing/
│   ├── TEST_STRATEGY.md
│   ├── TEST_MATRIX.md
│   ├── TEST_VECTORS/
│   └── TEST_LAB/
├── 08-ai/
│   ├── AI_GOVERNANCE.md
│   └── MCP_SECURITY.md
├── 09-supply-chain/
│   ├── DEPENDENCY_REGISTRY.md
│   ├── SBOM.md
│   └── RELEASE_SECURITY.md
├── 10-research/
│   └── SOURCE_REGISTRY.md
└── 99-archive/
```

## Rule
Implementation documentation may reference these documents, but must not silently redefine them.
