# PrivateMesh Protocol Specification — Draft Skeleton

Status: `DRAFT / NOT CONFORMANCE-READY`

## 1. Scope
Define exactly what the protocol guarantees and what it does not.

## 2. Terminology
Account, Identity, Device, Session, Prekey, Message, Attachment, Relay, Trusted Device, Recovery.

## 3. Security invariants
- confidentiality
- integrity
- authentication
- forward secrecy where applicable
- replay protection
- downgrade resistance
- key separation
- least privilege
- auditability

## 4. Identity model
```text
Username
  ↓
Public Identity
  ↓
Device Identity
  ↓
Session
  ↓
Ephemeral / Ratcheted Keys
```

## 5. Session establishment
Reference: Signal-family / PQXDH + Double Ratchet.
Exact version/library and interoperability profile must be decided by ADR.

## 6. Message format
To be specified:
- version
- sender/device reference
- recipient/device reference
- message type
- ciphertext
- associated-data semantics
- identifiers
- delivery metadata
- error semantics

## 7. State machines
Required:
- session
- message
- device
- transport
- recovery
- deletion

## 8. Network
Separate:
- application E2E protocol
- transport
- NAT traversal
- relay

QUIC ≠ E2E protocol.
ICE ≠ transport.
TURN ≠ permission to store plaintext.

## 9. Groups
MLS / RFC 9420 is a V2 candidate, not automatic adoption.

## 10. Attachments
Proposed pattern:
`local file → random file key → encrypt → encrypted blob → storage`
The exact envelope and key-distribution format requires a dedicated specification.

## 11. Deletion
Must define logical deletion, cryptographic deletion, application deletion, caches, temporary files, WAL/journals, backups and forensic limitations.

## 12. Recovery
Identity/account recovery must be separated from data recovery.

## 13. Compatibility
Specify:
- protocol version
- capability negotiation
- downgrade protection
- migration
- conformance vectors

## 14. Conformance gate
No final protocol claim before:
`Specification + test vectors + interoperability + negative tests + independent review`.
