# Test Strategy & Security Lab

## Test pyramid
- unit
- integration
- protocol
- interoperability
- cryptographic
- property-based
- fuzz
- state-machine
- network
- NAT/ICE
- transport
- storage
- deletion
- recovery
- attestation
- platform
- performance
- concurrency
- failure injection
- regression
- supply-chain
- static analysis
- dependency audit
- penetration testing
- external security audit

## Lab workflow
```text
Governance
 ↓
Orchestrator
 ↓
Scenario Selection
 ↓
Scenario Generator
 ↓
Safety Preflight
 ↓
Injector
 ↓
System Under Test
 ↓
Telemetry
 ↓
Detector
 ↓
Classifier
 ↓
RCA
 ↓
Remediation
 ↓
Independent Verification
 ↓
Regression
 ↓
Evidence
 ↓
Report
```

## Agent roles
Core roles from the supplied research:
- Orchestrator
- Generator
- Injector
- Detector
- Classifier
- Root Cause Analyst
- Remediator
- Verifier
- Regression Curator
- Governance
- Coverage Curator
- Safety Guard

No agent gets unrestricted production authority.

## Scenario lifecycle
`Scenario → Simulation → Analysis → Remediation → Stabilization → Verification → Regression → Learning`

## Lab safety
- synthetic data only
- no production credentials
- no real private keys
- strict isolation
- no unrestricted tool access
- monitored exports
- critical actions require policy control/human approval

## Research use
The DeepSeek/cyber-range material is treated as methodology reference for scenario generation, fault injection, detection, RCA, remediation, verification, regression and governance.

The GHOSTS paper is treated as engineering/process reference for realism, observability, maintainability, documentation, dependency management and long-term sustainment.

Neither source is a PrivateMesh protocol specification.
