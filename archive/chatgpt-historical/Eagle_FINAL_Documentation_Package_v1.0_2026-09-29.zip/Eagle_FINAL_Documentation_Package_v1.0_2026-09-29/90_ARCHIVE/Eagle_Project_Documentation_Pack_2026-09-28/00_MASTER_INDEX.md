# Eagle / PrivateMesh — Master Documentation Index
Version: 0.3-draft | Date: 2026-09-28

## 1. Purpose
هذه الحزمة هي طبقة التوثيق المنظمة للمشروع. وهي لا تلغي المصادر الأصلية؛ بل تفصل بينها وبين القرارات والمواصفات والتنفيذ والاختبارات.

القاعدة الحاكمة:
`Source → Evidence → Review → ADR/Decision → Specification → Implementation → Test → Verification → Documentation → Release`

## 2. Authority
1. Standards / RFCs / official platform security documentation
2. Official documentation of adopted libraries/projects
3. Peer-reviewed or institutional research
4. Security advisories / independent audits
5. Project ADRs
6. Project specifications
7. Implementation
8. Discussion/history

## 3. Document status
- `REFERENCE`: مصدر أو مرجع.
- `CANDIDATE`: مرشح يحتاج مراجعة/PoC.
- `PROPOSED`: اقتراح تصميمي لم يُعتمد.
- `ACCEPTED`: قرار مشروع مسجل.
- `IMPLEMENTED`: نُفذ.
- `VERIFIED`: اجتاز دليل التحقق.
- `DEPRECATED / REPLACED / REJECTED`: حالات الإيقاف أو الاستبدال.

## 4. Core documents
| ID | Document | Role |
|---|---|---|
| 00 | MASTER_INDEX | الفهرس الأعلى |
| 01 | PROJECT_CHARTER | هوية المشروع والمبادئ والنطاق |
| 02 | SYSTEM_ARCHITECTURE | المعمارية وحدود المكونات |
| 03 | SECURITY_ARCHITECTURE | Security Kernel وTrust Boundaries |
| 04 | PROTOCOL_SPECIFICATION_DRAFT | مواصفة البروتوكول قيد البناء |
| 05 | IDENTITY_SESSION_RECOVERY | الهوية والأجهزة والجلسات والاستعادة |
| 06 | SERVER_DATA_CONTRACT | ما يملكه الخادم وما لا يملكه |
| 07 | THREAT_MODEL | التهديدات والضمانات والحدود |
| 08 | TEST_STRATEGY_AND_LAB | استراتيجية الاختبار والمختبر |
| 09 | AI_MCP_GOVERNANCE | حدود AI وMCP والأدوات |
| 10 | SUPPLY_CHAIN_RELEASE | الاعتماديات والبناء والإصدار |
| 11 | REQUIREMENTS_TRACEABILITY | المتطلبات والتتبع |
| 12 | ADR_INDEX | سجل القرارات |
| 13 | SOURCE_REGISTRY | سجل المصادر والاعتماد |
| 14 | AUDIT_REPORT | نتيجة الفحص الحالي |
| 15 | OPEN_ISSUES | الفجوات والقرارات المطلوبة |
| 16 | ROADMAP | خارطة V1/V1.x/V2/V3 |
| 17 | DOCUMENTATION_MAP | خريطة المستودع المقترحة |
| 18 | EXTERNAL_VERIFICATION_MATRIX | تحقق خارجي حديث للمراجع |
| 19 | DECISION_GATES | بوابات القرار والإصدار |

## 5. Templates
- templates/ADR_TEMPLATE.md
- templates/REQUIREMENT_TEMPLATE.md
- templates/SECURITY_FINDING_TEMPLATE.md
- templates/TEST_CASE_TEMPLATE.md
- templates/SCENARIO_TEMPLATE.yml
- templates/EVIDENCE_TEMPLATE.md

## 6. Source files supplied for this review
- EAGLE_REFERENCE_INDEX_V2.md
- Eagle_MASTER_PROJECT_REFERENCE.md
- PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md
- Eagle_MASTER_REFERENCE_INDEX.md
- DeepSeek _ Into the Unknown_1790580016074.pdf
- DeepSeek - إلى المجهول
- A-Decade-of-GHOSTS-in-the-Machine-From-Cyber-Range-Realism-to-Cognitive-Missio_MoudN97.pdf
- بالضبط_5362697558946016807.docx
- ChatGPT shared link.url

## 7. Golden rule
لا تتحول أي تقنية إلى جزء من PrivateMesh لمجرد ظهورها في بحث أو محادثة. يجب أن يكون لها غرض، مصدر، مراجعة، قرار، اختبار، ودليل.
