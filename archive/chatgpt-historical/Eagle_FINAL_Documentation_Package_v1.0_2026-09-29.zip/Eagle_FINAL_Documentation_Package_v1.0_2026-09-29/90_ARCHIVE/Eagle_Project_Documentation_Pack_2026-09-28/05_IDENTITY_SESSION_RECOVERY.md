# Identity / Device / Session / Recovery

## Identity separation
Do not use one undifferentiated “user key”.

Conceptual model:
```text
Account
 ├─ Public Identity
 ├─ Device 1
 │   ├─ Device Identity
 │   ├─ Session State
 │   └─ Prekeys
 ├─ Device 2
 └─ ...
```

## Trust states
Candidate states:
- unverified
- verified
- suspicious
- blocked
- recovery
- key-change

Exact state machine is still `OPEN`.

## Device linking
A new device must not receive sensitive key material through an unauthenticated server workflow.

Required design stages:
1. Existing trusted device
2. Secure pairing
3. New-device authentication
4. Key provisioning
5. Trust-state activation
6. Audit/evidence
7. Regression coverage

## Recovery
Separate:
- account/identity recovery
- data recovery

Early preferred pattern from the reference material:
`Trusted Device → Device-to-Device Transfer → New Trusted Device`

Any cloud backup or server-assisted recovery requires a separate threat model.

## Key lifecycle
For every key type specify:
- purpose
- generation
- storage
- use
- rotation
- revocation
- destruction
- recovery implications
- test vectors

## Unresolved
- exact trust-state model
- exact device-transfer protocol
- backup architecture
- recovery guarantees
