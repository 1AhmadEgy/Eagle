# 01_MASTER_BASELINE.md

# Eagle / PrivateMesh — Master Baseline

## الرؤية
PrivateMesh نظام اتصال خاص، security-first/privacy-first/local-first، مع تقليل ثقة الخادم، ونواة مشتركة موجهة نحو Rust، وعملاء Android وiOS.

Eagle طبقة هندسة وحوكمة وأمن واختبار وذكاء فوق PrivateMesh، وليست جزءاً من Security Kernel.

## المبادئ
- لا plaintext للرسائل على الخادم.
- لا private keys أو session secrets في telemetry.
- AI لا يملك تلقائياً صلاحيات الثقة أو التشفير أو الاسترداد أو الحذف المحمي.
- لا اعتماد لأداة/مكتبة/نموذج لمجرد ظهوره في البحث.
- كل قرار حساس يحتاج مصدراً وتهديداً واختباراً ودليلاً.
- لا ادعاء بحذف مطلق دون ضمان قابل للدفاع.
- فصل Transport Security عن E2E Message Security.
- فصل Account/Identity Recovery عن Data Recovery.

## دورة العمل
Source → Requirement → Security Claim → Threat → Control → Architecture/ADR → Specification → Implementation → Test → Finding → Patch → Independent Verification → Regression → Evidence → Release Gate

## V1
Identity, Authentication, 1:1 Messaging, PQXDH reference, Double Ratchet reference, local encrypted storage, server rendezvous/prekey support, direct transport foundation, deletion semantics, Android/iOS, testing foundation.

## V1.x
P2P, ICE, QUIC, TURN fallback, recovery, device transfer, attestation hardening, release hardening.

## V2 candidates
MLS/RFC 9420, broader PQ migration, privacy routing, additional platforms, advanced privacy controls.

## V3 candidates
Security Intelligence, AI-assisted analysis, MCP security gateway, advanced governance and security automation.

## غير المحسوم
exact Signal implementation/version; PQXDH profile; final crypto library; V1 transport boundary; server ciphertext retention; device trust/linking; recovery protocol; deletion guarantees; Web/Desktop security model; local DB/encryption configuration; observability; MLS adoption; PQ migration; AI/MCP production scope; external audit scope.


# 02_ARCHITECTURE.md

# System Architecture Baseline

PrivateMesh:
Identity → Device Trust → Session/Crypto → Messaging → Storage → Transport → Server/Rendezvous → Platform Security

Eagle:
Governance → Evidence/Traceability → Security Intelligence → Test/Cyber Lab → AI/MCP Governance → Supply Chain → Continuous Improvement

Trust boundary:
الخادم لا يملك plaintext messages, plaintext attachments, private identity keys, session encryption keys, أو مفاتيح فك التشفير المحلية.

يمكن أن توجد بيانات account/auth/public identity/prekey/rendezvous/delivery/abuse metadata وفق القرار النهائي، وأي ciphertext delivery buffer يجب أن يكون مؤقتاً وTTL-limited إذا تم اعتماده.

الفصل الإجباري:
Transport ≠ Session ≠ Message Encryption ≠ Identity ≠ Metadata.


# 03_SECURITY.md

# Security Baseline

## Security invariants
- لا device يصبح VERIFIED دون مسار تحقق محدد.
- لا downgrade غير مصرح.
- private keys/session secrets خارج telemetry.
- crypto choices versioned وقابلة للتتبع.
- لا plaintext message history على الخادم.
- deletion يغطي DB/WAL/cache/attachments/temp/metadata/indexes/key material/derived state.
- لا claim للحذف المطلق دون evidence.

## Threat domains
Identity, Authentication, Device Trust, Key Management, Session Establishment, Messaging, Transport, NAT Traversal, Server Compromise, Client Compromise, Storage, Deletion, Recovery, Supply Chain, Build, Dependencies, Updates, Telemetry, AI, MCP, Social Engineering, Metadata.

## Compound scenarios
stolen phone + PIN; client+server compromise; recorded traffic + future PQ; malicious dependency + compromised CI; TURN compromise + metadata correlation; backup theft + recovery abuse; prompt injection + privileged tool; database corruption + deletion crash + backup restore.


# 04_PROTOCOL.md

# Protocol Specification Baseline

المواصفة النهائية يجب أن تغطي:
Scope, Terminology, Security Invariants, Identity, Keys, Prekeys, Session Establishment, PQXDH, Double Ratchet, Message Format, Serialization, State Machines, P2P, ICE/QUIC, TURN, Offline, Delivery, Ordering, Replay, Deletion, Recovery, Device Transfer, Server API, Errors, Version Negotiation, Downgrade Protection, Capability Negotiation, Test Vectors, Interoperability, Conformance.

الحالة:
Signal PQXDH = reference.
Signal Double Ratchet = reference؛ implementation/version غير مجمد.
MLS/RFC 9420 = V2 candidate.
NIST FIPS 203/204/205 = normative PQC references.
QUIC RFC 9000 = transport reference.
ICE RFC 8445 = connectivity reference.
TURN RFC 8656 = current TURN reference.

هذه المراجع لا تعني اعتماد مكتبة تنفيذية بعينها.


# 05_TEST_LAB.md

# Security / Engineering Test Lab

Governance
→ Orchestrator
→ Scenario Selection
→ Scenario Generator
→ Safety Preflight
→ Injector
→ System Under Test
→ Telemetry
→ Detector
→ Classifier
→ RCA
→ Remediation
→ Independent Verification
→ Regression
→ Evidence
→ Report

Test classes:
unit, integration, protocol, interoperability, cryptographic, property-based, fuzzing, state-machine, network/NAT/ICE, storage/deletion/recovery, attestation, concurrency, failure injection, regression, static/dependency/security, penetration testing, external audit.

Stop-the-line:
crypto flaw, trust bypass, auth bypass, key leakage, plaintext leakage, recovery bypass, deletion-policy bypass, downgrade vulnerability, critical dependency issue, build/release compromise, serious supply-chain issue, security-policy ambiguity.


# 06_AI_MCP.md

# Eagle AI / MCP Governance

AI خارج Security Kernel.

AI can:
detect, classify, analyze, recommend, generate test candidates, assist engineering.

AI cannot automatically:
alter trust state, bypass authentication, recover secrets, delete protected data, modify crypto policy, approve its own finding, disable controls, access arbitrary tools.

Agent roles:
Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

Autonomy:
A0 analysis; A1 recommendation; A2 sandbox; A3 patch/PR generation; A4 testing; A5 low-risk verified auto-fix; A6 approval-required; A7 sensitive production actions prohibited by default.

MCP:
Authentication → Authorization → Allowlist → Schema Validation → Argument Validation → Sandbox → Rate Limit → Audit → Execution.


# 07_GOVERNANCE.md

# Governance / Traceability

Decision gates:
G0 Source Integrity
G1 Architecture Freeze
G2 Crypto Freeze
G3 Mobile Security
G4 Observability Safety
G5 Supply Chain
G6 Security Verification
G7 Production

ADR register:
ADR-0001 V1 protocol baseline — PROPOSED
ADR-0002 TURN RFC 8656 — ACCEPTED AS REFERENCE
ADR-0003 server ciphertext retention — PROPOSED
ADR-0004 device trust state machine — PROPOSED
ADR-0005 recovery separation — PROPOSED
ADR-0006 deletion guarantee layers — PROPOSED
ADR-0007 platform capability policy — PROPOSED
ADR-0008 observability data minimization — PROPOSED

Open issues:
OI-001 Signal implementation/version
OI-002 PQXDH integration
OI-003 V1 transport
OI-004 ciphertext retention
OI-005 device trust
OI-006 device linking
OI-007 recovery
OI-008 deletion
OI-009 Web security
OI-010 Desktop security
OI-011 local DB/encryption
OI-012 observability
OI-013 MLS
OI-014 PQ migration
OI-015 AI/MCP production
OI-016 external audit


# 08_OPERATIONS.md

# Operations / Supply Chain / Observability

Telemetry uses allowlists and data minimization. Deny by default:
plaintext messages, private keys, session secrets, recovery secrets, plaintext attachments, unnecessary PII.

Supply chain:
Dependency Pinning + Audit + SBOM + Provenance + Reproducible Builds + Signed Releases + CI Verification + Vulnerability Monitoring.

Release:
Review → Static → Dependency Audit → Unit → Integration → Protocol → Fuzz → Security → Build → SBOM → Provenance → Signing → Release Verification.


# 09_RESEARCH_POLICY.md

# Research Usage Policy

GHOSTS:
مرجع منهجي للـcyber-range، الواقعية الكافية، observability، modularity، dependency management، documentation، maintainability، reproducibility، orchestration. ليس مواصفة لبروتوكول PrivateMesh.

مواد DeepSeek/cyber-range:
مرجع لمنهجية Preparation → Scenario Building → Simulation/Injection → Analysis → Repair → Continuous Learning → Automation → Continuous Improvement.

DOCX المختلط:
مصدر اكتشاف وأفكار وروابط؛ ليس authority واحدة، ويجب إعادة تصنيف عناصره قبل اعتمادها.

Research → Review → Threat Model → Prototype → Tests → Decision.


# 10_COMPREHENSIVE_AUDIT.md

# Comprehensive Audit — 2026-09-29

## نقاط القوة
- security-first/privacy-first/local-first واضحة.
- فصل Eagle عن PrivateMesh واضح.
- threat domains واسعة.
- recovery/deletion مصنفان كمجالات حساسة.
- test-lab lifecycle واضح.
- supply-chain controls محددة.
- non-adoption rule موجود.
- source priority/status model موجود.
- decision gates موجودة.
- المراجع الخارجية الأساسية محددة.

## الفجوات
1. لا يوجد source code؛ implementation verification غير ممكن.
2. protocol profile يحتاج freeze.
3. crypto implementation/version غير محسوم.
4. server ciphertext retention يحتاج قرار نهائي.
5. device trust/linking يحتاج specification.
6. recovery يحتاج protocol/evidence.
7. deletion يحتاج guarantees قابلة للاختبار.
8. observability يحتاج instrumentation design نهائي.
9. Android/iOS capability matrix يحتاج finalization.
10. UI/UX يحتاج design system ومواصفات تنفيذية.
11. traceability تحتاج لاحقاً linkage إلى الكود والاختبارات.
12. AI/MCP production scope غير محسوم.
13. external audit scope غير محسوم.

## الحالة
Architecture/security baseline: STRONG FOUNDATION
Reference set: EXTERNALLY CHECKED BASELINE
Specifications: INCOMPLETE / NEED FREEZE
Implementation: NOT PRESENT
Production readiness: NOT CLEARED

## المسار التالي
Architecture Freeze → Crypto Freeze → Protocol Conformance → Core implementation → Android/iOS → test execution → independent verification → external audit → release gates.


# 11_SCENARIO_TEMPLATE.md

# Scenario Template
Scenario ID:
Domain:
Actor:
Preconditions:
Capability:
Trigger:
Sequence:
Expected Behavior:
Security Invariant:
Detection:
Containment:
Recovery:
Evidence:
Regression Test:
Severity:
Likelihood:
Impact:
Dependencies:
Version:
Status:
Source:
ADR:
Requirement:
Test Case:


# 12_ADR_TEMPLATE.md

# ADR Template
ADR ID:
Title:
Status:
Date:
Owner:

## Context
## Decision
## Alternatives
## Security Impact
## Privacy Impact
## Threats
## Requirements
## Tests
## Evidence
## Rollback
## Approval


# README.md

# Eagle / PrivateMesh — Baseline Engineering Package
إصدار 2026-09-29

الحالة الحالية: وثائق ومخططات ومراجع وأبحاث وقرارات ومسودات. لا يوجد كود مصدر تنفيذي في baseline الحالي.

الهدف: تحويل المادة المتراكمة إلى baseline هندسي منظم جاهز لاحقاً لمرحلة البرمجة، مع تتبع:
Requirement → Security Claim → Threat → Control → Design → Test → Evidence → Independent Verification → Release Gate

الحالات: VERIFIED / PROPOSED / UNDER_REVIEW / UNKNOWN / CANDIDATE / REJECTED / DEPRECATED / ARCHIVED
