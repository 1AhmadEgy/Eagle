# Eagle / PrivateMesh — Master Baseline

## الرؤية
PrivateMesh نظام اتصال خاص، security-first/privacy-first/local-first، مع تقليل ثقة الخادم، ونواة مشتركة موجهة نحو Rust، وعملاء Android وiOS.

Eagle طبقة هندسة وحوكمة وأمن واختبار وذكاء فوق PrivateMesh، وليست جزءاً من Security Kernel.

## المبادئ
- لا plaintext للرسائل على الخادم.
- لا private keys أو session secrets في telemetry.
- AI لا يملك تلقائياً صلاحيات الثقة أو التشفير أو الاسترداد أو الحذف المحمي.
- لا اعتماد لأداة/مكتبة/نموذج لمجرد ظهوره في البحث.
- كل قرار حساس يحتاج مصدراً وتهديداً واختباراً ودليلاً.
- لا ادعاء بحذف مطلق دون ضمان قابل للدفاع.
- فصل Transport Security عن E2E Message Security.
- فصل Account/Identity Recovery عن Data Recovery.

## دورة العمل
Source → Requirement → Security Claim → Threat → Control → Architecture/ADR → Specification → Implementation → Test → Finding → Patch → Independent Verification → Regression → Evidence → Release Gate

## V1
Identity, Authentication, 1:1 Messaging, PQXDH reference, Double Ratchet reference, local encrypted storage, server rendezvous/prekey support, direct transport foundation, deletion semantics, Android/iOS, testing foundation.

## V1.x
P2P, ICE, QUIC, TURN fallback, recovery, device transfer, attestation hardening, release hardening.

## V2 candidates
MLS/RFC 9420, broader PQ migration, privacy routing, additional platforms, advanced privacy controls.

## V3 candidates
Security Intelligence, AI-assisted analysis, MCP security gateway, advanced governance and security automation.

## غير المحسوم
exact Signal implementation/version; PQXDH profile; final crypto library; V1 transport boundary; server ciphertext retention; device trust/linking; recovery protocol; deletion guarantees; Web/Desktop security model; local DB/encryption configuration; observability; MLS adoption; PQ migration; AI/MCP production scope; external audit scope.
