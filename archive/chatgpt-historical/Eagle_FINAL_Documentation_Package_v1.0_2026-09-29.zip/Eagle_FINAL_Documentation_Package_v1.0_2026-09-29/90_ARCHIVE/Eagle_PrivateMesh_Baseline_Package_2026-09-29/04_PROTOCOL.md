# Protocol Specification Baseline

المواصفة النهائية يجب أن تغطي:
Scope, Terminology, Security Invariants, Identity, Keys, Prekeys, Session Establishment, PQXDH, Double Ratchet, Message Format, Serialization, State Machines, P2P, ICE/QUIC, TURN, Offline, Delivery, Ordering, Replay, Deletion, Recovery, Device Transfer, Server API, Errors, Version Negotiation, Downgrade Protection, Capability Negotiation, Test Vectors, Interoperability, Conformance.

الحالة:
Signal PQXDH = reference.
Signal Double Ratchet = reference؛ implementation/version غير مجمد.
MLS/RFC 9420 = V2 candidate.
NIST FIPS 203/204/205 = normative PQC references.
QUIC RFC 9000 = transport reference.
ICE RFC 8445 = connectivity reference.
TURN RFC 8656 = current TURN reference.

هذه المراجع لا تعني اعتماد مكتبة تنفيذية بعينها.
