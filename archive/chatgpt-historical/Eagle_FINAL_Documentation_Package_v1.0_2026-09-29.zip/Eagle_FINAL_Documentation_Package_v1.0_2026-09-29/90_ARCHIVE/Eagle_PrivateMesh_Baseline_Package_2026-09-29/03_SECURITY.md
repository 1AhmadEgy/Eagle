# Security Baseline

## Security invariants
- لا device يصبح VERIFIED دون مسار تحقق محدد.
- لا downgrade غير مصرح.
- private keys/session secrets خارج telemetry.
- crypto choices versioned وقابلة للتتبع.
- لا plaintext message history على الخادم.
- deletion يغطي DB/WAL/cache/attachments/temp/metadata/indexes/key material/derived state.
- لا claim للحذف المطلق دون evidence.

## Threat domains
Identity, Authentication, Device Trust, Key Management, Session Establishment, Messaging, Transport, NAT Traversal, Server Compromise, Client Compromise, Storage, Deletion, Recovery, Supply Chain, Build, Dependencies, Updates, Telemetry, AI, MCP, Social Engineering, Metadata.

## Compound scenarios
stolen phone + PIN; client+server compromise; recorded traffic + future PQ; malicious dependency + compromised CI; TURN compromise + metadata correlation; backup theft + recovery abuse; prompt injection + privileged tool; database corruption + deletion crash + backup restore.
