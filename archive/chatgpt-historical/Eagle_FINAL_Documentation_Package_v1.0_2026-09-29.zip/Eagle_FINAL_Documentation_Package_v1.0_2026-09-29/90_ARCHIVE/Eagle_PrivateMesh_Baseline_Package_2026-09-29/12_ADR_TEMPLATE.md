# ADR Template
ADR ID:
Title:
Status:
Date:
Owner:

## Context
## Decision
## Alternatives
## Security Impact
## Privacy Impact
## Threats
## Requirements
## Tests
## Evidence
## Rollback
## Approval
