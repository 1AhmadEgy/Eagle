# Research Usage Policy

GHOSTS:
مرجع منهجي للـcyber-range، الواقعية الكافية، observability، modularity، dependency management، documentation، maintainability، reproducibility، orchestration. ليس مواصفة لبروتوكول PrivateMesh.

مواد DeepSeek/cyber-range:
مرجع لمنهجية Preparation → Scenario Building → Simulation/Injection → Analysis → Repair → Continuous Learning → Automation → Continuous Improvement.

DOCX المختلط:
مصدر اكتشاف وأفكار وروابط؛ ليس authority واحدة، ويجب إعادة تصنيف عناصره قبل اعتمادها.

Research → Review → Threat Model → Prototype → Tests → Decision.
