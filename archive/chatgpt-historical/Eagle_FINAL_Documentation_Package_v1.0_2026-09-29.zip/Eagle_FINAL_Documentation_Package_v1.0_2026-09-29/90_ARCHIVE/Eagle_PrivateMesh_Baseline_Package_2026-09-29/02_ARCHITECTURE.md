# System Architecture Baseline

PrivateMesh:
Identity → Device Trust → Session/Crypto → Messaging → Storage → Transport → Server/Rendezvous → Platform Security

Eagle:
Governance → Evidence/Traceability → Security Intelligence → Test/Cyber Lab → AI/MCP Governance → Supply Chain → Continuous Improvement

Trust boundary:
الخادم لا يملك plaintext messages, plaintext attachments, private identity keys, session encryption keys, أو مفاتيح فك التشفير المحلية.

يمكن أن توجد بيانات account/auth/public identity/prekey/rendezvous/delivery/abuse metadata وفق القرار النهائي، وأي ciphertext delivery buffer يجب أن يكون مؤقتاً وTTL-limited إذا تم اعتماده.

الفصل الإجباري:
Transport ≠ Session ≠ Message Encryption ≠ Identity ≠ Metadata.
