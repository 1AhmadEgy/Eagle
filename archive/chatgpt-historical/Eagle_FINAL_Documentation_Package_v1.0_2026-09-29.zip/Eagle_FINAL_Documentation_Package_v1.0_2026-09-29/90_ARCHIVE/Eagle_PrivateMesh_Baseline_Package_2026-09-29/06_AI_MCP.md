# Eagle AI / MCP Governance

AI خارج Security Kernel.

AI can:
detect, classify, analyze, recommend, generate test candidates, assist engineering.

AI cannot automatically:
alter trust state, bypass authentication, recover secrets, delete protected data, modify crypto policy, approve its own finding, disable controls, access arbitrary tools.

Agent roles:
Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

Autonomy:
A0 analysis; A1 recommendation; A2 sandbox; A3 patch/PR generation; A4 testing; A5 low-risk verified auto-fix; A6 approval-required; A7 sensitive production actions prohibited by default.

MCP:
Authentication → Authorization → Allowlist → Schema Validation → Argument Validation → Sandbox → Rate Limit → Audit → Execution.
