# Governance / Traceability

Decision gates:
G0 Source Integrity
G1 Architecture Freeze
G2 Crypto Freeze
G3 Mobile Security
G4 Observability Safety
G5 Supply Chain
G6 Security Verification
G7 Production

ADR register:
ADR-0001 V1 protocol baseline — PROPOSED
ADR-0002 TURN RFC 8656 — ACCEPTED AS REFERENCE
ADR-0003 server ciphertext retention — PROPOSED
ADR-0004 device trust state machine — PROPOSED
ADR-0005 recovery separation — PROPOSED
ADR-0006 deletion guarantee layers — PROPOSED
ADR-0007 platform capability policy — PROPOSED
ADR-0008 observability data minimization — PROPOSED

Open issues:
OI-001 Signal implementation/version
OI-002 PQXDH integration
OI-003 V1 transport
OI-004 ciphertext retention
OI-005 device trust
OI-006 device linking
OI-007 recovery
OI-008 deletion
OI-009 Web security
OI-010 Desktop security
OI-011 local DB/encryption
OI-012 observability
OI-013 MLS
OI-014 PQ migration
OI-015 AI/MCP production
OI-016 external audit
