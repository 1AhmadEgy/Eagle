# Operations / Supply Chain / Observability

Telemetry uses allowlists and data minimization. Deny by default:
plaintext messages, private keys, session secrets, recovery secrets, plaintext attachments, unnecessary PII.

Supply chain:
Dependency Pinning + Audit + SBOM + Provenance + Reproducible Builds + Signed Releases + CI Verification + Vulnerability Monitoring.

Release:
Review → Static → Dependency Audit → Unit → Integration → Protocol → Fuzz → Security → Build → SBOM → Provenance → Signing → Release Verification.
