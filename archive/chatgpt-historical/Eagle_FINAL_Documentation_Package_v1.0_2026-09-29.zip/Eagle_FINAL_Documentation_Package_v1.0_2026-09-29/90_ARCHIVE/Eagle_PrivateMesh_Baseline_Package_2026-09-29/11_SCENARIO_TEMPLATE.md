# Scenario Template
Scenario ID:
Domain:
Actor:
Preconditions:
Capability:
Trigger:
Sequence:
Expected Behavior:
Security Invariant:
Detection:
Containment:
Recovery:
Evidence:
Regression Test:
Severity:
Likelihood:
Impact:
Dependencies:
Version:
Status:
Source:
ADR:
Requirement:
Test Case:
