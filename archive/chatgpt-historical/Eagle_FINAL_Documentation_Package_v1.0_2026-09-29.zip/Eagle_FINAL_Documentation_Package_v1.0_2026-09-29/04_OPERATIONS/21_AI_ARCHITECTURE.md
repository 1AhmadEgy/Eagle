# AI Architecture
## Boundary
AI is outside the Security Kernel.

## Allowed
Detection, classification, analysis, recommendation, candidate test generation, documentation assistance, controlled code generation.

## Forbidden without explicit governed mechanism
Changing trust state, crypto policy, auth policy, deleting protected data, disabling controls, accessing arbitrary tools, approving own findings.

## Agent model
Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

## Autonomy
A0–A7; sensitive actions require approval and deterministic verification.

## AI evaluation
Prompt injection, tool misuse, privilege escalation, leakage, false positives/negatives, inconsistency, memory/context poisoning, telemetry poisoning, model drift and regression.
