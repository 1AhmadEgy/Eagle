# FINAL Documentation Version Diff Matrix

| From | To | Files From | Files To | Added paths | Removed paths | Changed same-path contents | Same content hashes |
|---|---|---:|---:|---:|---:|---:|---:|
| Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip | Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip | 156 | 99 | 15 | 72 | 3 | 85 |
| Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip | Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip | 99 | 101 | 2 | 0 | 0 | 99 |
| Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip | Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip | 101 | 104 | 3 | 0 | 0 | 101 |
| Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip | Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip | 104 | 105 | 105 | 104 | 0 | 103 |

## Interpretation
- v1.0 → v2.0 is a substantive restructuring: 15 added paths, 72 removed paths, 3 same-path content changes.
- v2.0 → v2.1 and v2.1 → v2.2 add control/audit material without same-path content changes in the compared files.
- v2.2 → v2.3 is primarily a path/layout reorganization: the content-hash comparison shows the carried content is largely preserved despite path changes.
- The `-1` filenames are handled separately and must not be treated as versions.