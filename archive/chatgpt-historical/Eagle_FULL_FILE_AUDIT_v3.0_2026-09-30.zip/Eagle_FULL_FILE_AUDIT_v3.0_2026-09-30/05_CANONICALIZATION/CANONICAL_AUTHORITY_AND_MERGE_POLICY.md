# Canonicalization & Merge Policy v3.0

## Principle

The user confirmed that repeated uploads can produce similar filenames. Therefore:

**Filename similarity is never sufficient to delete or merge a file.**

## Identity levels

1. Archive SHA-256 — exact archive identity.
2. Internal file SHA-256 — exact byte identity.
3. Path/version comparison — structural evolution.
4. Semantic comparison — required before collapsing different content.
5. Authority status — determines normative precedence.

## Exact duplicates

Byte-identical archives may be represented once in the active working set, while every original filename and hash remains in provenance.

## Version families

The `FINAL_Documentation_Package` series is treated as a version family:
v1.0 → v2.0 → v2.1 → v2.2 → v2.3.

The v2.x series is not collapsed merely because it shares large amounts of content.

## Authority precedence

1. Product constitution / non-negotiable principles
2. Master index / navigation
3. Architecture specification
4. Protocol and cryptography specifications after decision gates
5. ADR/decision registry
6. Source/reference registry
7. Implementation evidence
8. Test evidence
9. Independent verification
10. Release gates

A file named `FINAL` does not override evidence gates.

## Historical material

Older packages, working notes, research artifacts, and conversation-derived material remain provenance/history unless explicitly promoted by the authority model.
