# Exact Duplicate Archives

تشابه الاسم وحده لا يُستخدم للحكم على التكرار. هذه القائمة تعتمد على SHA-256 للأرشيف نفسه.

## Group 1
- SHA-256: `3db62d88119d548a3efa0aac7a97a11db4681f328a6b90f2d870d577bd03b1cc`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip`

## Group 2
- SHA-256: `37fa8d2b47e8ebde13e88878c36d10c549e52b2e66f5957ce3d9445b756864d4`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip`
