# Exact Duplicate File Contents Across Packages

These groups prove identical file bytes, even when filenames differ. They do not by themselves prove semantic redundancy.

## Group 1 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `03_AI_GOVERNANCE/AGENT_CONTRACT_AND_AUTONOMY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `03_AI_GOVERNANCE/AGENT_CONTRACT_AND_AUTONOMY.md`

## Group 2 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `03_AI_GOVERNANCE/SELF_HEALING_GOVERNANCE.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `03_AI_GOVERNANCE/SELF_HEALING_GOVERNANCE.md`

## Group 3 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/MASTER_SOURCE_REGISTRY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/MASTER_SOURCE_REGISTRY.md`

## Group 4 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/TRACEABILITY_MATRIX.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/TRACEABILITY_MATRIX.md`

## Group 5 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/DUPLICATE_REGISTRY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/DUPLICATE_REGISTRY.md`

## Group 6 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/EVIDENCE_REGISTRY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/EVIDENCE_REGISTRY.md`

## Group 7 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/CONFLICT_REGISTRY_V2.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/CONFLICT_REGISTRY_V2.md`

## Group 8 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/UNMERGED_MISSING_REGISTRY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/UNMERGED_MISSING_REGISTRY.md`

## Group 9 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `01_REGISTRIES/MASTER_FILE_REGISTRY.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `01_REGISTRIES/MASTER_FILE_REGISTRY.md`

## Group 10 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `05_TEST_LAB/TEST_EVIDENCE_INTAKE.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `05_TEST_LAB/TEST_EVIDENCE_INTAKE.md`

## Group 11 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `02_CONTINUOUS_ENGINEERING/CONTINUOUS_ENGINEERING_LOOP.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `02_CONTINUOUS_ENGINEERING/CONTINUOUS_ENGINEERING_LOOP.md`

## Group 12 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `04_TRAINING_EVALUATION/COVERAGE_AND_REGRESSION_CURATOR.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `04_TRAINING_EVALUATION/COVERAGE_AND_REGRESSION_CURATOR.md`

## Group 13 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `04_TRAINING_EVALUATION/TRAINING_EVALUATION_FRAMEWORK.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `04_TRAINING_EVALUATION/TRAINING_EVALUATION_FRAMEWORK.md`

## Group 14 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `06_ARCHITECTURE_MAINTENANCE/ARCHITECTURE_BASELINE_MAINTENANCE.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `06_ARCHITECTURE_MAINTENANCE/ARCHITECTURE_BASELINE_MAINTENANCE.md`

## Group 15 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `00_CONTROL/README.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `00_CONTROL/README.md`

## Group 16 — 2 occurrences
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` :: `00_CONTROL/ADDITIONAL_FILES_STATUS.md`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` :: `00_CONTROL/ADDITIONAL_FILES_STATUS.md`

## Group 17 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/21_AI_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/21_AI_ARCHITECTURE.md`

## Group 18 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/22_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/22_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/22_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/22_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/22_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `22_MCP_SECURITY.md`

## Group 19 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/24_CI_CD.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/24_CI_CD.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/24_CI_CD.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/24_CI_CD.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/24_CI_CD.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `24_CI_CD.md`

## Group 20 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/23_SUPPLY_CHAIN.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/23_SUPPLY_CHAIN.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/23_SUPPLY_CHAIN.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/23_SUPPLY_CHAIN.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/23_SUPPLY_CHAIN.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `23_SUPPLY_CHAIN.md`

## Group 21 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/26_INCIDENT_RCA.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/26_INCIDENT_RCA.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/26_INCIDENT_RCA.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/26_INCIDENT_RCA.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/26_INCIDENT_RCA.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `26_INCIDENT_RCA.md`

## Group 22 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `04_OPERATIONS/25_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `04_OPERATIONS/25_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/25_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/25_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/25_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `25_OBSERVABILITY.md`

## Group 23 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `07_REFERENCES/PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `07_REFERENCES/PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md`

## Group 24 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `07_REFERENCES/Eagle_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_PROJECT_REFERENCE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_MASTER_PROJECT_REFERENCE.md`

## Group 25 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `07_REFERENCES/00_REFERENCE_REGISTRY_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `07_REFERENCES/00_REFERENCE_REGISTRY_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_REFERENCE_REGISTRY_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_REFERENCE_REGISTRY_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_REFERENCE_REGISTRY_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_REFERENCE_REGISTRY_BASELINE.md`

## Group 26 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `07_REFERENCES/Eagle_MASTER_REFERENCE_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_REFERENCE_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_REFERENCE_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_REFERENCE_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/Eagle_MASTER_REFERENCE_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_MASTER_REFERENCE_INDEX.md`

## Group 27 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `07_REFERENCES/EAGLE_REFERENCE_INDEX_V2.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `07_REFERENCES/EAGLE_REFERENCE_INDEX_V2.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/EAGLE_REFERENCE_INDEX_V2.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/EAGLE_REFERENCE_INDEX_V2.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/EAGLE_REFERENCE_INDEX_V2.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `EAGLE_REFERENCE_INDEX_V2.md`

## Group 28 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/34_TECHNICAL_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/34_TECHNICAL_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/34_TECHNICAL_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/34_TECHNICAL_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/34_TECHNICAL_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `34_TECHNICAL_DEBT.md`

## Group 29 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/32_DEPENDENCY_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/32_DEPENDENCY_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/32_DEPENDENCY_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/32_DEPENDENCY_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/32_DEPENDENCY_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `32_DEPENDENCY_REGISTRY.md`

## Group 30 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/41_COMPATIBILITY_MIGRATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/41_COMPATIBILITY_MIGRATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/41_COMPATIBILITY_MIGRATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/41_COMPATIBILITY_MIGRATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/41_COMPATIBILITY_MIGRATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `41_COMPATIBILITY_MIGRATION.md`

## Group 31 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/38_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/38_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/38_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/38_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/38_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `38_PERFORMANCE.md`

## Group 32 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/27_ADR_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/27_ADR_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/27_ADR_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/27_ADR_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/27_ADR_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `27_ADR_REGISTRY.md`

## Group 33 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/28_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/28_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/28_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/28_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/28_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `28_REQUIREMENTS_TRACEABILITY.md`

## Group 34 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/36_DOCUMENTATION_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/36_DOCUMENTATION_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/36_DOCUMENTATION_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/36_DOCUMENTATION_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/36_DOCUMENTATION_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `36_DOCUMENTATION_DEBT.md`

## Group 35 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/42_DISASTER_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/42_DISASTER_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/42_DISASTER_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/42_DISASTER_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/42_DISASTER_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `42_DISASTER_RECOVERY.md`

## Group 36 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/30_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/30_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/30_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/30_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/30_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `30_ROADMAP.md`

## Group 37 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/31_ADOPTION_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/31_ADOPTION_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/31_ADOPTION_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/31_ADOPTION_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/31_ADOPTION_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `31_ADOPTION_REGISTRY.md`

## Group 38 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/35_SECURITY_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/35_SECURITY_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/35_SECURITY_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/35_SECURITY_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/35_SECURITY_DEBT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `35_SECURITY_DEBT.md`

## Group 39 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/37_ARCHITECTURE_DRIFT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/37_ARCHITECTURE_DRIFT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/37_ARCHITECTURE_DRIFT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/37_ARCHITECTURE_DRIFT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/37_ARCHITECTURE_DRIFT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `37_ARCHITECTURE_DRIFT.md`

## Group 40 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/39_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/39_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/39_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/39_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/39_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `39_ACCESSIBILITY.md`

## Group 41 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/29_RELEASE_GATES.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/29_RELEASE_GATES.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/29_RELEASE_GATES.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/29_RELEASE_GATES.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/29_RELEASE_GATES.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `29_RELEASE_GATES.md`

## Group 42 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/40_LOCALIZATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/40_LOCALIZATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/40_LOCALIZATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/40_LOCALIZATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/40_LOCALIZATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `40_LOCALIZATION.md`

## Group 43 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/43_EXTERNAL_AUDIT_PACKAGE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/43_EXTERNAL_AUDIT_PACKAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/43_EXTERNAL_AUDIT_PACKAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/43_EXTERNAL_AUDIT_PACKAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/43_EXTERNAL_AUDIT_PACKAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `43_EXTERNAL_AUDIT_PACKAGE.md`

## Group 44 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `05_GOVERNANCE/33_RISK_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `05_GOVERNANCE/33_RISK_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `05_GOVERNANCE/33_RISK_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `05_GOVERNANCE/33_RISK_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `05_GOVERNANCE/33_RISK_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `33_RISK_REGISTER.md`

## Group 45 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256.json`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256.json`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256.json`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256.json`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256.json`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `FILE_MANIFEST_SHA256.json`

## Group 46 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `00_CONTROL/00_FINAL_STATUS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `00_CONTROL/00_FINAL_STATUS.md`

## Group 47 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `00_CONTROL/Eagle_FINAL_Documentation_Baseline_v1.0.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `00_CONTROL/Eagle_FINAL_Documentation_Baseline_v1.0.docx`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/Eagle_FINAL_Documentation_Baseline_v1.0.docx`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/Eagle_FINAL_Documentation_Baseline_v1.0.docx`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/Eagle_FINAL_Documentation_Baseline_v1.0.docx`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_FINAL_Documentation_Baseline_v1.0.docx`

## Group 48 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `00_CONTROL/01_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `00_CONTROL/01_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/01_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/01_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/01_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `01_MASTER_INDEX.md`

## Group 49 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `02_SECURITY/16_SECURITY_INVARIANTS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `02_SECURITY/16_SECURITY_INVARIANTS.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `02_SECURITY/16_SECURITY_INVARIANTS.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `02_SECURITY/16_SECURITY_INVARIANTS.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `02_SECURITY/16_SECURITY_INVARIANTS.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `16_SECURITY_INVARIANTS.md`

## Group 50 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `02_SECURITY/15_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `02_SECURITY/15_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `02_SECURITY/15_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `02_SECURITY/15_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `02_SECURITY/15_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `15_THREAT_MODEL.md`

## Group 51 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `03_TESTING/19_SCENARIO_CATALOG.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `03_TESTING/19_SCENARIO_CATALOG.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `03_TESTING/19_SCENARIO_CATALOG.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `03_TESTING/19_SCENARIO_CATALOG.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `03_TESTING/19_SCENARIO_CATALOG.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `19_SCENARIO_CATALOG.md`

## Group 52 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `03_TESTING/18_SECURITY_LAB.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `03_TESTING/18_SECURITY_LAB.md`

## Group 53 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `03_TESTING/20_EVIDENCE_GRAPH.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `03_TESTING/20_EVIDENCE_GRAPH.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `03_TESTING/20_EVIDENCE_GRAPH.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `03_TESTING/20_EVIDENCE_GRAPH.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `03_TESTING/20_EVIDENCE_GRAPH.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `20_EVIDENCE_GRAPH.md`

## Group 54 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `03_TESTING/17_TEST_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `03_TESTING/17_TEST_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `03_TESTING/17_TEST_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `03_TESTING/17_TEST_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `03_TESTING/17_TEST_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `17_TEST_ARCHITECTURE.md`

## Group 55 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/00_FINAL_TEAM_HANDOFF_CHECKLIST.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/00_FINAL_TEAM_HANDOFF_CHECKLIST.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/00_FINAL_TEAM_HANDOFF_CHECKLIST.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/00_FINAL_TEAM_HANDOFF_CHECKLIST.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/00_FINAL_TEAM_HANDOFF_CHECKLIST.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_FINAL_TEAM_HANDOFF_CHECKLIST.md`

## Group 56 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/12_ANDROID_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/12_ANDROID_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/12_ANDROID_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/12_ANDROID_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/12_ANDROID_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `12_ANDROID_SPECIFICATION.md`

## Group 57 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/09_DELETION_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/09_DELETION_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/09_DELETION_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/09_DELETION_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/09_DELETION_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `09_DELETION_SPECIFICATION.md`

## Group 58 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/04_CRYPTO_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/04_CRYPTO_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/04_CRYPTO_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/04_CRYPTO_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/04_CRYPTO_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `04_CRYPTO_SPECIFICATION.md`

## Group 59 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/01_PRODUCT_CONSTITUTION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/01_PRODUCT_CONSTITUTION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/01_PRODUCT_CONSTITUTION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/01_PRODUCT_CONSTITUTION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/01_PRODUCT_CONSTITUTION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `01_PRODUCT_CONSTITUTION.md`

## Group 60 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/06_DEVICE_TRUST_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/06_DEVICE_TRUST_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/06_DEVICE_TRUST_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/06_DEVICE_TRUST_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/06_DEVICE_TRUST_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `06_DEVICE_TRUST_SPECIFICATION.md`

## Group 61 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/13_IOS_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/13_IOS_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/13_IOS_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/13_IOS_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/13_IOS_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `13_IOS_SPECIFICATION.md`

## Group 62 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/08_STORAGE_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/08_STORAGE_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/08_STORAGE_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/08_STORAGE_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/08_STORAGE_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `08_STORAGE_SPECIFICATION.md`

## Group 63 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/10_RECOVERY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/10_RECOVERY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/10_RECOVERY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/10_RECOVERY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/10_RECOVERY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `10_RECOVERY_SPECIFICATION.md`

## Group 64 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/05_IDENTITY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/05_IDENTITY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/05_IDENTITY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/05_IDENTITY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/05_IDENTITY_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `05_IDENTITY_SPECIFICATION.md`

## Group 65 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/11_NETWORK_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/11_NETWORK_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/11_NETWORK_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/11_NETWORK_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/11_NETWORK_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `11_NETWORK_SPECIFICATION.md`

## Group 66 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/03_PROTOCOL_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/03_PROTOCOL_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/03_PROTOCOL_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/03_PROTOCOL_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/03_PROTOCOL_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `03_PROTOCOL_SPECIFICATION.md`

## Group 67 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/07_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/07_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/07_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/07_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/07_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `07_SERVER_DATA_CONTRACT.md`

## Group 68 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/02_MASTER_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/02_MASTER_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/02_MASTER_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/02_MASTER_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/02_MASTER_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `02_MASTER_ARCHITECTURE.md`

## Group 69 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `01_SPECIFICATIONS/14_UI_UX_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `01_SPECIFICATIONS/14_UI_UX_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `01_SPECIFICATIONS/14_UI_UX_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `01_SPECIFICATIONS/14_UI_UX_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `01_SPECIFICATIONS/14_UI_UX_SPECIFICATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `14_UI_UX_SPECIFICATION.md`

## Group 70 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/16_OBSERVABILITY.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `16_OBSERVABILITY.md`

## Group 71 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/20_RESEARCH.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `20_RESEARCH.md`

## Group 72 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/01_PRODUCT.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `01_PRODUCT.md`

## Group 73 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/23_RELEASE_AUDIT.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `23_RELEASE_AUDIT.md`

## Group 74 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/Eagle_Team_Work_Packages_Master_v1.1.docx`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `Eagle_Team_Work_Packages_Master_v1.1.docx`

## Group 75 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/22_ACCESSIBILITY.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `22_ACCESSIBILITY.md`

## Group 76 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/25_ASSIGNMENT_FORM.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `25_ASSIGNMENT_FORM.md`

## Group 77 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/04_CRYPTO_PROTOCOL.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `04_CRYPTO_PROTOCOL.md`

## Group 78 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/27_HANDOFF_PROTOCOL.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `27_HANDOFF_PROTOCOL.md`

## Group 79 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/10_DESIGN_SYSTEM.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `10_DESIGN_SYSTEM.md`

## Group 80 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/21_PERFORMANCE.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `21_PERFORMANCE.md`

## Group 81 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/14_RED_TEAM.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `14_RED_TEAM.md`

## Group 82 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/00_TEAM_MASTER_GUIDE.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `00_TEAM_MASTER_GUIDE.md`

## Group 83 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/13_QA.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `13_QA.md`

## Group 84 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/28_SECURITY_STOP_THE_LINE.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `28_SECURITY_STOP_THE_LINE.md`

## Group 85 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/02_ARCHITECTURE.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `02_ARCHITECTURE.md`

## Group 86 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/26_REVIEW_AND_APPROVAL_MATRIX.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `26_REVIEW_AND_APPROVAL_MATRIX.md`

## Group 87 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/TEAM_RACI_MATRIX.csv`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `TEAM_RACI_MATRIX.csv`

## Group 88 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/17_AI.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `17_AI.md`

## Group 89 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/12_PRIVACY_RECOVERY.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `12_PRIVACY_RECOVERY.md`

## Group 90 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/09_UI_UX.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `09_UI_UX.md`

## Group 91 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/03_SECURITY.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `03_SECURITY.md`

## Group 92 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/18_MCP_SECURITY.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `18_MCP_SECURITY.md`

## Group 93 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/19_DOCUMENTATION.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `19_DOCUMENTATION.md`

## Group 94 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/08_IOS.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `08_IOS.md`

## Group 95 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/06_NETWORK_P2P.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `06_NETWORK_P2P.md`

## Group 96 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/05_BACKEND.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `05_BACKEND.md`

## Group 97 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/README.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `README.md`

## Group 98 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/15_DEVSECOPS.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `15_DEVSECOPS.md`

## Group 99 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/07_ANDROID.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `07_ANDROID.md`

## Group 100 — 9 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `06_TEAM_WORK_PACKAGES/Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `Eagle_Team_Work_Packages_v1.1/11_STORAGE.md`
- `Eagle_Team_Work_Packages_v1.1.zip` :: `11_STORAGE.md`

## Group 101 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/04_PROTOCOL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/04_PROTOCOL.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `04_PROTOCOL.md`

## Group 102 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/06_AI_MCP.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/06_AI_MCP.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `06_AI_MCP.md`

## Group 103 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/08_OPERATIONS.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/08_OPERATIONS.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `08_OPERATIONS.md`

## Group 104 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/12_ADR_TEMPLATE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/12_ADR_TEMPLATE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `12_ADR_TEMPLATE.md`

## Group 105 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/11_SCENARIO_TEMPLATE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/11_SCENARIO_TEMPLATE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `11_SCENARIO_TEMPLATE.md`

## Group 106 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/10_COMPREHENSIVE_AUDIT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/10_COMPREHENSIVE_AUDIT.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `10_COMPREHENSIVE_AUDIT.md`

## Group 107 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/01_MASTER_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/01_MASTER_BASELINE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `01_MASTER_BASELINE.md`

## Group 108 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/07_GOVERNANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/07_GOVERNANCE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `07_GOVERNANCE.md`

## Group 109 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/Eagle_PrivateMesh_Comprehensive_Baseline_2026-09-29.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/Eagle_PrivateMesh_Comprehensive_Baseline_2026-09-29.docx`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `Eagle_PrivateMesh_Comprehensive_Baseline_2026-09-29.docx`

## Group 110 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/09_RESEARCH_POLICY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/09_RESEARCH_POLICY.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `09_RESEARCH_POLICY.md`

## Group 111 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/02_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/02_ARCHITECTURE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `02_ARCHITECTURE.md`

## Group 112 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/Eagle_PrivateMesh_COMPLETE_BASELINE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/Eagle_PrivateMesh_COMPLETE_BASELINE.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `Eagle_PrivateMesh_COMPLETE_BASELINE.md`

## Group 113 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/03_SECURITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/03_SECURITY.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `03_SECURITY.md`

## Group 114 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/05_TEST_LAB.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/05_TEST_LAB.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `05_TEST_LAB.md`

## Group 115 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/README.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_PrivateMesh_Baseline_Package_2026-09-29/README.md`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` :: `README.md`

## Group 116 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/DIAGRAM_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/DIAGRAM_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/DIAGRAM_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/DIAGRAM_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/DIAGRAM_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/DIAGRAM_REGISTER.md`

## Group 117 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/REFERENCE_REGISTRY.csv`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/REFERENCE_REGISTRY.csv`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_REGISTRY.csv`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_REGISTRY.csv`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_REGISTRY.csv`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_REGISTRY.csv`

## Group 118 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/MASTER_REFERENCE_LIBRARY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/MASTER_REFERENCE_LIBRARY.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/MASTER_REFERENCE_LIBRARY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/MASTER_REFERENCE_LIBRARY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/MASTER_REFERENCE_LIBRARY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/MASTER_REFERENCE_LIBRARY.md`

## Group 119 — 6 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/README.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Master_Reference_Library_v1.0/README.md`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_LIBRARY_README.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_LIBRARY_README.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_LIBRARY_README.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/REFERENCE_LIBRARY_README.md`

## Group 120 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/10_SUPPLY_CHAIN_RELEASE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/10_SUPPLY_CHAIN_RELEASE.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `10_SUPPLY_CHAIN_RELEASE.md`

## Group 121 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/02_SYSTEM_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/02_SYSTEM_ARCHITECTURE.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `02_SYSTEM_ARCHITECTURE.md`

## Group 122 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/19_DECISION_GATES.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/19_DECISION_GATES.md`

## Group 123 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/11_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/11_REQUIREMENTS_TRACEABILITY.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `11_REQUIREMENTS_TRACEABILITY.md`

## Group 124 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/17_DOCUMENTATION_MAP.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/17_DOCUMENTATION_MAP.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `17_DOCUMENTATION_MAP.md`

## Group 125 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/Eagle_PrivateMesh_Project_Handbook.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/Eagle_PrivateMesh_Project_Handbook.docx`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `Eagle_PrivateMesh_Project_Handbook.docx`

## Group 126 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/03_SECURITY_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/03_SECURITY_ARCHITECTURE.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `03_SECURITY_ARCHITECTURE.md`

## Group 127 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/00_MASTER_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/00_MASTER_INDEX.md`

## Group 128 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/01_PROJECT_CHARTER.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/01_PROJECT_CHARTER.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `01_PROJECT_CHARTER.md`

## Group 129 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/09_AI_MCP_GOVERNANCE.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/09_AI_MCP_GOVERNANCE.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `09_AI_MCP_GOVERNANCE.md`

## Group 130 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/16_ROADMAP.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/16_ROADMAP.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `16_ROADMAP.md`

## Group 131 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/12_ADR_INDEX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/12_ADR_INDEX.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `12_ADR_INDEX.md`

## Group 132 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/18_EXTERNAL_VERIFICATION_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/18_EXTERNAL_VERIFICATION_MATRIX.md`

## Group 133 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/13_SOURCE_REGISTRY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/13_SOURCE_REGISTRY.md`

## Group 134 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/05_IDENTITY_SESSION_RECOVERY.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/05_IDENTITY_SESSION_RECOVERY.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `05_IDENTITY_SESSION_RECOVERY.md`

## Group 135 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/Eagle_PrivateMesh_Project_Handbook_v0.3.docx`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/Eagle_PrivateMesh_Project_Handbook_v0.3.docx`

## Group 136 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/14_AUDIT_REPORT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/14_AUDIT_REPORT.md`

## Group 137 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/04_PROTOCOL_SPECIFICATION_DRAFT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/04_PROTOCOL_SPECIFICATION_DRAFT.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `04_PROTOCOL_SPECIFICATION_DRAFT.md`

## Group 138 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/08_TEST_STRATEGY_AND_LAB.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/08_TEST_STRATEGY_AND_LAB.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `08_TEST_STRATEGY_AND_LAB.md`

## Group 139 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/06_SERVER_DATA_CONTRACT.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/06_SERVER_DATA_CONTRACT.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `06_SERVER_DATA_CONTRACT.md`

## Group 140 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/07_THREAT_MODEL.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/07_THREAT_MODEL.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `07_THREAT_MODEL.md`

## Group 141 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/15_OPEN_ISSUES.md`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` :: `90_ARCHIVE/Eagle_Project_Documentation_Pack_2026-09-28/15_OPEN_ISSUES.md`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` :: `15_OPEN_ISSUES.md`

## Group 142 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/00_FINAL_STATUS.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/00_FINAL_STATUS.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/00_FINAL_STATUS.md`

## Group 143 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/02_AUDIT_EXECUTIVE_SUMMARY.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/02_AUDIT_EXECUTIVE_SUMMARY.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/02_AUDIT_EXECUTIVE_SUMMARY.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `02_AUDIT_EXECUTIVE_SUMMARY.md`

## Group 144 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/03_ARCHIVE_PROVENANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/03_ARCHIVE_PROVENANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/03_ARCHIVE_PROVENANCE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `03_ARCHIVE_PROVENANCE.md`

## Group 145 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/04_INTEGRATION_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/04_INTEGRATION_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/04_INTEGRATION_MATRIX.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `04_INTEGRATION_MATRIX.md`

## Group 146 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/05_CONFLICT_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/05_CONFLICT_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/05_CONFLICT_REGISTER.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `05_CONFLICT_REGISTER.md`

## Group 147 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/06_UNMERGED_AND_GAPS.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/06_UNMERGED_AND_GAPS.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/06_UNMERGED_AND_GAPS.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `06_UNMERGED_AND_GAPS.md`

## Group 148 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256_V2.json`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256_V2.json`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256_V2.json`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `FILE_MANIFEST_SHA256_V2.json`

## Group 149 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `03_TESTING/18_SECURITY_LAB.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `03_TESTING/18_SECURITY_LAB.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `03_TESTING/18_SECURITY_LAB.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `18_SECURITY_LAB.md`

## Group 150 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `04_OPERATIONS/21_AI_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `04_OPERATIONS/21_AI_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `04_OPERATIONS/21_AI_ARCHITECTURE.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `21_AI_ARCHITECTURE.md`

## Group 151 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/GHOSTS_decade_report_2026.pdf`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/GHOSTS_decade_report_2026.pdf`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/GHOSTS_decade_report_2026.pdf`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/GHOSTS_decade_report_2026.pdf`

## Group 152 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/cross_platform_architecture_discussion.docx`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/cross_platform_architecture_discussion.docx`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/cross_platform_architecture_discussion.docx`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/cross_platform_architecture_discussion.docx`

## Group 153 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_into_the_unknown_lab.pdf`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_into_the_unknown_lab.pdf`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_into_the_unknown_lab.pdf`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/deepseek_into_the_unknown_lab.pdf`

## Group 154 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_isolated_lab_conversation.mhtml`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_isolated_lab_conversation.mhtml`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/00_EXTERNAL_SOURCE_MATERIALS/deepseek_isolated_lab_conversation.mhtml`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `00_EXTERNAL_SOURCE_MATERIALS/deepseek_isolated_lab_conversation.mhtml`

## Group 155 — 4 occurrences
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` :: `07_REFERENCES/01_RESEARCH_INTEGRATION_DIGEST.md`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `07_REFERENCES/01_RESEARCH_INTEGRATION_DIGEST.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `07_REFERENCES/01_RESEARCH_INTEGRATION_DIGEST.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `01_RESEARCH_INTEGRATION_DIGEST.md`

## Group 156 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/FINAL_AUDIT_V2.1.md`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/FINAL_AUDIT_V2.1.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `FINAL_AUDIT_V2.1.md`

## Group 157 — 3 occurrences
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` :: `00_CONTROL/MASTER_ENVIRONMENT_INVENTORY.tsv`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/MASTER_ENVIRONMENT_INVENTORY.tsv`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `MASTER_ENVIRONMENT_INVENTORY.tsv`

## Group 158 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/FILE_MANIFEST_SHA256_V2_2.json`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `FILE_MANIFEST_SHA256_V2_2.json`

## Group 159 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/07_FINAL_INTERNAL_CONSISTENCY_AUDIT_V2.2.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `07_FINAL_INTERNAL_CONSISTENCY_AUDIT_V2.2.md`

## Group 160 — 2 occurrences
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` :: `00_CONTROL/08_CANONICAL_STATUS_SEMANTICS.md`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` :: `08_CANONICAL_STATUS_SEMANTICS.md`
