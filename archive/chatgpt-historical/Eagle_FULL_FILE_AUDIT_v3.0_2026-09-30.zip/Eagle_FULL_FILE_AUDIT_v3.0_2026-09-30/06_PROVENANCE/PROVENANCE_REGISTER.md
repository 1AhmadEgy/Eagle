# Provenance Register

Uploaded ZIP packages audited: **20**

## Archive list
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` — 16 files — SHA-256 `3db62d88119d548a3efa0aac7a97a11db4681f328a6b90f2d870d577bd03b1cc`
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip` — 16 files — SHA-256 `3db62d88119d548a3efa0aac7a97a11db4681f328a6b90f2d870d577bd03b1cc`
- `Eagle_CORRECTED_DEVELOPMENT_PACKAGE_v2.4_2026-09-29.zip` — 22 files — SHA-256 `d5f8ed6972f3eec00b66d205b8919e0491f89ea6aa4cf58dc48f2882c9176518`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` — 156 files — SHA-256 `37fa8d2b47e8ebde13e88878c36d10c549e52b2e66f5957ce3d9445b756864d4`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip` — 156 files — SHA-256 `37fa8d2b47e8ebde13e88878c36d10c549e52b2e66f5957ce3d9445b756864d4`
- `Eagle_FINAL_Documentation_Package_v2.0_2026-09-29.zip` — 99 files — SHA-256 `bc02e32b7b83db95c507e36cae832f2e4b3bcfab63895021dc5086205b2dbc36`
- `Eagle_FINAL_Documentation_Package_v2.1_2026-09-29.zip` — 101 files — SHA-256 `b83fc81956e05ac0e8ab9d67a013a726c7689ff06227a2324a05b466a0125d70`
- `Eagle_FINAL_Documentation_Package_v2.2_2026-09-29.zip` — 104 files — SHA-256 `0182d29da82220c0032d2ae85d84e066a8afb2c26c5ef99d3ebdb13d27a8216e`
- `Eagle_FINAL_Documentation_Package_v2.3_2026-09-29.zip` — 105 files — SHA-256 `b5783b0d39a1b607cb40ed86c80f59c2e8a8ab9b444bf3dd79ca73637f9621c2`
- `Eagle_GAP_CLOSURE_PACKAGE_v1.0.zip` — 13 files — SHA-256 `7878f1bba63f44c58ceb2f213746cc252ed57ed5b79ff93836e16a57deb5ece4`
- `Eagle_GAP_CLOSURE_PACKAGE_v1.1.zip` — 8 files — SHA-256 `e16fa5e11e068b9760dfc6bad810d25f998fbeff439dad2c027376487cad43bb`
- `Eagle_IMPLEMENTATION_EVIDENCE_GATE_v1.1.zip` — 10 files — SHA-256 `00d115e38c18fd0d041333f77caaed79388c62cb2beb35901967d0fb1feb8bee`
- `Eagle_IMPLEMENTATION_EVIDENCE_INTAKE_v1.0.zip` — 9 files — SHA-256 `6b26465e03ce3493df92ac2bc4b278d83a2d13cbeef14e0047f6e3fe0d4a3434`
- `Eagle_MASTERIZATION_PACKAGE_v1.0.zip` — 27 files — SHA-256 `e8c6d044f5b2ac897ab6b5407d0553ebafbc937b27b8d7e2ba64f4ae490c3442`
- `Eagle_PRODUCTION_EXECUTION_BRIDGE_v2.8_2026-09-30.zip` — 33 files — SHA-256 `5010de7506998d6cd01e6de767951edd7f16889c83513974de1fc47dce240454`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip` — 15 files — SHA-256 `13d2df831dd13e8f38522c379169a868bf7bda1cea0612545f882776b838dd4a`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip` — 25 files — SHA-256 `581e0d6bea5daaefe7acd78ce87f97785bd3bdde82fc6e092e7b7b12573679ce`
- `Eagle_REMAINING_COMPLETION_PACKAGE_v2.5_2026-09-30.zip` — 41 files — SHA-256 `618b370fc1cd7842696a30f2dbbf2b5b8699301824587f0ad43551a114e71c82`
- `Eagle_Team_Work_Packages_v1.1.zip` — 31 files — SHA-256 `009fb2de014821fa5dd7e5b3893423b46de52d49656b6200f41e2647e935cf99`
- `PrivateMesh_Project_Documentation.zip` — 17 files — SHA-256 `f5793bb99152f0772914d66423e3c670e76121d217c326729af2fc11dcbfd37d`

## Exact duplicate archive groups
- `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0-1.zip` = `Eagle_CORRECTED_ADDITIONAL_FILES_v1.0.zip`
- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29-1.zip` = `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip`