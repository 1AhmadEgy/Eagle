# ADR-XXXX — Title
Status: PROPOSED
Date:
Owner:

## Context
## Problem
## Options
## Decision
## Security impact
## Privacy impact
## Compatibility impact
## Consequences
## Alternatives rejected
## References
## Implementation
## Tests
## Evidence
## Supersedes / Replaces
