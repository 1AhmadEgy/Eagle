# SF-XXXX — Security Finding
Severity:
Status:
Component:
Source/Test:

## Reproduction
## Expected
## Actual
## Impact
## Root cause
## Fix
## Regression test
## Verification evidence
