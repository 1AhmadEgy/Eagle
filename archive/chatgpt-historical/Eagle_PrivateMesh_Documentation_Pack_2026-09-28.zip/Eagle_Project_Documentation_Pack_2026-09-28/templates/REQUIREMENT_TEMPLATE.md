# REQ-DOMAIN-XXXX — Title
Status: PROPOSED
Priority: P0/P1/P2

## Requirement
## Rationale
## Source
## Acceptance criteria
## Security impact
## Implementation
## Tests
## Evidence
## Owner
