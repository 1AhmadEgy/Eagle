# Source Registry

## Project/reference documents
| Source | Classification | Role |
|---|---|---|
| EAGLE_REFERENCE_INDEX_V2.md | REFERENCE INDEX | compact source taxonomy |
| Eagle_MASTER_PROJECT_REFERENCE.md | PROJECT MASTER | conversation/document map |
| PRIVATE_MESH_MASTER_PROJECT_REFERENCE.md | PROJECT MASTER | consolidated architecture/security reference |
| Eagle_MASTER_REFERENCE_INDEX.md | REFERENCE INDEX | technical source map |

## Research
| Source | Classification | Use |
|---|---|---|
| A Decade of GHOSTS in the Machine... | RESEARCH / ENGINEERING | observability, maintainability, realism, sustainment |
| DeepSeek _ Into the Unknown_.pdf | RESEARCH / TEST-LAB | cyber-range methodology, agents, scenarios, analytics |
| DeepSeek - إلى المجهول | RESEARCH / TEST-LAB NOTES | scenario lifecycle, lab structure, agent roles, templates |

## Mixed conversation/document dump
| Source | Classification | Rule |
|---|---|---|
| بالضبط_5362697558946016807.docx | MIXED PROJECT MATERIAL | mine for useful technical content; do not treat all embedded links/claims as authoritative |

## Navigation artifact
| Source | Classification |
|---|---|
| ChatGPT shared link.url | NAVIGATION POINTER only |

## Source status rule
Presence in the registry never means adoption.
