# Standards & Dependency Drift Engine

Inputs: standards, RFCs, NIST publications, OWASP releases, platform security guidance, adopted-library releases/advisories.

Flow: detect → classify authority → identify affected claims/requirements/ADRs → impact analysis → update tests/specs → independent review → release-gate decision.

Draft standards are monitoring inputs, not final normative authority unless the project explicitly records otherwise.
