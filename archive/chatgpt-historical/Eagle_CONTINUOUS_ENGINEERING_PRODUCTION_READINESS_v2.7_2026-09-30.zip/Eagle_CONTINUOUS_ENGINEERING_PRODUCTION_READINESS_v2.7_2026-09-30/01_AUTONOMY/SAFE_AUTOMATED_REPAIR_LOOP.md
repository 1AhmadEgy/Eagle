# Safe Automated Repair Loop

Detect → reproduce → minimize → propose → static check → targeted tests → full regression → security regression → independent verification → evidence package → human/policy approval → merge.

Never auto-merge a repair solely because an AI model reports success.

Rollback is mandatory for every automated change capable of reaching a deployed artifact.
