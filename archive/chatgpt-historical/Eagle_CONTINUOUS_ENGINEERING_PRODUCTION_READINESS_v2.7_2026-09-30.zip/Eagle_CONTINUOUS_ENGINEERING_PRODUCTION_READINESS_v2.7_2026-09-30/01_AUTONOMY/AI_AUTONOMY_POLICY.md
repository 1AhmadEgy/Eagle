# AI Autonomy Policy

A0 Observe only.
A1 Analyze and report.
A2 Generate proposals.
A3 Execute isolated tests.
A4 Prepare patches in isolated worktrees.
A5 Prepare PRs with complete evidence.
A6 Conditional merge/release preparation only when deterministic gates and approval policy permit.
A7 Production-changing autonomy is disabled by default and may not override security policy.

Protected actions requiring explicit governance: crypto parameter changes, identity/trust changes, authentication/authorization changes, recovery/deletion policy changes, security-control disabling, production credential access, release signing, and irreversible destructive actions.

Promotion/demotion must be evidence-based. Security incidents cause immediate demotion/quarantine of the affected agent/workflow.
