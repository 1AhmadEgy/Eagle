# AI/MCP Threat Model

Threats: prompt injection, tool poisoning, confused deputy, argument injection, excessive agency, secret exfiltration, privilege escalation, cross-tool contamination, unsafe generated patches, malicious context, compromised tool server.

Controls: authenticated tool identity, authorization, allowlists, schema validation, argument validation, sandboxing, rate limits, audit logging, network restrictions, secret isolation, deterministic policy enforcement, independent verification and rollback.
