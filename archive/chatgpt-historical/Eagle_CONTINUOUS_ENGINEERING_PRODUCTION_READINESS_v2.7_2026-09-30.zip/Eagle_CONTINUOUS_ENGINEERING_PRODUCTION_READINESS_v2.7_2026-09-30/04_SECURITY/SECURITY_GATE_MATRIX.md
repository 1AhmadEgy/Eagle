# Security Gate Matrix

Identity/authentication: BLOCK until executable tests and independent verification.
Device trust/attestation: BLOCK until platform evidence exists.
Key management/session/ratchet: BLOCK until protocol vectors, negative tests, and independent verification exist.
Recovery/deletion: BLOCK until failure and residual-data tests exist.
MCP/tools/AI: BLOCK privileged automation until policy enforcement and sandbox tests exist.
Supply chain: BLOCK release until dependency policy, SBOM, provenance, attestation and artifact verification pass.
