# Security Invariant Automation

Security invariants must be represented as executable checks where feasible. Examples: no unauthenticated privileged action; no downgrade across prohibited versions; no plaintext secret in telemetry; no trust-state transition without required evidence; no release artifact without provenance/signature verification.
