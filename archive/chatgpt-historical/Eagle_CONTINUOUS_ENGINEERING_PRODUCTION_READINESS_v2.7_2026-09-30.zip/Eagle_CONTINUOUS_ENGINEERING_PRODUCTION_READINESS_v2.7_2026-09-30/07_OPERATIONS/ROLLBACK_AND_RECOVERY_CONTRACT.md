# Rollback and Recovery Contract

Every releasable change needs a reversible deployment path unless the change is explicitly irreversible and separately approved. Recovery procedures must define authority, prerequisites, data impact, key impact, verification and post-recovery security checks.
