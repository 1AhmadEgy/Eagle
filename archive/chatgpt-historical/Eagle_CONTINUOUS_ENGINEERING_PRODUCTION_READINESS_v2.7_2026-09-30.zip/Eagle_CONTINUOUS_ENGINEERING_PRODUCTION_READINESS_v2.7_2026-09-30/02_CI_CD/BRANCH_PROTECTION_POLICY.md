# Branch Protection Policy

Protect release branches and main. Require successful CI, required reviewers, security checks, dependency checks, and signed/verified release artifacts. Disable force pushes and branch deletion for protected branches. Treat administrative bypass as an auditable security event.
