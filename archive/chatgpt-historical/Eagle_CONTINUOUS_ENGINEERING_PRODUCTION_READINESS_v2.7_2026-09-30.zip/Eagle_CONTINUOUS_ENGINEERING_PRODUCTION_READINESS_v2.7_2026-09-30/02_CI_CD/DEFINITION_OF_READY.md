# Definition of Ready

A task is dispatchable only when it has: unique ID, problem statement, affected component, acceptance criteria, security impact, threat assumptions, dependencies, rollback plan, test plan, evidence plan, required reviewer/verifier, and explicit unresolved decisions.

Tasks touching crypto, identity, trust, recovery, deletion, release signing or security policy require security review before implementation.
