# Definition of Done

Implementation exists at an immutable revision; unit/integration/security/negative/regression tests applicable to the change pass; required evidence is retained; dependency and supply-chain checks pass; documentation/spec/ADR are synchronized; independent verification is complete where required; rollback is defined; no stop-the-line condition remains.
