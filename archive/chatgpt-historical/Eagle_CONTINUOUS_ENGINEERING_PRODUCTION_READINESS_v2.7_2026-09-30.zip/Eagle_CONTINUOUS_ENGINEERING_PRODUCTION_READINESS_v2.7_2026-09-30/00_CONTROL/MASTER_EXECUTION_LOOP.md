# Master Continuous Execution Loop

1. WATCH: source, issues, dependencies, standards, CI, incidents, runtime signals.
2. ASSESS: classify change, threat, impact scope, confidence, affected requirements.
3. ADMIT: Definition-of-Ready gate; reject ambiguous or unsafe tasks.
4. ISOLATE: dedicated branch/worktree/sandbox and least-privilege credentials.
5. EXECUTE: human or AI-assisted implementation.
6. VERIFY: static analysis, dependency checks, unit/integration/protocol/property/fuzz/security tests as applicable.
7. REVIEW: independent reviewer/verifier; security review for protected domains.
8. ATTEST: record source revision, build, tests, SBOM, provenance, attestations and artifact digests.
9. RELEASE: deterministic release policy decides whether gates are satisfied.
10. OBSERVE: privacy-minimized runtime telemetry.
11. DRIFT: detect standards/dependency/architecture/threat drift.
12. LEARN: update requirements, scenarios, tests and documentation; never silently change security policy.
