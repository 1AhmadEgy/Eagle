# Protocol Conformance Model

Define normative state machines, message schemas, version negotiation, capability negotiation, error semantics, replay handling, ordering, retry behavior, timeout behavior, downgrade resistance, and test vectors before claiming interoperability.

Any implementation behavior not covered by the normative specification is NON-CONFORMANT/UNDEFINED until explicitly decided.
