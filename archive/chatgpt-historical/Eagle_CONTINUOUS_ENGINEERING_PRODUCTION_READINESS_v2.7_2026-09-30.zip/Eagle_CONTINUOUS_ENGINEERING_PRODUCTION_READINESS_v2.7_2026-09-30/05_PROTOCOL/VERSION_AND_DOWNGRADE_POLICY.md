# Version and Downgrade Policy

Version negotiation must define supported ranges and explicit rejection behavior. Security-sensitive downgrades require an explicit compatibility rule and must never silently weaken cryptographic or authentication guarantees.
