# Error and Failure Contract

Errors must be typed, deterministic, privacy-minimized and non-ambiguous. Security failures fail closed. Do not expose secrets, key material, internal trust decisions, or unnecessary metadata through user-visible or telemetry error channels.
