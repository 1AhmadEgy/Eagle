# Evidence Graph Rules

Source → Claim → Requirement → Threat → Control → Implementation → Test → Result → Evidence → Independent Verification → ADR/Decision → Release Gate.

A node cannot be marked VERIFIED when a required predecessor is missing. Evidence must identify immutable revisions and artifact digests whenever possible.
