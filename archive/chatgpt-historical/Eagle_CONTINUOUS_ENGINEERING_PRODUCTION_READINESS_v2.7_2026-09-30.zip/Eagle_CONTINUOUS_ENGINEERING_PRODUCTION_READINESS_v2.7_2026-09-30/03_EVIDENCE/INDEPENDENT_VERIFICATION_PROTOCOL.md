# Independent Verification Protocol

The verifier must not rely solely on the implementer's assertion. Reproduce critical tests from the recorded revision, inspect evidence, validate expected/actual results, check security invariants, and record an independent verdict.

For security-critical changes, the verifier must be a separate role from the implementing agent.
