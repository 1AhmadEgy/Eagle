# Claim Status Machine

UNSUPPORTED → PROPOSED → EVIDENCE_PENDING → EVIDENCE_AVAILABLE → VERIFIED → RELEASE_ELIGIBLE.

Any contradictory evidence transitions a claim to CONFLICTED. Verification may be revoked when the referenced implementation, dependency, standard, or threat model changes materially.
