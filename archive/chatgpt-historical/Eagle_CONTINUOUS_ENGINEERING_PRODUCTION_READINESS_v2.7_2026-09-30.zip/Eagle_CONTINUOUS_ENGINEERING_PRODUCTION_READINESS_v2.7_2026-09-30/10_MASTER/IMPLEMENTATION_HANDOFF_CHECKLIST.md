# Implementation Handoff Checklist

Before accepting a real repository: capture repository URI, commit/tag, toolchain versions, Cargo.lock/manifest, build instructions, platform matrix, exact source paths, tests, CI configuration, SBOM/provenance, security scans, secrets policy, reviewer/verifier identities and artifact digests.

Documentation-only submissions remain EVIDENCE_PENDING.
