# Next Execution Sequence

1. Intake the actual source repository.
2. Freeze an immutable baseline revision.
3. Inventory code/dependencies/workflows/secrets/configuration.
4. Run static/dependency/security analysis.
5. Build reproducibly in an isolated environment.
6. Execute unit/integration/protocol/property/state/fuzz/security tests.
7. Map evidence to requirements and invariants.
8. Perform independent verification.
9. Generate SBOM/provenance/attestation/signature evidence.
10. Run release gates and external security review where required.
11. Only then evaluate production release eligibility.
