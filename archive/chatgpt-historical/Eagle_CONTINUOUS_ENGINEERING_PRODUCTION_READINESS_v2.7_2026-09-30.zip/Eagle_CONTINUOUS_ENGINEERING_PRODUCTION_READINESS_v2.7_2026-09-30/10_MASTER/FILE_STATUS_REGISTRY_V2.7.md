# File Status Registry v2.7

This package is additive. Existing packages remain authoritative for content they own unless superseded by an explicit ADR.

Status vocabulary: NEW, EXTENDS, CORRECTS, REFERENCE_ONLY, EVIDENCE_PENDING, BLOCKED, VERIFIED.

All files in this package are documentation/policy/templates unless explicitly stated otherwise. None constitutes proof of production implementation.
