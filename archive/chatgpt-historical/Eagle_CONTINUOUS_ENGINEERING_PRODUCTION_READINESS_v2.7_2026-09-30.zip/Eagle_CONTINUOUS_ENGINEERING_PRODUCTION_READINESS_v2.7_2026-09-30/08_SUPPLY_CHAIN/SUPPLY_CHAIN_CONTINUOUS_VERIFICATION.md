# Continuous Supply-Chain Verification

For every release candidate: verify immutable source revision, dependency lock state, dependency policy, SBOM, build provenance, attestations, artifact digest and signature. Verify on the consumer side as well as producer side.

SLSA v1.2 provides separate Source and Build tracks; Eagle must not treat one provenance artifact as proof of all supply-chain properties.
