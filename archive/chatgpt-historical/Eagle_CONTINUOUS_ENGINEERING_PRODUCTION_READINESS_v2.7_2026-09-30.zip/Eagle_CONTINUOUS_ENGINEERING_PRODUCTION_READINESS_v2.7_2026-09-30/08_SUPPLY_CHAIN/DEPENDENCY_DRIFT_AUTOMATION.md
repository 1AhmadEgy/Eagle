# Dependency Drift Automation

Watch: manifest/lockfile changes, advisories, yanked releases, maintainer/security events, transitive dependency changes and license changes.

Classify: PATCH/MINOR/MAJOR/SECURITY/COMPATIBILITY/REPLACEMENT.

Security-critical dependency changes require impact analysis, test expansion and release-gate reevaluation.
