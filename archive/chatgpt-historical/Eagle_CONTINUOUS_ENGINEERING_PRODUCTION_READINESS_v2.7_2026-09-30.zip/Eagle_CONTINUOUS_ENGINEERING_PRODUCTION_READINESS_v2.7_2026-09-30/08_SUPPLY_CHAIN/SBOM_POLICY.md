# SBOM Policy

Generate machine-readable SBOMs for release artifacts and retain them with the release evidence. Prefer SPDX and/or CycloneDX as project-approved formats. SBOM presence is not sufficient: it must be tied to an immutable artifact digest and used for vulnerability response.
