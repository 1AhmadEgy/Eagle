# Android/iOS Platform Assurance

Record exact OS/device versions, hardware-backed key capabilities, attestation results where used, app signing identity, build artifact digest, runtime permissions, secure storage behavior, backup behavior, debugging status, and security-test evidence.

Do not assume identical hardware-security capabilities across devices or OS versions.
