# Test Evidence Intake

## Intake record
TEST-ID, Requirement, Component, Type, Environment, Preconditions, Input, Expected, Actual, Evidence, Result, Regression.

## Accepted results
`PASS | FAIL | BLOCKED | NOT_RUN | NOT_APPLICABLE`

## Security requirement
A PASS without reproducible evidence is not equivalent to independent verification.
