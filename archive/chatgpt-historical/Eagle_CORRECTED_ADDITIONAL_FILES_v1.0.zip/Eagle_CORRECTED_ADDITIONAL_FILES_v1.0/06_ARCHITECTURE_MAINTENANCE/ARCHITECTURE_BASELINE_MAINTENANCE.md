# Architecture Baseline Maintenance

## Trigger events
- protocol/crypto/platform/dependency change;
- security advisory;
- implementation change;
- threat-model change;
- scope change;
- release change.

## Required record
Date, Source, Old Decision, New Decision, Reason, Security Impact, Compatibility Impact, Affected Specifications, Required Tests, Verification, Status.

## Drift control
Any divergence between implementation and approved specification becomes an Architecture Drift finding and follows the project's stop-the-line rules when security-critical.
