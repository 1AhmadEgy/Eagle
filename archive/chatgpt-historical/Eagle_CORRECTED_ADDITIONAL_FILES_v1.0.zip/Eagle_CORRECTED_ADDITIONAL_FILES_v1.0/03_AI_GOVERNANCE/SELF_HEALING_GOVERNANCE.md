# Controlled Self-Healing Governance

## Principle
Self-healing is a controlled engineering capability, not unrestricted autonomy.

## Required sequence
Detect → Scope → Safety Preflight → Generate Candidate → Sandbox → Test → Security Test → Verify → Approval Gate → Apply → Regression → Evidence → Rollback if failure → Document.

## Forbidden autonomous actions
- bypass auth/authz;
- change trust roots;
- weaken cryptographic policy;
- expose secrets;
- disable security controls;
- approve own security finding;
- modify release gates;
- silently alter retention/deletion guarantees.
