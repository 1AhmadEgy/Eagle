# Agent Contract and Autonomy

## Contract
- agent_id
- role
- authority
- tools
- allowed_data
- forbidden_data
- allowed_actions
- forbidden_actions
- max_runtime
- max_cost
- max_tool_calls
- sandbox
- approval_required
- evidence_required
- verifier
- rollback
- audit_policy

## Autonomy levels
`A0..A7` are governance levels, not permission to bypass security policy.
Higher autonomy requires stronger evidence, isolation, verification, rollback and auditability.

## Critical roles
Orchestrator, Verifier, Safety Guard, Governance, Scenario Generator/Injector, Detector/Classifier, RCA, Remediator, Regression Curator, Coverage Curator, Knowledge Curator, Baseline Keeper, Reporter, Red Team, Blue Team.
