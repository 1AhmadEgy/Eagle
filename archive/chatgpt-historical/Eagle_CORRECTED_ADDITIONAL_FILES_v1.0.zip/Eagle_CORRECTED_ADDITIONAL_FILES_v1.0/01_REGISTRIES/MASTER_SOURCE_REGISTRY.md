# Master Source Registry

## Source record
- SOURCE-ID
- Title
- Publisher
- URL / Document
- Version / Date
- Source Type
- Authority
- Domain
- Claim Supported
- Relevant Component
- License
- Maintenance Status
- Security Relevance
- Project Adoption Status
- ADR
- Specification
- Required Tests
- Evidence
- Notes

## Source Type
`STANDARD | OFFICIAL_DOCUMENTATION | REFERENCE_IMPLEMENTATION | LIBRARY | RESEARCH_PAPER | SECURITY_GUIDANCE | TESTING_STANDARD | TOOL | CASE_STUDY | PROJECT_DISCUSSION | ARCHIVED_REFERENCE | UNVERIFIED`

## Authority rule
Normative standards/RFCs/official specifications > official platform/vendor documentation > maintainer documentation > peer-reviewed/institutional research > independent research > community > blogs > AI-generated material.

AI-generated material is never sole authority for security decisions.
