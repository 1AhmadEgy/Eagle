# Conflict Registry v2

| CONFLICT-ID | Topic | Source A | Source B | Conflict | Authority Ranking | Security Impact | Decision | ADR | Affected Docs | Required Tests | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|

## Known unresolved conflicts
- OI-001 exact Signal implementation/version
- OI-002 PQXDH integration profile
- OI-003 V1 transport boundary
- OI-004 server ciphertext retention
- OI-005 identity/device trust states
- OI-006 device linking
- OI-007 recovery protocol
- OI-008 deletion guarantees
