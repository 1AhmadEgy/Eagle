# Duplicate Registry

| DUP-ID | File A | File B | Duplicate Type | Similarity | Unique Content A | Unique Content B | Canonical | Action | Evidence |
|---|---|---|---|---|---|---|---|---|---|

## Rule
لا حذف قبل exact content comparison. Historical packages remain preserved and are referenced through provenance.
