# Evidence Registry

## Evidence chain
`Source → Requirement → Threat → Scenario → ADR/Decision → Specification → Implementation → Test → Evidence → Independent Verification → Release Gate`

## Evidence record
- EVIDENCE-ID
- Claim / Finding
- Source
- Artifact
- Test ID
- Environment
- Timestamp
- Hash / Version
- Expected
- Actual
- Result
- Reviewer
- Independent Verification
- Related Requirement / ADR / Threat
- Release Gate
- Status
