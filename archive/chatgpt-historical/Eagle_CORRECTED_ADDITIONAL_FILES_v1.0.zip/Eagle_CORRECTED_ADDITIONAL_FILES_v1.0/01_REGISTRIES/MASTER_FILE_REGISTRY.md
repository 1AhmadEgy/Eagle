# Master File Registry

## Rule
لا يُحذف أو يُدمج ملف بناءً على تشابه الاسم فقط. يجب وجود مقارنة محتوى ودليل.

## Record schema
- FILE-ID
- Filename
- Version
- Created / Modified
- Type
- Domain
- Authority
- Role
- Status
- Canonical File
- Duplicate Of
- Supersedes / Superseded By
- Content Hash
- Source
- ADR Links
- Requirement Links
- Test Links
- Evidence Links
- Notes

## Status vocabulary
`ORIGINAL | CANONICAL | SUPERSEDED | DUPLICATE | HISTORICAL | ARCHIVED | UNVERIFIED | CONFLICTED`

## Important
Source classification is independent from adoption lifecycle.
