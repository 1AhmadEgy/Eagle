# Unmerged / Missing Registry

| MISS-ID | Source | Missing Content | Target Document | Reason Not Integrated | Security Impact | Priority | Integration Action | Verification | Status |
|---|---|---|---|---|---|---|---|---|---|

## Current rule
المحتوى البحثي لا يتحول تلقائيًا إلى قرار معماري. يجب المرور عبر: Source → Security Review → Maturity Review → License Review → Maintenance Review → Interoperability Review → Threat Model → Prototype → Tests → Decision.
