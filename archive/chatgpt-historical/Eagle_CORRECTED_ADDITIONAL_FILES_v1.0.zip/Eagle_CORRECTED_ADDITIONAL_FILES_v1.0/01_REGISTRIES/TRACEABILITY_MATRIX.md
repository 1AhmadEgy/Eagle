# Traceability Matrix

## Required path
`Problem → Evidence → Risk → Correction → Repair → Test → Acceptance Criteria → Verification → Status`

## Project path
`Source → Requirement → Threat → Scenario → ADR → Specification → Implementation → Test → Evidence → Independent Verification → Release Gate`

Every security-critical change must be traceable through both paths.
