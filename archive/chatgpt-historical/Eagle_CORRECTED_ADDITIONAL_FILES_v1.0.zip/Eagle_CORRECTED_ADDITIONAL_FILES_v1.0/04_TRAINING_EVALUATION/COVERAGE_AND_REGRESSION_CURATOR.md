# Coverage and Regression Curator

## Responsibilities
- identify uncovered requirements/threats/scenarios;
- map tests to requirements and security invariants;
- detect regression escapes;
- propose new scenarios;
- preserve minimal reproductions;
- require re-verification after security-sensitive changes.

## Rule
Coverage metrics do not replace security judgment; they provide evidence for gaps and regression risk.
