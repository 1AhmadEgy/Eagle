# Training and Evaluation Framework

## Training layers
1. Knowledge and standards
2. Project architecture and invariants
3. Threat and scenario reasoning
4. Test generation
5. Failure injection
6. Detection/classification/RCA
7. Repair generation
8. Verification and regression
9. Governance and safety
10. Continuous reassessment

## Evaluation dimensions
- correctness
- security-policy compliance
- evidence quality
- reproducibility
- regression safety
- coverage improvement
- false-positive/false-negative behavior
- rollback correctness
- tool-use safety
- cost/resource bounds

## KPI examples
Coverage Gap Count, Regression Escape Rate, Automation Safety Rate, Verification Pass Rate, Evidence Completeness, Mean Time to Verified Fix.
