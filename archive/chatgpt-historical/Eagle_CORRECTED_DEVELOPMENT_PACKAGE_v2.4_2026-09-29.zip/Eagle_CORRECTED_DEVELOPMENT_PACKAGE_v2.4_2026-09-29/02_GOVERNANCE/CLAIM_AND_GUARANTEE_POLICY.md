# Claim and Guarantee Policy

Eagle documentation must distinguish:
- specified behavior;
- intended behavior;
- implemented behavior;
- tested behavior;
- independently verified behavior;
- externally audited behavior.

Never describe a property as guaranteed when the evidence only supports an intention or specification.

Deletion language must distinguish logical deletion, cryptographic deletion, application deletion, OS/filesystem behavior, backups/restore, and forensic residual risk.

Security claims must identify scope, assumptions, version, environment, and evidence.
