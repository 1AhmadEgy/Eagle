# Open Decision Closure Protocol

Applies to OI-001..OI-008.

## Required evidence per decision
1. Problem statement.
2. Options considered.
3. Authoritative sources.
4. Security/threat impact.
5. Compatibility/interoperability impact.
6. License and maintenance review.
7. Prototype or implementation evidence where applicable.
8. Positive and negative tests.
9. Rollback/migration plan.
10. ADR approval.

## Closure rule
A decision moves from PENDING to ACCEPTED only when the decision record contains sufficient evidence. A document assertion alone is not implementation evidence.

## Reopening
Any protocol, platform, dependency, vulnerability, interoperability, or threat-model change reopens the affected decision and requires impact analysis.
