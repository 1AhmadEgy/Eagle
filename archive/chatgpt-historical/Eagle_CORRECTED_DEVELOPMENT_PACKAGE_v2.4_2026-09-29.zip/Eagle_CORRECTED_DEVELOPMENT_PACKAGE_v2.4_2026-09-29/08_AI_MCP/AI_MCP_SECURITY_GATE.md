# AI and MCP Security Gate

AI is an engineering/security-assistance layer outside the deterministic Security Kernel.

## Allowed
analysis, classification, test generation, research, documentation, code suggestions, candidate remediation, evidence summarization.

## Forbidden without explicit governed control
changing trust state, bypassing authentication/authorization, changing cryptographic policy, recovering secrets, deleting protected data, disabling controls, approving its own security finding, unrestricted tool execution.

## MCP/tool execution path
`Authentication → Authorization → Allowlist → Schema Validation → Argument Validation → Sandbox → Rate Limit → Audit → Execution`

## Agent contract
Every agent requires identity, role, authority, tools, allowed/forbidden data, allowed/forbidden actions, runtime/cost/tool limits, sandbox, approval rule, evidence requirement, verifier, rollback, and audit policy.
