# Security Invariant Catalog

Initial invariant families:

- INV-ID-001: identity binding cannot be silently replaced.
- INV-TRUST-001: untrusted/revoked devices cannot enter protected sessions.
- INV-KEY-001: secret key material is never emitted through ordinary telemetry/logging.
- INV-SESSION-001: invalid session state fails closed.
- INV-SESSION-002: downgrade must be explicitly prohibited or safely negotiated.
- INV-MSG-001: replay/duplicate handling is deterministic.
- INV-STORAGE-001: sensitive state uses the approved storage/key boundary.
- INV-DELETE-001: deletion semantics match the documented guarantee.
- INV-REC-001: recovery cannot silently bypass device trust.
- INV-TOOL-001: tools execute only through authentication, authorization, allowlist, schema validation, sandbox, rate limit and audit controls.
- INV-AI-001: AI cannot override deterministic security policy.
- INV-SC-001: release artifacts require provenance and verification evidence.

Each invariant must map to Requirement → Implementation → Test → Evidence.
