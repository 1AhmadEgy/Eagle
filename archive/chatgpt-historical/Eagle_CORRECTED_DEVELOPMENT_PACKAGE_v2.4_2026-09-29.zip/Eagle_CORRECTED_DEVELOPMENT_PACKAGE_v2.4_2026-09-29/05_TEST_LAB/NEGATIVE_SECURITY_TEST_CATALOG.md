# Negative and Security Test Catalog

Required scenario families before release:

A. Identity: identity substitution, stale identity, revoked identity.
B. Authentication: invalid credentials, replayed authentication, malformed proofs.
C. Device trust: revoked/unattested device, trust-state race, downgrade.
D. Crypto/session: malformed keys, invalid signatures, bad KEM results, ratchet state corruption.
E. Messaging: replay, duplication, reordering, truncation, tampering, oversized payloads.
F. Network: packet loss, delay, reordering, NAT failure, relay failure, reconnect storms.
G. Storage: corruption, rollback, WAL/journal residue, cache leakage, temporary-file leakage.
H. Deletion: logical deletion failure, restore from backup, stale indexes, attachment residue.
I. Recovery: unauthorized recovery attempt, partial recovery, rollback, device transfer abuse.
J. AI/MCP: prompt injection, tool poisoning, argument injection, confused deputy, excessive agency, secret exfiltration.
K. Supply chain: dependency compromise simulation, unsigned artifact, invalid provenance, tampered SBOM.
L. Resource exhaustion: rate-limit bypass, memory pressure, concurrency storms.

Each scenario must produce evidence and a regression test when a defect is found.
