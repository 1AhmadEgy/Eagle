# Evidence Graph Schema

Canonical chain:
`SOURCE → CLAIM → REQUIREMENT → THREAT → CONTROL → IMPLEMENTATION → TEST → RESULT → EVIDENCE → INDEPENDENT VERIFICATION → DECISION → RELEASE → RUNTIME → DRIFT → FINDING`

Minimum evidence object:
`EVIDENCE-ID, Type, Source/Artifact, Commit, Environment, Toolchain, Timestamp, Hash, Related Requirement, Test IDs, Result, Reviewer, Verifier, Reproducibility, Retention, Status`.

Documentation may establish a specification or policy claim but cannot substitute for executable implementation/test evidence.
