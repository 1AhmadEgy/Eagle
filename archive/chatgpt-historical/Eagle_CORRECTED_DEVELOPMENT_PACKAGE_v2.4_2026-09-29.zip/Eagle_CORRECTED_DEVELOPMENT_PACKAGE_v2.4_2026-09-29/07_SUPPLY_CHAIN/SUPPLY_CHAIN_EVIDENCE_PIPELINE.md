# Supply Chain Evidence Pipeline

Required chain:
`Source → Commit → Build → Tests → SBOM → Provenance → Attestation → Artifact → Signature → Verification`

## Baseline
- SLSA v1.2: approved specification.
- NIST SP 800-218 v1.1: final SSDF baseline.
- NIST SP 800-218A: final AI-focused SSDF community profile.

## Rust-oriented pipeline
`Cargo.toml/Cargo.lock → cargo-deny → cargo-audit/RustSec → cargo-auditable → SBOM → SLSA provenance → attestation → signing → release verification`.

OpenSSF Scorecard is an assessment signal, not a sole release verdict.

Draft standards must be marked DRAFT and must not silently replace final baselines.
