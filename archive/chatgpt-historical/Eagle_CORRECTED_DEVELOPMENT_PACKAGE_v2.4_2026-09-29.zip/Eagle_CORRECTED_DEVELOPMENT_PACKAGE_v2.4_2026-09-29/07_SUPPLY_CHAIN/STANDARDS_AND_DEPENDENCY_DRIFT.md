# Standards and Dependency Drift Engine

## Flow
`Standards / Dependencies / Platforms → Drift Detection → Impact Analysis → Security Review → Requirement/ADR → Test Matrix → Evidence → Release Gate`

## Trigger events
- new final standard/revision;
- protocol specification revision;
- dependency major/minor/security release;
- security advisory;
- platform API/security change;
- license change;
- maintenance abandonment;
- interoperability regression.

## Output
A drift record must identify affected components, claims, ADRs, tests, evidence, and whether release is blocked.
