# Missing Content Closure Register

| ID | Gap | Target | Required action | Gate |
|---|---|---|---|---|
| GAP-001 | Exact Signal implementation/version | Crypto registry + ADR | Record exact candidate, license, maintenance, advisories, tests | OI-001 |
| GAP-002 | Final PQXDH profile/parameters | Session specification | Freeze parameters only after implementation/test review | OI-002 |
| GAP-003 | V1 transport boundary | Network specification | Define direct/relay behavior and failure semantics | OI-003 |
| GAP-004 | Server ciphertext retention | Server contract | Define storage/TTL/deletion behavior | OI-004 |
| GAP-005 | Recovery protocol | Recovery specification | Separate identity recovery from data recovery | OI-005 |
| GAP-006 | Deletion guarantees | Deletion specification | Define logical/crypto/app/OS/backup guarantees and limits | OI-006 |
| GAP-007 | Server retention policy | Privacy/server contract | Define metadata and ciphertext retention explicitly | OI-007 |
| GAP-008 | Device trust states | Device trust specification | Define state machine, transitions, revocation and fail-closed behavior | OI-008 |
| GAP-009 | Executable implementation evidence | Evidence ledger | Intake repository/commit/build/tests/artifacts | Implementation Gate |
| GAP-010 | Protocol test vectors | Test lab | Add deterministic positive/negative vectors | Test Gate |
| GAP-011 | Mobile traceability | Mobile security registry | Map MASVS→MASWE→MASTG→Eagle TEST-ID→Evidence | Mobile Gate |
| GAP-012 | Standards/dependency drift | Engineering governance | Add scheduled drift review and impact process | Maintenance Gate |
