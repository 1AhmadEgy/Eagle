# Source and Adoption Normalization

## Problem
The project contains two valid but different vocabularies: source lifecycle/status and technology adoption lifecycle. They must not be silently merged.

## Canonical separation
### Source classification
STANDARD, OFFICIAL_DOCUMENTATION, REFERENCE_IMPLEMENTATION, LIBRARY, RESEARCH_PAPER, SECURITY_GUIDANCE, TESTING_STANDARD, TOOL, CASE_STUDY, PROJECT_DISCUSSION, ARCHIVED_REFERENCE, UNVERIFIED.

### Adoption lifecycle
REFERENCE, CANDIDATE, POC, ADOPTED, REQUIRED, OPTIONAL, DEFERRED, REJECTED, REPLACED.

### Evidence state
NOT_SUBMITTED, SUBMITTED, INCOMPLETE, ACCEPTED, VERIFIED, REJECTED.

## Rule
Presence in a source index never means adoption. Adoption requires problem/layer fit, authoritative source review, security review, maintenance/license review, compatibility review, threat analysis, prototype where needed, tests, ADR, and explicit status change.
