# Tool Qualification Registry

Each tool used to build, test, audit, or operate Eagle must be tracked independently from runtime dependencies.

Required fields:
`TOOL-ID, Name, Version, Repository, Official Docs, License, Maintainer, Maintenance Status, Advisories, Purpose, Threat Domain, Inputs, Outputs, Privileges, Network Access, Secret Access, Sandbox Requirement, CI Support, Reproducibility, Evidence Generated, False Positive Risk, Alternatives, ADR, Adoption Status, Last Review, Next Review`.

Initial qualification targets:
- cargo-deny
- cargo-audit / RustSec
- cargo-fuzz / libFuzzer
- CodeQL
- CycloneDX / SPDX
- Trivy
- SLSA provenance
- in-toto attestations
- Sigstore/Cosign
- OpenSSF Scorecard
- OWASP MASVS/MASWE/MASTG tooling
- MobSF
- Wireshark/tcpdump
- OpenTelemetry behind a privacy filter

No tool is automatically adopted into Eagle runtime.
