# Eagle Mobile Security Traceability

Canonical chain:
`MASVS Control → MASWE Weakness → MASTG Test → Eagle TEST-ID → Evidence → Independent Verification`

The mapping must be maintained separately for Android and iOS because platform controls and evidence differ.

Current external baseline:
- OWASP MASWE v1.0.0 is stable and contains 78 weaknesses across storage, crypto, auth, network, platform, code, resilience and privacy.
- MASTG v2.0.0 uses the MASVS→MASWE→MASTG relationship.

Eagle must not copy an OWASP checklist blindly; it should reference the current OWASP IDs and map only relevant controls/tests.
