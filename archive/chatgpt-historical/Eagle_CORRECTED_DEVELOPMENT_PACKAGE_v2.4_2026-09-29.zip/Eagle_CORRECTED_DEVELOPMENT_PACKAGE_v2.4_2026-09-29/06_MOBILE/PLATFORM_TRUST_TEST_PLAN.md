# Platform Trust Test Plan

## Android
Verify Keystore/StrongBox capability, key isolation, attestation behavior where used, backup/restore behavior, screen-lock/device-state dependencies, and failure behavior.

## Apple
Verify Secure Enclave-backed key workflows where used, App Attest flows where used, key lifecycle, assertion/attestation failures, device migration behavior, and recovery boundaries.

## Common
- rooted/jailbroken or compromised-device assumptions must be explicit;
- no platform capability is assumed universal;
- every platform-specific guarantee must cite the exact platform API/version and test environment.
