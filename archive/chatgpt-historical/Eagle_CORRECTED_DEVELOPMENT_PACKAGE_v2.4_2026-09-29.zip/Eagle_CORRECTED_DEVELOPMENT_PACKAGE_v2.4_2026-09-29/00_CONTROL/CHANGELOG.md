# Changelog

## v2.4 — 2026-09-29
- Added explicit source/adoption/evidence lifecycle separation.
- Added missing-content closure register.
- Added V1 implementation contract and protocol conformance specification.
- Added security invariant catalog and negative security test catalog.
- Added evidence graph schema.
- Added mobile MASVS/MASWE/MASTG traceability and platform trust plan.
- Added supply-chain evidence pipeline and standards/dependency drift engine.
- Added AI/MCP security gate.
- Added implementation intake and repository bootstrap guidance.
- Added release execution checklist.
- Added current external reference update.

## Important
This package is a corrective documentation/development baseline. It does not constitute implementation evidence or a production release.
