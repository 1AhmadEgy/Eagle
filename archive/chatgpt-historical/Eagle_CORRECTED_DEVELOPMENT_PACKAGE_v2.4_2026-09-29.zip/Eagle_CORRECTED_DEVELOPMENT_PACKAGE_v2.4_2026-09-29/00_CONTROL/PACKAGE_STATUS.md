# Package Status

| Area | Status | Meaning |
|---|---|---|
| Governance | READY-DOC | Documentation baseline available |
| Architecture | READY-DOC | Baseline available; implementation pending |
| Protocol | PENDING-IMPLEMENTATION | Specifications need executable conformance tests |
| Crypto/session | PENDING-DECISIONS | Exact implementation/version/profile still requires closure |
| Network | PENDING-IMPLEMENTATION | QUIC/ICE/TURN behavior requires implementation tests |
| Mobile | READY-DOC / TEST-PENDING | Mapping prepared; device evidence required |
| Storage/deletion/recovery | PENDING-IMPLEMENTATION | Guarantees require executable evidence |
| AI/MCP | READY-DOC | Governance defined; runtime integration pending |
| Supply chain | READY-DOC / EVIDENCE-PENDING | Tooling and attestations require actual CI artifacts |
| Release | BLOCKED | Release gates cannot pass without evidence |
