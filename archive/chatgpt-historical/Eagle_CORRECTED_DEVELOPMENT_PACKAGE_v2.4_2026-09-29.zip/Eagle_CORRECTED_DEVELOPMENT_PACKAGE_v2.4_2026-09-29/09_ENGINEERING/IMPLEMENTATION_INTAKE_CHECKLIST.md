# Implementation Intake Checklist

Before any implementation is marked ACCEPTED, collect:

- repository and exact commit;
- exact source paths;
- Rust/toolchain versions;
- Cargo.toml/Cargo.lock;
- build command and clean-build result;
- static-analysis results;
- dependency/advisory results;
- unit/integration/protocol tests;
- negative/security tests;
- fuzz/property tests where applicable;
- reproducible artifact metadata;
- SBOM;
- provenance/attestation;
- artifact signature and verification;
- reviewer and independent verifier;
- environment and timestamp;
- hashes of evidence artifacts.

If required evidence is missing, status remains INCOMPLETE/BLOCKED.
