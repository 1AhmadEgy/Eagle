# Protocol Conformance Specification

## Test classes
- serialization/parsing
- state-machine transitions
- authentication and authorization
- PQXDH parameter/profile conformance
- Double Ratchet state transitions
- replay and duplicate handling
- out-of-order handling
- malformed input rejection
- downgrade/capability negotiation
- error-code determinism
- version compatibility

## Every vector contains
`VECTOR-ID, Version, Preconditions, Input, Expected State, Expected Output/Error, Security Invariant, Negative/Positive, Evidence, Regression Status`.

## Rule
A passing happy-path test is insufficient. Every security-sensitive transition needs rejection/negative coverage.
