# V1 Implementation Contract

## Core boundary
The Rust core owns deterministic protocol/security state machines, identity interfaces, session state, trust decisions, recovery policy, deletion policy, and security policy.

Platform clients own platform integration and UI but cannot override security-kernel decisions.

## Required V1 components
1. Identity.
2. Device trust.
3. Key management.
4. 1:1 session establishment.
5. PQXDH profile after OI-002 closure.
6. Double Ratchet profile after OI-001/OI-002 closure.
7. Message/state machine.
8. Local sensitive-state storage boundary.
9. Minimal server/rendezvous contract.
10. Deterministic failure and downgrade handling.

## Fail-closed requirements
Unknown protocol version, invalid authentication, invalid trust state, malformed cryptographic state, unsupported security policy, or unverifiable required evidence must not silently downgrade to weaker behavior.
