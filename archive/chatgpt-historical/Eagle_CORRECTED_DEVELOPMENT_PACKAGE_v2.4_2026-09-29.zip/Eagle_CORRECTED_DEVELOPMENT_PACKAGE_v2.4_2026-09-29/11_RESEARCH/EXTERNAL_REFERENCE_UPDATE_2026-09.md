# External Reference Update — September 2026

## Verified baselines
- SLSA v1.2 is an approved specification: https://slsa.dev/spec/v1.2/
- NIST SP 800-218 v1.1 is final: https://csrc.nist.gov/pubs/sp/800/218/final
- NIST SP 800-218A is final and supplements SSDF 1.1 for AI: https://csrc.nist.gov/pubs/sp/800/218/a/final
- Signal Double Ratchet Revision 4 (2025-11-04): https://signal.org/docs/specifications/doubleratchet/
- Signal PQXDH Revision 3, last updated 2024-01-23: https://signal.org/docs/specifications/pqxdh/
- OWASP MASWE v1.0.0 is stable (2026-08-17): https://mas.owasp.org/news/2026/08/17/maswe-v100-release/

## Policy
Final standards remain authoritative over drafts. Draft/future revisions may be monitored through the drift engine but must not silently become project requirements.
