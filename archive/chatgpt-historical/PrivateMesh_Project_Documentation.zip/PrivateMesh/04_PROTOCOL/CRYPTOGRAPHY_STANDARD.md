# معايير التشفير المعتمدة
- **إنشاء الجلسات:** PQXDH (Post-Quantum Extended Diffie-Hellman).
- **تشفير الرسائل:** Double Ratchet Algorithm.
- **معايير NIST 2024:** التطبيق الإلزامي لمعايير ML-KEM (FIPS 203) و ML-DSA (FIPS 204) و SLH-DSA (FIPS 205).
- **القاعدة الذهبية:** يُمنع قطعياً ابتكار أي خوارزميات تشفير خاصة.
