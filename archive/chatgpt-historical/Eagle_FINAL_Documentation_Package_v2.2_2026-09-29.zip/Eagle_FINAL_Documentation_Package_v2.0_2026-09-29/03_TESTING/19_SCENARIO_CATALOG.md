# Scenario Catalog
## Domains A–Z
A Normal operations; B identity/device; C authz; D crypto; E PQ; F messaging; G attachments; H server compromise; I transport/NAT; J QUIC; K storage; L deletion/forensics; M recovery; N metadata; O mobile; P telemetry; Q supply chain; R release; S AI; T MCP; U abuse; V performance; W disaster recovery; X governance; Y social engineering; Z compound scenarios.

## Scenario record
ID, domain, preconditions, actor, capability, trigger, sequence, expected behavior, invariant, detection, containment, recovery, evidence, regression test, severity, likelihood, impact, dependencies, version, status, source, ADR, requirement and test case.
