# Test Architecture
## Layers
Unit → Component → Integration → Protocol → Interoperability → Property → Fuzz → State Machine → Network/NAT → Storage → Deletion → Recovery → Platform → Performance → Concurrency → Failure Injection → Regression → Supply Chain → Security Review.

## Rule
A green build is not security evidence by itself.

## Required outputs
Test ID, requirement, scenario, environment, inputs, expected result, actual result, artifact/evidence, reviewer and regression linkage.
