# Evidence Graph
## Chain
`Source → Requirement → Threat → Scenario → Code/Artifact → Test → Result → Finding → Patch → Verification → ADR → Release Gate`

## Evidence rules
- Immutable identifier
- timestamp/version
- source reference
- environment
- artifact hash where applicable
- reviewer
- status
- supersession history

## Knowledge states
`VERIFIED / PROPOSED / UNKNOWN / REJECTED`
