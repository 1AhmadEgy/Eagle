# Security Lab
## Pipeline
Governance → Orchestrator → Scenario Selection → Scenario Generator → Safety Preflight → Injector → SUT → Telemetry → Detector → Classifier → RCA → Remediation → Independent Verification → Regression → Evidence → Report.

## Lab modes
Red / Blue / Purple.

## Safety
Tests are authorized, isolated and reproducible. Real user secrets/data are excluded.

## AI
AI may generate candidates and analyze results but cannot bypass safety controls or approve its own findings.


## Research-integrated cyber-range realism
The reviewed GHOSTS research indicates that realistic exercises require more than random traffic. The isolated lab may therefore provide controlled, synthetic:
- plausible websites, documents, media and downloadable objects;
- dynamic content resolution inside the closed environment;
- benign background activity and recurring user behavior;
- participatory uploads/shares and realistic workflow context;
- controlled red-team payloads separated from ordinary baseline activity.

These capabilities are **lab-only** and must use synthetic data, isolation and explicit authorization. They do not authorize arbitrary live-internet content or uncontrolled payload execution.

## Optional analysis research hooks
Process mining, drift detection and causal-analysis techniques may be evaluated for RCA and scenario analysis. They are research/tooling candidates, not mandatory dependencies.
