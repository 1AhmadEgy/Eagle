# Conflict / Ambiguity Register — v2.0

| ID | Topic | Evidence A | Evidence B | Resolution |
|---|---|---|---|---|
| CR-001 | Android-first vs cross-platform | Earlier Android-first discussion | Cross-platform architecture discussion | Current baseline treats cross-platform core as the architectural direction; Android/iOS remain implementation tracks. |
| CR-002 | Server storage model | Project baseline contains gated transient-ciphertext options | Earlier discussions include stronger “no server content storage” language | Remains OI-004 gated; no silent closure. |
| CR-003 | Recovery | Several proposals mention recovery codes/trusted contacts/identity proofing | Baseline requires separated recovery policy | Keep account/data recovery separation; exact mechanism remains OI-007. |
| CR-004 | Agent count | Research describes 7–12 conceptual agents | Project architecture uses role model + autonomy levels | No fixed agent count; roles may be implemented by fewer or more components under governance. |
| CR-005 | Observability stack | Research suggests Kafka/Elasticsearch/etc. | Baseline favors minimized observability and avoids automatic adoption | Tooling is candidate-only and must pass adoption gate. |
| CR-006 | Crypto primitives | Research discussion names AES/ChaCha as additional layers | Signal-based protocol baseline already defines cryptographic construction | Do not add ad-hoc crypto layers; use protocol-defined constructions and approved storage encryption only where justified. |
| CR-007 | Tor | Some discussions treat Tor as optional/default in particular modes | Baseline does not make it universally mandatory | Tor remains an optional transport/privacy capability subject to threat model and UX/platform gates. |
