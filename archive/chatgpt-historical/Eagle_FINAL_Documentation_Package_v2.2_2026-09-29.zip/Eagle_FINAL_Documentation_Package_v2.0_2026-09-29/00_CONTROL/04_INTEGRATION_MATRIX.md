# Integration Matrix — v2.0

| Source | Finding | v1.0 coverage | v2.0 action | Authority | Status |
|---|---|---|---|---|---|
| Cross-platform architecture discussion | Cross-platform core; platform-independent protocol/backend | Partial | Clarified as architecture direction; implementation still gated | Project discussion | Integrated as proposal |
| Same source | P2P + relay/TURN fallback | Present | Cross-linked to Network/Protocol specs | Project discussion + RFC references | Integrated |
| Same source | Local identity/key protection and recovery | Present/partial | Added to research integration map; no automatic closure | Project discussion | Integrated, gated |
| DeepSeek lab discussion | Scenario factory, fault injection, RCA, remediation, verification, regression | Present | Extended agent responsibility map | AI/lab methodology | Integrated |
| DeepSeek lab discussion | Regression Curator | Implicit | Explicit role added | AI/lab methodology | Integrated |
| DeepSeek lab discussion | Knowledge Curator | Missing as explicit role | Explicit role added | AI/lab methodology | Integrated |
| DeepSeek lab discussion | Isolated synthetic environment | Present | Strengthened with realism layer | Methodology | Integrated |
| DeepSeek Into Unknown | 10–12 agent conceptual pipeline | Partial | Mapped to project role model without forcing agent count | Research/conversation | Integrated as mapping |
| DeepSeek Into Unknown | Kafka/Elasticsearch/OPA/etc. | Not authoritative | Recorded as candidate tooling only | Research/conversation | Non-adoption / gated |
| GHOSTS 2026 report | Air-gapped realism and plausible content | Missing | Added controlled range-realism requirements | Research report | Integrated as lab requirement |
| GHOSTS 2026 report | Dynamic content / plausible URLs / benign baseline activity | Missing | Added to isolated-lab design | Research report | Integrated |
| GHOSTS 2026 report | Participatory realistic user activity | Missing | Added to scenario realism guidance | Research report | Integrated |
| Reference library | Signal/NIST/IETF/OWASP/platform sources | Present | Registry preserved and promoted as source authority | Normative/official | Integrated |
