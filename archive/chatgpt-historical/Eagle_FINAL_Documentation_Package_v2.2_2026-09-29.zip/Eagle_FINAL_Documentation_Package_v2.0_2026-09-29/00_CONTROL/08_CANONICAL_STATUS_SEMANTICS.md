# Canonical Status Semantics

| Status | Meaning |
|---|---|
| PROPOSED | Candidate decision or design; not binding implementation authority. |
| UNDER_REVIEW | Being evaluated; not approved. |
| ACCEPTED-AS-REFERENCE | External source is accepted as a reference; it does not mandate adoption. |
| ACCEPTED | Project decision approved through the required governance gate. |
| IMPLEMENTED | Implemented in source/build artifacts; requires evidence. |
| VERIFIED | Independently verified against defined acceptance criteria; requires evidence. |
| DEFERRED | Deliberately postponed by an explicit decision. |
| REJECTED | Explicitly not adopted. |
| DEPRECATED | Previously accepted/used but superseded. |
| UNKNOWN | Evidence is insufficient to classify the state. |

## Critical rule
`FINAL DOCUMENTATION BASELINE` describes documentation status only. It never means implementation complete, security verified, or production approved.
