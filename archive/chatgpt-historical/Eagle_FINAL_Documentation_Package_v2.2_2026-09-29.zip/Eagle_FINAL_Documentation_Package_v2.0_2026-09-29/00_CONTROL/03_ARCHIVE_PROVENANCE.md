# Archive Provenance and Deduplication Policy

The following historical packages were inventoried and compared. Their duplicate content is not copied into the active v2.0 baseline:

- `Eagle_FINAL_Documentation_Package_v1.0_2026-09-29.zip`
- `Eagle_PrivateMesh_Baseline_Package_2026-09-29.zip`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28.zip`
- `Eagle_PrivateMesh_Documentation_Pack_2026-09-28_v0.3.zip`
- `Eagle_Team_Work_Packages_v1.1.zip`
- `Eagle_Master_Reference_Library_v1.0.zip`
- `Eagle_ALL_PROJECT_DOCUMENTS_2026-09-29.zip`

Exact normalized-content comparison confirmed repeated copies of many project documents across these packages. Historical versions remain provenance evidence, but only the v2.0 active documents are authoritative for the current documentation baseline.
