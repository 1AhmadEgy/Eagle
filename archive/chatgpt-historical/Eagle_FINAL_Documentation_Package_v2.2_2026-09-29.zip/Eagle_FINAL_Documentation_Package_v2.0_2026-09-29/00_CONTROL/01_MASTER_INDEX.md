# Eagle — Final Master Index

## 1. Authority
This index is navigation only. It does not override specifications or ADRs.

## 2. Document map
- 01 Product / Architecture / Protocol / Crypto / Identity / Device / Server / Storage / Deletion / Recovery / Network / Android / iOS / UIUX
- 02 Threat Model / Security Invariants
- 03 Test Architecture / Security Lab / Scenarios / Evidence
- 04 AI / MCP / Supply Chain / CI/CD / Observability / Incident
- 05 ADR / Requirements / Release Gates / Roadmap / Registries / Risks / Debt / Drift / Performance / Accessibility / Localization / Migration / DR / External Audit
- 06 Team Work Packages
- 07 Reference Library
- 90 Historical archive

## 3. Status vocabulary
`VERIFIED | ACCEPTED | PROPOSED | UNDER_REVIEW | UNKNOWN | DEFERRED | REJECTED | DEPRECATED`

## 4. Rule
No document may promote an UNKNOWN/PROPOSED item to implementation authority without the required ADR, evidence, and gate.
