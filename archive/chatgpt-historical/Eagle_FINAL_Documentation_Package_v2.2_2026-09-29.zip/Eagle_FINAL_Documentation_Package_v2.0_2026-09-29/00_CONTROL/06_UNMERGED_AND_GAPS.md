# Previously Unmerged / Newly Strengthened Items

## Integrated in v2.0
- Cross-platform core as a first-class architecture concern.
- Explicit mapping of Regression Curator and Knowledge Curator functions.
- Air-gapped cyber-range realism as a lab capability, not a production-network assumption.
- Dynamic synthetic content / plausible URL and object resolution for isolated training.
- Benign background activity and realistic user behavior baselines.
- Process-mining and causal-analysis research hooks as optional analysis capabilities.
- Explicit separation between research suggestions and adopted dependencies.

## Still intentionally open
- OI-001 exact Signal implementation/version.
- OI-002 PQXDH integration profile.
- OI-003 V1 transport boundary.
- OI-004 server ciphertext retention.
- OI-005 identity/device trust states.
- OI-006 device linking.
- OI-007 recovery protocol.
- OI-008 deletion guarantees.

## Not merged as design decisions
- Kafka as mandatory infrastructure.
- Elasticsearch as mandatory infrastructure.
- OPA as mandatory policy engine.
- LagRCA/CSnake as mandatory RCA engines.
- Any specific ML framework as mandatory.
- Any AI agent framework as mandatory.
