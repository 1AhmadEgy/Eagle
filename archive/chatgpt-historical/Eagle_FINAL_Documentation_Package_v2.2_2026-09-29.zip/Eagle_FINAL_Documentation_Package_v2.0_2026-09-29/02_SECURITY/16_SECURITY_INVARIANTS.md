# Security Invariants
1. Untrusted server cannot decrypt protected message content.
2. Private keys are not emitted to logs/telemetry.
3. Security-critical ambiguity fails closed.
4. Device trust is explicit.
5. Recovery cannot bypass security policy.
6. Deletion policy cannot be bypassed through alternate storage paths.
7. Version negotiation cannot silently downgrade security.
8. AI cannot directly change trust/crypto/auth/deletion policy.
9. Tool execution requires authorization and validation.
10. Release artifacts require integrity/provenance evidence.
