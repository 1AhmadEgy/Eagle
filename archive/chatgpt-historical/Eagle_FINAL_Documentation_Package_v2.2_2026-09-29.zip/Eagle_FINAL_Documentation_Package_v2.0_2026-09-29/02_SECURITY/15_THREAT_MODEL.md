# Threat Model
## Domains
Identity, authentication, device trust, key management, sessions, messaging, transport, NAT, server compromise, client compromise, storage, deletion, recovery, supply chain, build/release, updates, telemetry, AI, tools/MCP, social engineering and metadata.

## Method
Asset → Actor → Capability → Attack path → Impact → Existing control → Detection → Containment → Recovery → Evidence.

## Severity
Use project-approved severity definitions; do not rely on intuition alone.

## Rule
Every security-critical change must update affected threats/scenarios.
