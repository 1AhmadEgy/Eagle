# Supply Chain Security
## Controls
- pinned dependencies
- vulnerability/advisory review
- SBOM
- provenance
- signed artifacts
- reproducible-build target
- CI isolation
- release verification
- dependency ownership/maintenance review

## Reference
SLSA 1.2 is the current approved SLSA specification; project adoption level must be explicitly decided rather than assumed.

## Gate
No untracked dependency or unsigned/unverified release artifact enters production.
