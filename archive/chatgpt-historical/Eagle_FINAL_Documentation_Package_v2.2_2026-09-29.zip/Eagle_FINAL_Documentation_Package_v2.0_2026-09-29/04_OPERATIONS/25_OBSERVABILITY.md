# Observability
## Two planes
1. Engineering telemetry
2. Production privacy-safe telemetry

## Denylist
Plaintext messages, private keys, recovery secrets, attachment plaintext and unnecessary PII.

## Controls
Allowlist schemas, minimization, redaction, retention/access policy and instrumentation review.

## Rule
Telemetry libraries are part of the security boundary and must be tested for accidental disclosure.
