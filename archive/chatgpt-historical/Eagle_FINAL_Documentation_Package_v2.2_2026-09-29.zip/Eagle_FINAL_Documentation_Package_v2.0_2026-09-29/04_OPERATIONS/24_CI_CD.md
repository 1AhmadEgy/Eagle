# CI/CD
## Pipeline
Source → Review → Static Analysis → Dependency Audit → Unit → Integration → Protocol → Fuzz/Property → Security → Build → SBOM → Provenance → Signing → Verification → Release.

## Branch/review rules
Security-critical changes require appropriate reviewers and evidence.

## Secrets
Use CI secret management; never commit secrets; minimize token permissions and lifetime.
