# Incident / RCA
## Lifecycle
Detect → Contain → Preserve evidence → Triage → Scope → Root cause → Remediate → Verify → Regress → Document → Prevent recurrence.

## RCA requirements
Timeline, affected versions, attack/control path, evidence, root cause, contributing factors, remediation and regression test.

## Security incidents
Do not erase evidence before preservation requirements are satisfied.
