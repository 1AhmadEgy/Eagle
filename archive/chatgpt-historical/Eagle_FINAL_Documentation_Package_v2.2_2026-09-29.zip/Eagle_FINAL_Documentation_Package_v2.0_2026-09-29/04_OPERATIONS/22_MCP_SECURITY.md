# MCP / Tool Security
## Mandatory pipeline
`Authentication → Authorization → Allowlist → Schema Validation → Argument Validation → Sandbox → Rate Limit → Audit → Execution`

## Rules
- No arbitrary tool access.
- Least privilege.
- Explicit data allowlist.
- Sensitive actions require approval.
- Tool output is untrusted input.
- Every tool call is auditable.

## Tests
Privilege escalation, argument fuzzing, schema bypass, prompt injection, data exfiltration and sandbox escape attempts in an isolated lab.
