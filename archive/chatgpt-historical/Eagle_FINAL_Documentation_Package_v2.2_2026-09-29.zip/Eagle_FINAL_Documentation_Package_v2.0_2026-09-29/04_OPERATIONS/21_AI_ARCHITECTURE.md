# AI Architecture
## Boundary
AI is outside the Security Kernel.

## Allowed
Detection, classification, analysis, recommendation, candidate test generation, documentation assistance, controlled code generation.

## Forbidden without explicit governed mechanism
Changing trust state, crypto policy, auth policy, deleting protected data, disabling controls, accessing arbitrary tools, approving own findings.

## Agent model
Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

## Autonomy
A0–A7; sensitive actions require approval and deterministic verification.

## AI evaluation
Prompt injection, tool misuse, privilege escalation, leakage, false positives/negatives, inconsistency, memory/context poisoning, telemetry poisoning, model drift and regression.


## Research-integrated agent responsibilities
The research material describes additional functional roles. They are mapped to the project role model rather than forcing a fixed number of independent agents:
- **Regression Curator:** converts verified findings and fixes into durable regression cases.
- **Knowledge Curator:** updates project knowledge/evidence links after independent verification.
- **Reporter:** produces evidence-bound reports and release artifacts.

These functions remain governed by the existing autonomy, evidence, approval, sandbox, rollback and independent-verification rules.

## Agent-selection principle
Agent selection is capability-based, not vendor- or framework-based. A candidate implementation must pass security, maintenance, licensing, isolation, reproducibility, tool-permission and verification gates before adoption.
