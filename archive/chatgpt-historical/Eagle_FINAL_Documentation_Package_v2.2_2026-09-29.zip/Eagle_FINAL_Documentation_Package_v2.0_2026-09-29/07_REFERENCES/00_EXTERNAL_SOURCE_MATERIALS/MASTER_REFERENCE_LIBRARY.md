# Eagle Master Reference Library v1.0

## 1. Purpose
هذه المكتبة هي سجل مصادر ومراجع ومشاريع مرجعية لمرحلة ما قبل الكود في Eagle / PrivateMesh.

## 2. حالات المرجع
- PROPOSED
- UNDER_REVIEW
- ACCEPTED_REFERENCE
- ADOPTED
- IMPLEMENTED
- VERIFIED
- DEPRECATED
- REJECTED

## 3. قواعد الاعتماد
Research != Adoption  
Reference != Dependency  
Candidate != Approved  
Approved != Implemented  
Implemented != Verified

## 4. سلسلة التتبع
Source -> Requirement -> ADR -> Threat -> Security Invariant -> Scenario -> Test -> Evidence -> Independent Verification -> Release Gate

## 5. بوابات القرار
G0 Source Integrity
G1 Architecture Freeze
G2 Crypto Freeze
G3 Mobile Security
G4 Observability Safety
G5 Supply Chain
G6 Security Verification
G7 Production

## 6. Stop-the-Line
أي خلل تشفيري حرج، تجاوز للمصادقة أو الثقة، تسريب مفاتيح/نص صريح، غموض هوية أو حالة جهاز، تجاوز recovery/deletion policy، downgrade غير محمي، dependency حرجة غير موثوقة، build/release compromise، supply-chain issue خطير، telemetry تكشف أسرارًا، أو تجاوز AI/MCP للصلاحيات يوقف الانتقال حتى المعالجة.

## 7. مخططات مطلوبة
Architecture: System Context, Container, Component, Deployment, Data Flow, Trust Boundaries.
Security: Threat Model, Attack Surface, Trust Model, Key Lifecycle, Identity Lifecycle, Device Trust, Session Lifecycle, Recovery, Deletion.
Protocol: PQXDH, Double Ratchet, Message Envelope, Message State Machine, Replay, Offline Delivery, Attachment.
Network: Connection Establishment, ICE, STUN, TURN, QUIC, Path Migration.
Mobile: Android Keystore, Attestation, StrongBox Capability, Secure Enclave, App Attest.
Engineering: Test Pipeline, Security Lab, Fuzzing, SBOM, Provenance, Release Signing, Evidence Graph, AI Control Plane, MCP Security Gate, AI Kill Switch.

## 8. قاعدة Core
Eagle Core يجب أن يظل قادرًا على العمل بأمان دون AI. AI/MCP/Automation أدوات هندسية محكومة وليست جذور ثقة.

## 9. ملاحظة
المراجع في السجل لا تعني دمجها في الكود ولا تعني التحقق من تنفيذ Eagle.
