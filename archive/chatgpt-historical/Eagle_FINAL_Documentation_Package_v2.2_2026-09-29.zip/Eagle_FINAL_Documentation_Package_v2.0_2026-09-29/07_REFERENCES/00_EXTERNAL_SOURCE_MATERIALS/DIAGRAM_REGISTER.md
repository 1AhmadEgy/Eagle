# Eagle Diagram Register v1.0

| ID | Diagram | Layer | Purpose |
|---|---|---|---|
| D-001 | System Context | Architecture | حدود النظام والأطراف |
| D-002 | Container | Architecture | الخدمات والمكونات |
| D-003 | Trust Boundaries | Security | حدود الثقة |
| D-004 | Identity Lifecycle | Identity | دورة الهوية |
| D-005 | Device Trust State Machine | Security | حالات الثقة |
| D-006 | Key Lifecycle | Crypto | دورة المفاتيح |
| D-007 | PQXDH Flow | Crypto | إنشاء الجلسة |
| D-008 | Double Ratchet | Crypto | دوران المفاتيح |
| D-009 | Message State Machine | Protocol | الإرسال والتسليم وACK وReplay |
| D-010 | ICE/TURN | Network | الاتصال المباشر والـRelay |
| D-011 | QUIC | Network | طبقة النقل |
| D-012 | Recovery | Data | فصل account recovery عن data recovery |
| D-013 | Deletion | Data | ضمانات الحذف متعددة الطبقات |
| D-014 | Mobile Trust | Mobile | Android/iOS capabilities |
| D-015 | Test Lab | Engineering | scenario إلى evidence |
| D-016 | Evidence Graph | Governance | source إلى gate |
| D-017 | Supply Chain | Release | SBOM/provenance/signing |
| D-018 | AI Control Plane | AI | حوكمة دورة AI |
| D-019 | MCP Security Gate | AI | auth/authz/allowlist/sandbox/audit |
| D-020 | Release Gates | Governance | G0-G7 |
