# Research Integration Digest

## 1. Cross-platform architecture source
The supplied architecture discussion argues for a platform-independent core, with Android/iOS/Desktop/Web as clients around a common protocol/backend boundary. It also discusses Signal Protocol, local key protection, P2P/relay fallback, and recovery. These points are treated as project discussion and mapped to existing specifications; normative cryptographic authority remains with the referenced official specifications.

## 2. DeepSeek isolated-lab sources
The supplied conversations propose a governed loop: scenario generation → injection/execution → detection/classification → RCA → remediation → independent verification → regression → knowledge/reporting. They also propose explicit agent functions and operational templates. v2.0 maps these functions to the existing Eagle agent model without requiring a fixed agent count or a specific vendor framework.

## 3. GHOSTS report
The supplied 2026 report describes lessons from cyber-range realism, including air-gapped content environments, dynamic/plausible content, realistic background activity, document/media exchange, and coherent user behavior. v2.0 incorporates these as isolated security-lab realism requirements using synthetic data only.

## 4. Tooling suggestions
References to Kafka, Elasticsearch, OPA, causal-analysis tools, ML frameworks and other infrastructure are preserved as research candidates. They are not adopted automatically. Adoption remains subject to the Eagle research-to-implementation gate.

## 5. Security interpretation
None of these research artifacts is allowed to override normative standards, official platform security documentation, the Eagle security invariants, or an approved ADR.
