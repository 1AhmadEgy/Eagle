# Eagle — Reference Registry Baseline

## Normative / primary
- Signal Double Ratchet — Revision 4, 2025-11-04.
- Signal PQXDH.
- NIST FIPS 203 — ML-KEM.
- NIST FIPS 204 — ML-DSA.
- NIST FIPS 205 — SLH-DSA.
- IETF RFC 9420 — MLS.
- IETF RFC 9000 — QUIC.
- IETF RFC 8445 — ICE.
- IETF RFC 8656 — TURN.
- OWASP MASVS / MASTG.
- Android Keystore / platform security documentation.
- Apple Secure Enclave / App Attest documentation.
- NIST SSDF SP 800-218 and relevant newer draft/profile material.
- SLSA v1.2.

## Research / methodology
- GHOSTS-related cyber-range research supplied by the project.
- DeepSeek cyber-range material supplied by the project.
- Academic/security studies in the supplied reference library.

## Adoption rule
Presence here means reference/candidate only. Adoption requires the project adoption gate and evidence.
