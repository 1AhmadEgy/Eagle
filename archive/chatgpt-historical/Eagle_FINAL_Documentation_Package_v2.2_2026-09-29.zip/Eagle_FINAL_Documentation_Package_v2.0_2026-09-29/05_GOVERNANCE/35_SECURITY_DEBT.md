# Security Debt
Track missing controls, unverified assumptions, test gaps, unsupported claims and unresolved security findings.

Security debt is not closed by documentation alone; it requires evidence.
