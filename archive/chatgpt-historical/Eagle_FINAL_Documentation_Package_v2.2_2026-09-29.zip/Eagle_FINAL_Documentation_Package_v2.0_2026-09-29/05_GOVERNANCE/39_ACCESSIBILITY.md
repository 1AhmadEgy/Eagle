# Accessibility
## Scope
Screen readers, keyboard navigation, dynamic text, contrast, focus, touch targets, error messaging and reduced-motion considerations.

## Security
Accessibility must not remove authentication, verification or security warnings; instead provide equivalent accessible semantics.
