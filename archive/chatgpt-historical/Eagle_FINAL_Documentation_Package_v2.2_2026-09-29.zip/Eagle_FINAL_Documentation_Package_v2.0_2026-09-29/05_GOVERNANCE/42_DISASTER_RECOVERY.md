# Disaster Recovery
## Scope
Service outage, key service outage, build compromise, corrupted metadata, dependency compromise and infrastructure loss.

## Principles
- minimize server-side critical state
- separate operational recovery from encrypted-data recovery
- maintain tested rollback/rebuild procedures
- preserve security evidence during incidents

## Tests
Restore/rebuild exercises, dependency outage, corrupted-state and release rollback scenarios.
