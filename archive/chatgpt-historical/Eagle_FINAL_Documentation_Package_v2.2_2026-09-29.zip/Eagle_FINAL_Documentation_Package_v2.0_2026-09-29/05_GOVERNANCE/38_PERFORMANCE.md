# Performance & Reliability
## Budgets
CPU, memory, battery, network, storage, startup and cryptographic operation latency.

## Principle
Never improve a performance metric by removing a security control without an explicit risk decision.

## Tests
Repeatable benchmarks, load, concurrency, resource exhaustion, battery/platform testing and regression thresholds.
