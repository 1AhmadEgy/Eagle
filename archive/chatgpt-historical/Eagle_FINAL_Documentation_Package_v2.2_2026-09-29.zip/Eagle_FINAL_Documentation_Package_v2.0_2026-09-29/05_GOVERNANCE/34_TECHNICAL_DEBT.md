# Technical Debt
Track deferred engineering choices, temporary implementations, duplicated logic, missing automation and interoperability gaps.

Each item requires owner, impact, trigger, planned resolution and review date.
