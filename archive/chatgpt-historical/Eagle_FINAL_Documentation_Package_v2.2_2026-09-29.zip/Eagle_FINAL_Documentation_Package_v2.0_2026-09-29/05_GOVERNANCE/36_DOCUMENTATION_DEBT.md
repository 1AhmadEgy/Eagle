# Documentation Debt
Track stale references, conflicting terminology, missing diagrams, unlinked requirements, outdated versions and missing operational runbooks.

Documentation changes affecting authority must be reviewed against ADR/spec ownership.
