# Compatibility & Migration
## Required
Protocol versioning, capability negotiation, migration plans, schema migrations, rollback, downgrade prevention and crypto agility.

## Rule
Backward compatibility cannot override a security invariant.

## Migration evidence
Old/new interoperability tests, rollback tests and downgrade-resistance tests.
