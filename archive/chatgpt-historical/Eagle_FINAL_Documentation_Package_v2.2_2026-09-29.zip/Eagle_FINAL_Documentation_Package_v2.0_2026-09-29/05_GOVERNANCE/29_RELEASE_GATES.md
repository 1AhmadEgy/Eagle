# Release Gates
## G0 Source Integrity
Canonical URLs, versions, revisions, obsolete status, errata.

## G1 Architecture Freeze
V1 scope, transport, server retention, identity/device, recovery, deletion.

## G2 Crypto Freeze
Exact protocol revision, implementation/library, parameters, serialization, lifecycle, migration, vectors.

## G3 Mobile Security
MASVS mapping, storage/auth/network/platform/privacy/SBOM tests.

## G4 Observability Safety
Schema, denylist, instrumentation, minimization and retention.

## G5 Supply Chain
Pinned dependencies, advisories, SBOM, provenance, signed artifacts, reproducibility target.

## G6 Security Verification
Full test and independent security review.

## G7 Production
No production clearance until required evidence exists and P0/P1 blockers are formally handled.
