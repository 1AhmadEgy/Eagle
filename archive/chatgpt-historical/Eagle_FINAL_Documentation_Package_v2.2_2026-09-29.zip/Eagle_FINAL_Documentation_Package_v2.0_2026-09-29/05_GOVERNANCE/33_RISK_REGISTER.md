# Risk Register
## Major current risks
- unresolved crypto implementation/version
- unresolved PQXDH profile
- unresolved V1 transport boundary
- unresolved server retention contract
- unresolved identity/device linking
- unresolved recovery
- unresolved deletion semantics
- platform capability variance
- supply-chain compromise
- telemetry leakage
- AI/tool privilege escalation

## Treatment
Avoid / Mitigate / Transfer / Accept only through authorized governance.
