# ADR Registry
## Authority
ADRs record decisions; they do not replace detailed specifications.

## Existing critical decisions
- ADR-0001 V1 protocol baseline — proposed
- ADR-0002 TURN RFC 8656 reference — accepted as reference
- ADR-0003 transient ciphertext retention — proposed
- ADR-0004 device trust state machine — proposed
- ADR-0005 recovery separation — proposed
- ADR-0006 deletion guarantee layers — proposed
- ADR-0007 platform capability policy — proposed
- ADR-0008 observability minimization — proposed

## Rule
A decision is not “implemented” merely because an ADR exists.
