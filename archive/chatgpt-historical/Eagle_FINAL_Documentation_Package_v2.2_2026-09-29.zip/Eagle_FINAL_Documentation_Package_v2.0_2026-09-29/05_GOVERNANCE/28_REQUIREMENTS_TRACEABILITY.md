# Requirements Traceability
## Required linkage
Requirement → Architecture element → Threat → Invariant → Scenario → Test → Evidence → Release Gate.

## Status
The traceability framework is defined; implementation-level linkage is incomplete until code and tests exist.

## Rule
Unlinked security claims are not release evidence.
