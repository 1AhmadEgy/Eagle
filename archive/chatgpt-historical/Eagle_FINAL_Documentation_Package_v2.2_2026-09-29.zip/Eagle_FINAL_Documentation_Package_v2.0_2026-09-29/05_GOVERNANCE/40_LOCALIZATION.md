# Localization
## Scope
Arabic/RTL and future locales, dates, numbers, errors, security warnings and recovery text.

## Rules
Security meaning must remain semantically equivalent across translations. No localization may weaken consent or warning states.
