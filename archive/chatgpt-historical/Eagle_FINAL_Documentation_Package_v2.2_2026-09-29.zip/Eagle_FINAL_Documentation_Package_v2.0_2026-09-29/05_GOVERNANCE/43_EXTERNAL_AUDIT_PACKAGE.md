# External Audit Package
## Purpose
Provide an auditor with a reproducible evidence package.

## Contents
- architecture
- threat model
- crypto/protocol specification
- security invariants
- requirements traceability
- dependency/SBOM/provenance
- test reports
- fuzz/property results
- platform security results
- deletion/recovery evidence
- incident history
- release artifacts
- open findings and accepted risks

## Auditor independence
The external reviewer must not be the sole author/approver of the security controls being assessed.
