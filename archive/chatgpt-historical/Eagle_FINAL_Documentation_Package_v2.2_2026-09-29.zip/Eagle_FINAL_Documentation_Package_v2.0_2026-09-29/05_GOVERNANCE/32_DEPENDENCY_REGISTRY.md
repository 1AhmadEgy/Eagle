# Dependency Registry
## Required fields
Package, version, source, checksum/lock, license, maintainer health, advisory status, supported platform, transitive risk, purpose, owner, replacement plan, last review.

## Rule
No dependency is production-approved solely because it compiles.
