# Roadmap
## V1
Stable single-device private messaging core and minimal supporting services, after G1/G2 decisions.

## V1.x
Connectivity hardening, NAT/ICE/TURN refinement, platform hardening, observability and operational maturity.

## V2
Group messaging/MLS, broader PQ migration and additional platforms only after V1 stability and security evidence.

## V3
Advanced automation/AI, broader resilience and optional privacy/network capabilities.

## Rule
Do not add V2/V3 scope to V1 implementation merely because a technology is available.
