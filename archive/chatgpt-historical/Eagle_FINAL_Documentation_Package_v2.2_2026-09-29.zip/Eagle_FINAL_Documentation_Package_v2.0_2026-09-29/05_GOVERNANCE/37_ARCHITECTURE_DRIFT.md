# Architecture Drift
## Detect
Compare implemented components/interfaces/dependencies/configuration against the frozen architecture and ADRs.

## Response
Detect → classify → impact analysis → ADR or correction → test → evidence.

## Rule
Unapproved architectural drift is a release blocker when it affects security boundaries.
