# Adoption Registry
## Status vocabulary
`REFERENCE | CANDIDATE | POC | ADOPTED | REQUIRED | OPTIONAL | DEFERRED | REJECTED | REPLACED`

## Required fields
Name, purpose, source, version, license, maintenance, advisories, platforms, integration status, tests, threat impact, decision, owner.

## Adoption gate
Source → Security Review → Maturity → License → Maintenance → Interoperability → Threat Model → Prototype → Tests → Decision.
