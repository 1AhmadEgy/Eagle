# Protocol Specification
## Status
FINAL DOCUMENTATION BASELINE; protocol implementation profile remains G2-gated.

## Required sections
- Terminology and invariants
- Identity
- Device registration/linking
- Key lifecycle and prekeys
- Session establishment
- PQXDH integration profile
- Double Ratchet profile
- Message format and serialization
- State machines
- Delivery, ordering and replay
- Attachments
- P2P/network interaction
- Offline behavior
- Server API/error contract
- Versioning/capability negotiation
- Downgrade prevention
- Test vectors and conformance

## Reference baseline
Signal PQXDH and Double Ratchet are reference families, not permission to invent an incompatible profile. Exact implementation/version is OI-001/OI-002 and must close through G2.

## Invariants
No plaintext at untrusted server; no key leakage; authenticated peer/session binding; replay protection; explicit version negotiation; fail-closed downgrade handling.
