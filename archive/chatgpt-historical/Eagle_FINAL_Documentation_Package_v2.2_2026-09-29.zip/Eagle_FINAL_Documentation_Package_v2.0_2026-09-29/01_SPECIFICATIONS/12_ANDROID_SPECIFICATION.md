# Android Specification
## Security baseline
- Android Keystore
- StrongBox when available and appropriate
- platform authentication
- secure storage
- network security
- privacy-safe logging
- MASVS/MASTG mapping

## Capability policy
StrongBox/attestation features are capability-aware: REQUIRED / PREFERRED / OPTIONAL / UNSUPPORTED-DEGRADED.

## Acceptance
Platform matrix, secure storage tests, auth tests, tamper/resilience tests and privacy checks.
