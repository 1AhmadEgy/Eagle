# Network Specification
## Reference layers
- Direct connectivity where available
- ICE / RFC 8445
- QUIC / RFC 9000
- TURN fallback / RFC 8656
- Additional privacy mechanisms only after independent adoption review

## Rules
Transport security does not replace application E2EE.

## V1 boundary
The exact V1 transport scope is OI-003 and must be frozen by ADR before implementation.
