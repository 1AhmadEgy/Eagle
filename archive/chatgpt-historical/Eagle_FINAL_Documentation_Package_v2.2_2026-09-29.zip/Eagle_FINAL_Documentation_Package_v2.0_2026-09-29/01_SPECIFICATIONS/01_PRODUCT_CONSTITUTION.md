# Product Constitution
## Purpose
Eagle / PrivateMesh is a security-first private communications system whose core trust, identity, cryptographic, recovery and deletion decisions are deterministic and auditable.

## Non-negotiables
- Security and privacy before feature count.
- No custom cryptography.
- Minimal server knowledge and retention.
- Least privilege and explicit trust states.
- Fail closed on security-critical ambiguity.
- Independent verification for security-critical work.
- AI cannot become the final authority for security state.
- Every material claim maps to evidence.

## Scope
Core protocol, clients, network, supporting services, security lab, supply chain, documentation and governed AI/tooling.

## Out of scope by default
Arbitrary blockchain, arbitrary telemetry, arbitrary cloud storage, arbitrary AI agents, Kafka/Elasticsearch/Logstash/Zeek/Suricata as mandatory product components. Each requires an independent adoption decision.
