# Identity Specification
## Goals
Unambiguous identity, authenticated device ownership, explicit lifecycle and auditable state transitions.

## Required
- Account identity model
- Device identity
- Public identity material
- Registration
- Authentication
- Linking
- Replacement
- Revocation
- Expiry
- Recovery separation

## Rule
Account recovery and encrypted-data recovery are separate concepts and must not share an implicit bypass path.
