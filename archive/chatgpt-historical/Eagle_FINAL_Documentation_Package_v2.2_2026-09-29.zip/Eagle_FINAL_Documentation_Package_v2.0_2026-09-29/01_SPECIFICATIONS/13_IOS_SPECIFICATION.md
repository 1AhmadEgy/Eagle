# iOS Specification
## Security baseline
- Keychain
- Secure Enclave where applicable
- App Attest where adopted
- platform authentication
- secure networking
- privacy-safe logging

## Capability policy
Apple security capabilities are modeled explicitly and tested; unavailable capabilities must not be silently treated as present.

## Acceptance
Platform matrix, storage/network/auth tests, attestation tests where applicable and privacy review.
