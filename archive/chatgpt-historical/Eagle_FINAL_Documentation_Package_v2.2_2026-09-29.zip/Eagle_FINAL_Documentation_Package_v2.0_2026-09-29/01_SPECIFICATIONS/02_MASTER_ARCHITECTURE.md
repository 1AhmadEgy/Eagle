# Master Architecture
## Layers
1. Security/Protocol Core
2. Platform Integration
3. Client UX
4. Network/Transport
5. Minimal Services
6. Observability with privacy controls
7. AI/Automation outside the Security Kernel

## Security Kernel
Deterministic, versioned, auditable and fail-closed. It owns trust, recovery/deletion policy and security decisions.

## Core direction
Rust is the primary core implementation direction; platform clients integrate the core without duplicating security-critical logic.

## Server boundary
Server functions are limited to the minimum required identity/authentication/discovery/rendezvous and delivery support. Plaintext messages, private keys and unrestricted message history are not part of the intended server trust model.

## Architecture freeze gate
V1 platform scope, transport boundary, server retention, identity/device state machine, recovery and deletion semantics must be frozen through G1.
