# Deletion Specification
## Guarantee layers
1. Logical deletion
2. Application deletion
3. Cryptographic deletion where applicable
4. OS/filesystem semantics
5. Backup/replica semantics
6. Forensic limitations

## Rule
Do not claim absolute physical destruction without defensible evidence.

## Coverage
Database rows, WAL/journals, caches, attachments, thumbnails, temp data, indexes, metadata, keys, derived state and backups.

## Verification
Deletion tests plus crash/restart and forensic-oriented verification where feasible.
