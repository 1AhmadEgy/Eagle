# Recovery Specification
## Two separate domains
- Account/identity recovery
- Encrypted-data recovery

## Security rules
Recovery must not bypass authentication, device trust, encryption policy or deletion policy.

## Required
Threat model, state machine, user-visible semantics, abuse controls, audit evidence and recovery testing.
