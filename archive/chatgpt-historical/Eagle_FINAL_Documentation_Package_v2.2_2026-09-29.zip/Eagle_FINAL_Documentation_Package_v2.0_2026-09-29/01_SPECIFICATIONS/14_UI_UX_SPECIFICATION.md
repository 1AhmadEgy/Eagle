# UI/UX Specification
## Goals
Make security states understandable without exposing secrets or unnecessary metadata.

## Required states
Onboarding, verification, trust changes, errors, offline, recovery, deletion, revoked device, network failure, security warning and degraded capability.

## Security UX
Warnings must not be bypassable through ambiguous wording. Sensitive material must never be rendered unnecessarily.

## Accessibility
Keyboard/screen-reader/dynamic text/RTL/localization behavior must be testable.
