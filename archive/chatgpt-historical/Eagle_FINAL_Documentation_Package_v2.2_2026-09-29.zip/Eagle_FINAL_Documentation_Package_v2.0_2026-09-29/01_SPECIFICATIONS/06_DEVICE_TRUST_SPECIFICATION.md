# Device Trust Specification
## State machine
`UNKNOWN → PENDING_VERIFICATION → VERIFIED → REVOKED`
with `EXPIRED/REPLACED` as terminal/transition states where defined.

## Requirements
- Every transition has an authenticated trigger.
- Revocation is explicit.
- New devices cannot silently inherit trust.
- Platform capabilities are modeled as capabilities, not universal guarantees.
- Attestation is optional/required only where the final platform policy says so.

## Evidence
State-machine tests, negative transitions, replay tests and independent review.
