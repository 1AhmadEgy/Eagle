# Cryptography Specification
## Status
G2 CRYPTO FREEZE REQUIRED

## Reference families
- Signal PQXDH
- Signal Double Ratchet
- NIST FIPS 203 / 204 / 205 as applicable
- Standard AEAD/KDF/signature constructions only through reviewed implementations

## Rules
- No custom primitives.
- Exact algorithm, library, version, parameter profile and serialization must be recorded before implementation.
- Every cryptographic state transition must have test vectors.
- Sensitive key material must have explicit lifecycle and zeroization/retention semantics where supported.
- Crypto agility must not become algorithm ambiguity.

## Acceptance
Conformance vectors, negative tests, interoperability evidence, implementation review, dependency/advisory review and independent security verification.
