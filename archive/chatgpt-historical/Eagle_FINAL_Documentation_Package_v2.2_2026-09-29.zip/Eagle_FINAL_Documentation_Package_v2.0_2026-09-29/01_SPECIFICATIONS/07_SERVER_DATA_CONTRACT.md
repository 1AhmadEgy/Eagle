# Server Data Contract
## Principle
The server is not the authoritative message-history store.

## Each server-side field requires
`purpose / sensitivity / retention / access / deletion / audit`

## Prohibited by default
- Plaintext messages
- Plaintext attachments
- Private identity keys
- Session encryption keys
- Recovery secrets sufficient by themselves to recover protected data
- Indefinite message history

## Transient ciphertext
A bounded, recipient-bound, TTL-controlled ciphertext delivery buffer may be considered only after ADR approval. Exact retention is OI-004.
