# Storage Specification
## Scope
Local database, WAL/journal, cache, attachments, thumbnails, temp files, indexes, key material and derived state.

## Requirements
- Data minimization
- Explicit classification
- Secure local storage according to platform capability
- Migration safety
- Crash consistency
- No sensitive logging
- Deletion coverage

## Candidate
SQLite is a candidate/reference technology; final storage/encryption choice remains a decision item.
