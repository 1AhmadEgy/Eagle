# EAGLE Assignment Form

**Assignment ID:**  
**Specialty:**  
**Owner:**  
**Reviewer:**  
**Version:**  

## Objective

## Scope
### In Scope
### Out of Scope

## Source / Evidence
- Source IDs:
- Reference URLs:
- Evidence IDs:

## Requirements
- REQ-

## Threats / Invariants
- THREAT-
- INV-

## ADR / Specification
- ADR-
- SPEC-

## Tasks
1.
2.
3.

## Deliverables
1.
2.
3.

## Acceptance Criteria
1.
2.
3.

## Tests
- Unit
- Integration
- Negative
- Security
- Regression
- Interoperability

## Handoff
- Changed:
- Why:
- Tested:
- Not tested:
- Remaining risks:
- Next owner:

## Status
`PROPOSED | READY | IN_PROGRESS | REVIEW | ACCEPTED | VERIFIED | BLOCKED | REJECTED`
