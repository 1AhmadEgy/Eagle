# 🦅 Eagle — حزمة عمل التخصص 05

## مهندس Backend/Server

**Team ID:** `EAGLE-BACKEND-05`  
**حالة الوثيقة:** Template / Ready for Assignment  
**المشروع:** Eagle / PrivateMesh  
**المرحلة:** Pre-Implementation / Implementation-ready baseline

## 1. المهمة
خدمات الهوية والاكتشاف والـ rendezvous والعقود الدنيا

## 2. المدخلات الإلزامية
- Server Contract، Identity Spec
- Master Reference Index
- المتطلبات المعتمدة ذات الصلة
- ADRs ذات الصلة
- Threat Model وSecurity Invariants ذات الصلة
- نتائج الاختبارات أو القيود من الفرق السابقة

## 3. المخرجات
- server، API contract، tests، abuse controls
- سجل التغييرات.
- Evidence links/IDs.
- Test results.
- Open issues / assumptions.

## 4. حدود الصلاحية
- العمل داخل نطاق التكليف فقط.
- لا تغيير في قرار معماري/أمني/تشفيري معتمد دون ADR أو مسار الموافقة المحدد.
- أي تعارض مع المواصفة يوقف التنفيذ ويُرفع للجهة المالكة.
- أي secret أو private key أو plaintext حساس يجب أن يبقى خارج artifacts وlogs.

## 5. ممنوعات التخصص
لا يخزن plaintext أو مفاتيح أو تاريخ رسائل غير مصرح

## 6. Definition of Ready (DoR)
- المتطلبات محددة.
- المرجع الفني/الأمني معروف.
- dependencies محددة.
- acceptance criteria قابلة للاختبار.
- owner/reviewer محددان.
- test environment محدد.

## 7. Definition of Done (DoD)
- التنفيذ/التصميم مكتمل ضمن النطاق.
- الاختبارات المطلوبة ناجحة.
- security/privacy review مكتمل عند الحاجة.
- evidence محفوظ ومربوط بالمتطلب.
- documentation محدثة.
- لا توجد assumptions غير موثقة.

## 8. معايير القبول
API conformance، authz، validation، rate limits، failure tests

## 9. الاختبارات المطلوبة
- Unit / component tests عند انطباقها.
- Integration tests.
- Negative/failure tests.
- Regression tests.
- Security-specific tests.
- Interoperability/conformance tests عند انطباقها.

## 10. نموذج التكليف
**Assignment ID:** `EAGLE-BACKEND-XXX`  
**Objective:**  
**In Scope:**  
**Out of Scope:**  
**Inputs:**  
**Tasks:**  
**Deliverables:**  
**Dependencies:**  
**Acceptance Criteria:**  
**Security Constraints:**  
**Tests:**  
**Evidence:**  
**Reviewer:**  
**Status:** `PROPOSED | IN_PROGRESS | REVIEW | ACCEPTED | VERIFIED`

## 11. Handoff
التسليم لا يكون "ملفات فقط". يجب أن يتضمن:
1. ما تم تغييره.
2. لماذا تم تغييره.
3. ما المرجع الذي يبرره.
4. كيف تم اختباره.
5. ما الذي لم يُختبر.
6. المخاطر المتبقية.
7. الخطوة التالية والجهة المستلمة.

