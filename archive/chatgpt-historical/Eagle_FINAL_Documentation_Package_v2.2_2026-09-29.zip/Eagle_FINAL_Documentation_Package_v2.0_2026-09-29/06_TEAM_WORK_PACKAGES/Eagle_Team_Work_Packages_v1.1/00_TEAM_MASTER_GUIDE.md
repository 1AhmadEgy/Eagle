# 🦅 Eagle — Team Work Packages Master Guide v1.1

## الغرض
هذه الحزمة مخصصة لتسليم أجزاء مشروع Eagle / PrivateMesh إلى أفراد أو فرق متخصصة بطريقة تمنع تداخل الصلاحيات وتربط كل عمل بالمتطلبات والمراجع والاختبارات والأدلة.

## القاعدة الحاكمة
```text
SOURCE
  ↓
EVIDENCE
  ↓
REVIEW
  ↓
DECISION / ADR
  ↓
SPECIFICATION
  ↓
IMPLEMENTATION
  ↓
TEST
  ↓
INDEPENDENT VERIFICATION
  ↓
DOCUMENTATION
  ↓
RELEASE GATE
```

## حالة المشروع
- المشروع في مرحلة ما قبل الإنتاج؛ لا يُفترض وجود كود إنتاجي مكتمل.
- هذه الحزم لا تمنح أي شخص صلاحية تغيير البروتوكول أو سياسة الأمان منفردًا.
- أي عنصر غير مثبت يبقى `PROPOSED` أو `UNKNOWN`.

## المبادئ
1. Security-first / fail-closed.
2. لا custom cryptography.
3. أقل صلاحية ممكنة.
4. الفصل بين التصميم والتنفيذ والاختبار والاعتماد.
5. كل claim أمني يحتاج evidence.
6. لا اعتماد لمكتبة/أداة لمجرد الشهرة.
7. المصدر الرسمي والمعيار أولًا، ثم الأبحاث والمشاريع المرجعية بعد المراجعة.
8. AI مساعد هندسي وليس سلطة أمنية نهائية.
9. لا release مع blocker أمني غير معالج أو مقبول رسميًا.
10. التوثيق جزء من التنفيذ وليس نشاطًا لاحقًا.

## دورة حالة المهمة
`PROPOSED → READY → IN_PROGRESS → REVIEW → ACCEPTED → VERIFIED → RELEASED`
مع مسارات:
`BLOCKED / REJECTED / SUPERSEDED / DEPRECATED`

## البوابات
- G0 Source Integrity
- G1 Architecture Freeze
- G2 Crypto Freeze
- G3 Mobile Security
- G4 Observability Safety
- G5 Supply Chain
- G6 Security Verification
- G7 Production

## DoR العام
- Owner + reviewer
- Scope / out of scope
- Requirement IDs
- ADR IDs
- Threat IDs
- Dependencies
- Acceptance criteria
- Test plan
- Evidence plan

## DoD العام
- Implementation/design complete
- Tests pass
- Security/privacy review where required
- Evidence linked
- Documentation updated
- No unexplained deviations
- Independent verification for security-critical work

## قواعد التغيير
أي تغيير يمس:
- cryptographic primitive/protocol
- identity/authentication
- trust state
- recovery
- deletion guarantees
- server data retention
- telemetry contents
- tool permissions
- release signing
- security invariants

يحتاج مراجعة الجهة المالكة وADR/decision record مناسب.

## مراجع خارجية أساسية
- NIST SSDF SP 800-218: secure development practices.
- OWASP MASVS/MASTG: mobile security verification/testing.
- SLSA 1.2: supply-chain security and provenance.
- IETF/Signal specifications حسب التخصص.

## مصادر تحقق خارجية
NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final
OWASP MASVS: https://mas.owasp.org/MASVS/
SLSA 1.2: https://slsa.dev/spec/v1.2/

## قاعدة الأدلة
كل تسليم يجب أن يجيب:
- What?
- Why?
- Based on which source?
- Which requirement?
- Which threat?
- Which test?
- What result?
- Who reviewed it?
- What remains unknown?

## مسار التصعيد
1. اكتشاف المشكلة.
2. إيقاف الجزء المتأثر عند الخطر العالي.
3. فتح Finding/Issue.
4. ربطه بالمتطلب والتهديد.
5. اقتراح remediation.
6. اختبار الإصلاح.
7. Independent verification.
8. تحديث ADR/spec/evidence.
9. إعادة الاختبار.
