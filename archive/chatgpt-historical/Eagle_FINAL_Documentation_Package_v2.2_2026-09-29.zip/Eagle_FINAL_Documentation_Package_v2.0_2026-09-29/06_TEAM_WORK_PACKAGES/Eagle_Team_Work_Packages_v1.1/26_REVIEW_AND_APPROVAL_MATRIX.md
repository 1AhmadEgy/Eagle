# Eagle — Review & Approval Matrix

| Workstream | Primary | Mandatory Review | Independent Verification |
|---|---|---|---|
| Architecture | Architect | Security + affected engineers | QA/Security |
| Crypto/Protocol | Crypto | Security + Architecture | Independent security reviewer |
| Backend | Backend | Security + Architecture | QA |
| Network/P2P | Network | Security + Protocol | QA/Security |
| Android/iOS | Platform owner | Security + UX | QA/Security |
| Storage | Storage | Privacy + Security | QA |
| Deletion/Recovery | Privacy | Security + Storage | Security/QA |
| UI/UX | UX | Security/Accessibility | QA |
| AI | AI | Security + Governance | AI eval/verifier |
| MCP | MCP Security | Security + Architecture | Security |
| Supply Chain | DevSecOps | Security + Release | Independent verification |
| Observability | Observability | Privacy + Security | QA/Security |
| Release | Release | Security + QA + owners | Release verifier |

**قاعدة:** صاحب التنفيذ لا يكون وحده صاحب الاعتماد النهائي للعمل الأمني الحرج.
