# 🦅 Eagle — حزمة عمل التخصص 03

## مهندس/معماري الأمن

**Team ID:** `EAGLE-SECURITY-03`  
**حالة الوثيقة:** Template / Ready for Assignment  
**المشروع:** Eagle / PrivateMesh  
**المرحلة:** Pre-Implementation / Implementation-ready baseline

## 1. المهمة
Threat model، invariants، security gates

## 2. المدخلات الإلزامية
- Threat Model، Security Invariants، ADRs
- Master Reference Index
- المتطلبات المعتمدة ذات الصلة
- ADRs ذات الصلة
- Threat Model وSecurity Invariants ذات الصلة
- نتائج الاختبارات أو القيود من الفرق السابقة

## 3. المخرجات
- Security requirements، findings، gates
- سجل التغييرات.
- Evidence links/IDs.
- Test results.
- Open issues / assumptions.

## 4. حدود الصلاحية
- العمل داخل نطاق التكليف فقط.
- لا تغيير في قرار معماري/أمني/تشفيري معتمد دون ADR أو مسار الموافقة المحدد.
- أي تعارض مع المواصفة يوقف التنفيذ ويُرفع للجهة المالكة.
- أي secret أو private key أو plaintext حساس يجب أن يبقى خارج artifacts وlogs.

## 5. ممنوعات التخصص
لا يعتمد إصلاحًا أمنيًا دون دليل مستقل

## 6. Definition of Ready (DoR)
- المتطلبات محددة.
- المرجع الفني/الأمني معروف.
- dependencies محددة.
- acceptance criteria قابلة للاختبار.
- owner/reviewer محددان.
- test environment محدد.

## 7. Definition of Done (DoD)
- التنفيذ/التصميم مكتمل ضمن النطاق.
- الاختبارات المطلوبة ناجحة.
- security/privacy review مكتمل عند الحاجة.
- evidence محفوظ ومربوط بالمتطلب.
- documentation محدثة.
- لا توجد assumptions غير موثقة.

## 8. معايير القبول
كل claim مرتبط بتهديد واختبار ودليل

## 9. الاختبارات المطلوبة
- Unit / component tests عند انطباقها.
- Integration tests.
- Negative/failure tests.
- Regression tests.
- Security-specific tests.
- Interoperability/conformance tests عند انطباقها.

## 10. نموذج التكليف
**Assignment ID:** `EAGLE-SECURITY-XXX`  
**Objective:**  
**In Scope:**  
**Out of Scope:**  
**Inputs:**  
**Tasks:**  
**Deliverables:**  
**Dependencies:**  
**Acceptance Criteria:**  
**Security Constraints:**  
**Tests:**  
**Evidence:**  
**Reviewer:**  
**Status:** `PROPOSED | IN_PROGRESS | REVIEW | ACCEPTED | VERIFIED`

## 11. Handoff
التسليم لا يكون "ملفات فقط". يجب أن يتضمن:
1. ما تم تغييره.
2. لماذا تم تغييره.
3. ما المرجع الذي يبرره.
4. كيف تم اختباره.
5. ما الذي لم يُختبر.
6. المخاطر المتبقية.
7. الخطوة التالية والجهة المستلمة.

