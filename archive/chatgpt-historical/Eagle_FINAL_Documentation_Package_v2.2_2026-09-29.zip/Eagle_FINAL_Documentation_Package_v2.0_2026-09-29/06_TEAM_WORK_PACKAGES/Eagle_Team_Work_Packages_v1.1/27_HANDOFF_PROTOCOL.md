# Eagle — Handoff Protocol

## لا يتم التسليم بالملفات فقط
كل handoff يجب أن يحتوي على:
1. Artifact inventory.
2. Requirement mapping.
3. Source/ADR mapping.
4. Test results.
5. Security/privacy review.
6. Known limitations.
7. Open issues.
8. Rollback/recovery instructions عند الحاجة.
9. Reviewer identity.
10. Version/commit/build identifier عند توفره.

## ممنوعات
- "يعمل عندي" دون evidence.
- إغلاق finding دون retest.
- تغيير spec شفهيًا.
- نسخ أسرار داخل issue/PR/docs.
- الاعتماد على AI output كدليل أمني.
