# Eagle — Security Stop-the-Line Rules

يوقف المسار المتأثر فورًا عند اكتشاف:
- cryptographic flaw
- authentication/authorization bypass
- identity ambiguity
- key leakage
- plaintext leakage
- recovery bypass
- deletion-policy bypass
- downgrade vulnerability
- critical dependency/supply-chain compromise
- build/release compromise
- serious security-policy ambiguity

الإجراء:
Detect → Contain → Record → Review → Remediate → Test → Independent Verify → Regress → Re-open gate
