# Final Team Handoff Checklist
For every individual/contractor/team:
- Assignment ID
- Scope / out-of-scope
- Requirements
- ADR/spec references
- Threats/invariants
- Allowed tools/dependencies
- Forbidden changes
- Deliverables
- Tests
- Evidence
- Reviewer
- Independent verifier if security-critical
- Handoff note
- Known limitations
- Rollback/recovery notes
- Final status
