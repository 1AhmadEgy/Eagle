# Recovery and Device Transfer Specification

Separate:
- identity/account recovery
- data recovery
- trusted-device transfer

Preferred early path: trusted device → authenticated device-to-device transfer → new trusted device.

Recovery must not silently weaken identity assurance or expose historical plaintext.
