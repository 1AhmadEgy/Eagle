# Data Lifecycle Matrix

For each data class record:
creation → use → storage → replication → cache → backup → deletion trigger → deletion mechanism → verification → retention.

Classes include identity material, session keys, plaintext, ciphertext, metadata, attachments, telemetry, recovery material, build/release secrets.
