# Storage Security Specification

Sensitive local state includes identity keys, session state, message metadata, ciphertext, attachments, recovery state, and deletion markers.

Required controls:
- encryption/key protection
- access isolation
- rollback detection where required
- WAL/journal/cache/temp-file analysis
- backup behavior
- crash consistency
- migration safety
- corruption handling
