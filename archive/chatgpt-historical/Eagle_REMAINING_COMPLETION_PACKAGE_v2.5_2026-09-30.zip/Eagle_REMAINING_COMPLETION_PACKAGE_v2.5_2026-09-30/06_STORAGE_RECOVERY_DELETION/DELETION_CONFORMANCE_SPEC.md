# Deletion Conformance Specification

Deletion domains:
DB rows, WAL/journal, caches, attachments, thumbnails, temp files, indexes, key material, derived state, backups/restore paths.

Guarantees must be stated precisely as logical, cryptographic, application-level, OS/filesystem, backup, or forensic-residual guarantees.

No claim of absolute physical destruction is permitted without a defensible technical guarantee.
