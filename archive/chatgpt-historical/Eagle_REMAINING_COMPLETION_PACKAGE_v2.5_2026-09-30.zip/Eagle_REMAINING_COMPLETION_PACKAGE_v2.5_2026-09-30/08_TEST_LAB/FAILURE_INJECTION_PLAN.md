# Failure Injection Plan

Inject:
network loss, corruption, replay, duplication, reordering, clock anomalies, disk full, database corruption, process kill, power-loss simulation, dependency failure, relay failure, server compromise simulation, malformed tool arguments, AI refusal/unsafe recommendation.

Expected behavior must remain fail-closed for security-critical conditions.
