# Independent Verification Protocol

The verifier must not be the author of the evidence under review for security-critical gates.

Verify:
artifact identity → source/commit → build → tests → security tests → evidence integrity → requirement linkage → acceptance criteria → residual risk.
