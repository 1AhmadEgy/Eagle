# Property / State-Machine / Fuzz Test Plan

Targets:
- protocol parser
- serialization/deserialization
- session state transitions
- replay handling
- skipped-key bounds
- malformed negotiation
- storage migration
- recovery state machine
- deletion state machine

Properties must express security invariants, not merely crash absence.
