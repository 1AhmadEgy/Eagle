# Master Test Case Template

TEST-ID
Requirement
ADR
Component
Type
Threat/Invariant
Environment
Version/commit
Preconditions
Input
Expected
Actual
Evidence artifact/hash
Result: PASS/FAIL/BLOCKED/NOT_RUN/N/A
Regression: YES/NO
Independent verifier
Date
Notes
