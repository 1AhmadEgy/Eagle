# Cryptography Interface Contract

No custom cryptographic primitive is permitted.

The core exposes narrow interfaces for:
- key generation
- key agreement
- KDF
- AEAD
- signatures
- secure random generation
- key destruction/zeroization semantics where supported

Implementations must be pinned, reviewed, licensed, maintained, vulnerability-monitored, and tested against known vectors.
