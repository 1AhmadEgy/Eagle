# Signal PQXDH / Double Ratchet Adoption Gate

Reference status: protocol specifications are references, not automatic library adoption.

Required before adoption:
- exact implementation/library and version
- license
- maintenance status
- advisories
- supported platforms
- API/security review
- interoperability vectors
- state-machine tests
- negative tests
- migration/upgrade plan
- independent review

Current project status: implementation choice remains a gated decision unless an accepted ADR closes it.
