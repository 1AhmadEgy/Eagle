# MCP Security Reference Architecture

Authentication → Authorization → Allowlist → Schema Validation → Argument Validation → Sandbox → Rate Limit → Audit → Execution.

Threats: prompt injection, tool poisoning, argument injection, confused deputy, excessive agency, cross-tool contamination, secret/data exfiltration.
