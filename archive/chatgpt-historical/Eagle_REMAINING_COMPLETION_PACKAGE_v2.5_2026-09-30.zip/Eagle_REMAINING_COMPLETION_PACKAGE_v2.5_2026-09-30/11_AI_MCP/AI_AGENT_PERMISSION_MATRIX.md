# AI Agent Permission Matrix

Roles: Planner, Specialist, Critic, Verifier, Executor, Auditor, Governor.

Critical rule: AI may analyze, propose, generate tests, and prepare patches; deterministic security policy decides trust/auth/security state.

Each agent requires: identity, authority, tools, data scope, allowed actions, forbidden actions, limits, sandbox, approval, evidence, verifier, rollback, audit policy.
