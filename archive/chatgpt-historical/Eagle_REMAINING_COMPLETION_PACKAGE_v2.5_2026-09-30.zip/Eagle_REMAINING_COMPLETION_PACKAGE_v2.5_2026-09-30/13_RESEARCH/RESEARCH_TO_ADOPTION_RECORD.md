# Research to Adoption Record

Record each proposed technology as:
SOURCE → CLAIM → PROBLEM → SECURITY REVIEW → MAINTENANCE/LICENSE → COMPATIBILITY → THREAT MODEL → PoC → TESTS → ADR → SPECIFICATION → ADOPTION STATUS.

Research is not implementation evidence.
