# Standards Drift Review

Review triggers:
new standard revision, errata, CVE/advisory, library release, platform security change, protocol change, deprecation, license change.

Flow:
source update → impact analysis → security review → ADR/requirement impact → test updates → evidence → release decision.
