# Reference Update — 2026-09-30

Verified external baselines used for this package:
- SLSA v1.2: Approved current specification.
- Signal Double Ratchet: Revision 4 dated 2025-11-04.
- OWASP MASWE v1.0.0: stable release, 2026-08-17; 78 stable weakness IDs.
- OWASP MASTG v2.0.0: stable release in 2026; its structure links MASVS/MASWE/MASTG and does not rely on the old checklist artifact.
- NIST FIPS 203/204/205: final PQC standards, approved 2024-08-13.

These are reference inputs. They do not by themselves prove that Eagle has adopted any implementation or passed any test.
