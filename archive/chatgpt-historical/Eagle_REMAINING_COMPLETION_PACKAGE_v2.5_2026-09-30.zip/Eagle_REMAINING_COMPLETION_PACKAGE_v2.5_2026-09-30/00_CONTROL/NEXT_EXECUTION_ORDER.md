# Next Execution Order

1. Intake actual repository/source tree.
2. Freeze exact toolchain and dependency lock state.
3. Close OI-001..OI-008 using evidence-backed ADRs.
4. Implement Security Kernel and core state machines.
5. Implement protocol conformance tests before broad UI work.
6. Add network/storage/platform adapters.
7. Execute negative/fuzz/failure-injection tests.
8. Build evidence graph and release evidence.
9. Independent verification.
10. External security audit before production release.
