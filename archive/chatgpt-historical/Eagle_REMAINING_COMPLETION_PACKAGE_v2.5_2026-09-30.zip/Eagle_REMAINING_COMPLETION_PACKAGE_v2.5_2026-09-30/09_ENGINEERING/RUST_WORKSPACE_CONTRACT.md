# Rust Workspace Contract

Required baseline artifacts:
Cargo.toml
Cargo.lock
rust-toolchain.toml
workspace structure
format/lint policy
unsafe-code policy
MSRV policy
feature policy
unit/integration test layout
fuzz targets
security CI configuration
license policy
advisory policy
SBOM/provenance hooks

No production implementation is implied by this document.
