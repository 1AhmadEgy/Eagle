# Repository Policy

Protected branches, mandatory review, CODEOWNERS for security-critical paths, signed/reviewed changes where supported, dependency lock discipline, no secrets in repository, reproducible build inputs, security disclosure process, release tagging, artifact retention and evidence retention.
