# CI Security Pipeline

Suggested order:
format → lint → compile → unit → integration → protocol/conformance → property/fuzz smoke → dependency/advisory checks → secret scanning → SAST → build artifact → SBOM → provenance → signature/attestation → verification.

A failed critical security control blocks release.
