# ICE / TURN / QUIC Test Matrix

Scenarios:
- direct IPv4
- direct IPv6
- symmetric NAT
- restricted NAT
- relay-only
- packet loss
- reordering
- duplication
- latency/jitter
- path migration
- server/relay outage
- malformed signaling
- resource exhaustion
- TLS/QUIC handshake failure

Evidence must include environment, exact versions/configuration, logs/pcap where appropriate, expected vs actual, and regression classification.
