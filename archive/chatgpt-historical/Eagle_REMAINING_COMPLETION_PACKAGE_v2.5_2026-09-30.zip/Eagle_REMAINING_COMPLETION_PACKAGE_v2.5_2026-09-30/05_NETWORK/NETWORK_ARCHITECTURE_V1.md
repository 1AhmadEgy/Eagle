# Network Architecture V1

Preferred path:
Direct connectivity where policy permits → NAT traversal → relay fallback → controlled failure.

Candidate technologies are separated from adopted protocol behavior.

Network layer must not receive plaintext or long-term private keys.
