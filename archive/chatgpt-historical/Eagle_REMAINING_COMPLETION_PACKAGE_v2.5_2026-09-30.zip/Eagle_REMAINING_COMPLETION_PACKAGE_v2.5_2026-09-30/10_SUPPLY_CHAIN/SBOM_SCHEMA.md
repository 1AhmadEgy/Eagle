# SBOM Schema Contract

Preferred machine-readable formats: CycloneDX and/or SPDX.

Minimum linkage:
component → version → source → license → hash → dependency relation → advisory status → build artifact.

SBOM alone is not provenance and does not prove build integrity.
