# Dependency Acceptance Gate

For each dependency:
problem solved, authoritative source, exact version, license, maintainer, maintenance, advisories, transitive dependencies, unsafe/native code, privileges, network access, secrets access, reproducibility, SBOM, alternatives, tests, ADR, adoption status.
