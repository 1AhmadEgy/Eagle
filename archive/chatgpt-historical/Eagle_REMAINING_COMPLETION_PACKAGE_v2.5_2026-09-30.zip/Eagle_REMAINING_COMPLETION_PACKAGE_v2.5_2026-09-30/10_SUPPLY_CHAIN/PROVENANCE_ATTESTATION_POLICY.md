# Provenance and Attestation Policy

Required chain:
source commit → build environment → dependencies → build steps → artifact → provenance → attestation → signature → verification.

SLSA v1.2 is the current approved baseline. The project must record the exact implementation level achieved rather than claiming a level without evidence.
