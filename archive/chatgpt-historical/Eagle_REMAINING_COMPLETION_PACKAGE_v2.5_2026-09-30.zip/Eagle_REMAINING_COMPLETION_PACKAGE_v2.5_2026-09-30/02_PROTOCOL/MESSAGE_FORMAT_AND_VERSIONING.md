# Message Format and Versioning Contract

Every protocol message must define:
- protocol version
- message type
- session/context identifier where applicable
- monotonic/replay protection fields where applicable
- payload encoding
- authenticated associated data
- size limits
- canonical serialization rules
- error handling
- downgrade/capability negotiation behavior

Unknown security-critical fields or incompatible versions must fail closed unless explicitly specified as safely ignorable.
