# Downgrade and Capability Policy

The implementation must never silently select a weaker security mode because a peer/server claims incompatibility.

Required tests:
- version rollback
- algorithm rollback
- missing mandatory capability
- forged capability advertisement
- mixed-version negotiation
- replayed negotiation
- downgrade through relay/server
