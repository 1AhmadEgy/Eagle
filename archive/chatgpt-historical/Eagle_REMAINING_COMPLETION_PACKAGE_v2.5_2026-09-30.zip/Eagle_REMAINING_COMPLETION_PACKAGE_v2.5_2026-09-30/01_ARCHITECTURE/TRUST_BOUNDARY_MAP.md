# Trust Boundary Map

Boundaries to model and test:
- Device ↔ Security Kernel
- Security Kernel ↔ Crypto Provider
- Client ↔ Network
- Client ↔ Minimal Server
- App ↔ OS secure storage
- App ↔ filesystem/database/cache
- AI ↔ project data
- AI ↔ tools/MCP
- CI ↔ source/dependencies/build workers
- Release system ↔ artifacts/signing/provenance

Every boundary requires authentication/authorization, input validation, failure behavior, logging policy, and negative tests.
