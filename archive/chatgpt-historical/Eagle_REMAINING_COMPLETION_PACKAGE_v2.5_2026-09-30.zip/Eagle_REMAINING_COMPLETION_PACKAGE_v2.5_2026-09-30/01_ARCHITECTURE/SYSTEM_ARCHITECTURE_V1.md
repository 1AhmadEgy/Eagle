# Eagle System Architecture V1

## Layers
1. Security Kernel: deterministic policy, trust state, authorization, fail-closed decisions.
2. Protocol Core: identity, session state, message state machines, serialization contracts.
3. Crypto Boundary: interfaces to reviewed cryptographic implementations; no custom primitives.
4. Transport: QUIC/direct path with ICE/TURN boundary where adopted.
5. Local State: encrypted storage, deletion policy, recovery/device transfer.
6. Platform Adapters: Android, iOS, desktop/web as staged clients.
7. Minimal Services: identity/login/discovery/rendezvous and minimum protocol support.
8. Observability: privacy-filtered events only.

## Rule
Security decisions remain deterministic and outside AI control.
