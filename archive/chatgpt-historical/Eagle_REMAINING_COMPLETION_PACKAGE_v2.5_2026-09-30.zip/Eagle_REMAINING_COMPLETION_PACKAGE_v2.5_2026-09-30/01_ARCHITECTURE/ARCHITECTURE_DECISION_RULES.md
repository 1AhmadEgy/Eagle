# Architecture Decision Rules

A technology is not adopted because it is popular or present in a source list.

Required gate:
Problem → authoritative source → security review → maintenance/license review → compatibility → threat model → PoC if needed → ADR → specification → tests → evidence.

Any conflict with a higher-authority standard or existing accepted ADR must stop implementation until reconciled.
