# Android Security Baseline

Map implementation to Android Keystore/StrongBox capabilities without assuming universal hardware support.

Required tests:
key isolation, backup/restore behavior, device lock states, hardware-backed capability detection, attestation where adopted, root/debug conditions, IPC exposure, exported components, local storage, screenshots/clipboard where relevant.
