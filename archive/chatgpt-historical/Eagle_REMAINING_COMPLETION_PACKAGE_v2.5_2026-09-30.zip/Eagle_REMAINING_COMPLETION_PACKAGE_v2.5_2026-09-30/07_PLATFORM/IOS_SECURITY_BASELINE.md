# iOS Security Baseline

Use platform security capabilities through explicit adapters.

Required areas:
Secure Enclave-bound key handling where applicable, App Attest where adopted, Keychain access controls, backup behavior, app lifecycle, extensions, IPC/universal links, screenshots, local storage, jailbreak/debug conditions.
