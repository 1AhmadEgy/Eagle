# Mobile Security Traceability

Trace every mobile requirement as:
MASVS control → MASWE weakness → MASTG test → Eagle TEST-ID → implementation location → evidence → independent verification.

This follows the current OWASP structure rather than relying on the discontinued MASTG checklist artifact.
