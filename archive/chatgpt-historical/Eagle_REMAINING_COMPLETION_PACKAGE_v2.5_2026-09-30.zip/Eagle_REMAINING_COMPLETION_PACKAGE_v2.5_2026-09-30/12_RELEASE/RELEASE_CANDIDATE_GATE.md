# Release Candidate Gate

Prerequisites:
all P0 requirements verified; security findings resolved/accepted; test evidence complete; reproducible build evidence; SBOM; provenance/attestation; artifact signature; dependency review; release verification; independent security verification; required external audit.

No production release if a Stop-the-Line condition remains open.
