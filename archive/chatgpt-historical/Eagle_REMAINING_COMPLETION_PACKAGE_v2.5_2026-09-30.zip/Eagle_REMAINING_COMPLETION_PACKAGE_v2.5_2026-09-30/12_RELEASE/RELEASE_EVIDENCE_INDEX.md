# Release Evidence Index

Release ID
source commit
build ID
artifact hash
SBOM hash
provenance/attestation reference
signature reference
verification result
test suite result
security review
external audit
known limitations
rollback artifact
approval record
