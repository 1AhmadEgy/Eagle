# Eagle Threat Model V1

Assets: identity keys, session state, plaintext, metadata, recovery material, device trust state, build credentials, release artifacts, source code, CI configuration.

Actors: passive network attacker, active network attacker, compromised server, compromised client, malicious app/process, malicious dependency, CI/repository attacker, malicious tool/MCP input, social-engineering attacker.

Security properties: confidentiality, integrity, authenticity, forward secrecy, post-compromise recovery where supported, availability within defined limits, privacy/minimization, downgrade resistance, supply-chain integrity.

Method: asset → trust boundary → threat → control → invariant → test → evidence → verification.
