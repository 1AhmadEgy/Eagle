# Security Kernel Contract

The kernel owns:
- authentication and authorization decisions
- device trust state
- security policy version
- fail-closed behavior
- recovery authorization
- deletion authorization
- tool/AI permission enforcement

The kernel must not depend on an AI recommendation to make a security-critical allow/deny decision.
