# Security Abuse Cases

Minimum cases:
1. stolen trusted device
2. cloned identity material
3. malicious server modifies ciphertext metadata
4. replayed session message
5. skipped-message resource exhaustion
6. storage rollback
7. recovery social engineering
8. malicious update
9. compromised dependency
10. poisoned AI/tool instruction
11. MCP confused deputy
12. telemetry secret leakage

Each case requires prevention, detection, containment, recovery, and regression coverage.
